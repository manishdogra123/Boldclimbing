<?php 
/* 
Disable Email by Order Snippet 
*/
include 'woocommerce/emails/disable-email-by-order.php'
?>

<?php
/*
Author:     Wordpress Shuttle Team
@version:   4.1
@url:       http://www.wordpressshuttle.com
@copyright: 2017 Wordpress Shuttle
Template:   wordpress-shuttle
*/

/*

function hide_gateways( $available_gateways ) {
    if( isset( WC()->cart->total and WC()->cart->total > 2000 ) ){

    }

    if( isset( WC()->cart->total ) ){
        if ( WC()->cart->total > '2000' ) {
            unset( $available_gateways[ 'stripe_cc' ] );
            unset( $available_gateways[ 'stripe_applepay' ] );
            unset( $available_gateways[ 'stripe_googlepay' ] );
        }
    }

    //print_r($available_gateways);
    return $available_gateways;
}
*/


//if( WP_DEBUG && WP_DEBUG_DISPLAY && (defined('DOING_AJAX') && DOING_AJAX) ){
/*if( (defined('DOING_AJAX') && DOING_AJAX) ){
    @ ini_set( 'display_errors', 1 );
}
*/
/*

function mymodule_curl_before_request($curlhandle){
    session_write_close();
}
add_action( 'requests-curl.before_request', 'mymodule_curl_before_request', 9999 );
*/

//Class Bold - manage category, products
include 'bold-inventory/categories.php';
include 'bold-inventory/lines.php';
include 'bold-inventory/product.php';
include 'bold-inventory/cart.php';
include 'bold-inventory/shipping.php';

require_once 'bold-csv-cron.php';

add_action( 'wp_head', 'hide_rls_option' );


function fix_inventories(){
    global $wpdb;

    $sql="SELECT product_id, count(`name`) FROM `wp_atum_inventories`
    group by product_id 
    HAVING count(*) > 3";

    $results = $wpdb->get_results(
        $sql,
        ARRAY_A
    );
    foreach($results as $result){
        $sql_row="delete from wp_atum_inventories where name='Current stock' and product_id='".$result['product_id']."' order by id DESC LIMIT 1";
        ///$wpdb->query($sql_row);

        //echo '<span style="display: none">product_id='.$result['product_id'].'</span>';
    }
    //echo "fix_inventories";
}
//add_action( 'wp', 'fix_inventories' );

function bold_after_customer_login_form(){
    ?>
    <div class="wrp_myaccount_links">
        <h2>Need account?</h2>
        <div class="myaccount_links">
            <div class="myaccount_link">
                <a href="/create-an-account/">Create an Account</a>
            </div>
            <div class="myaccount_link">
                <a href="/wholesale-account/">Wholesale Account</a>
            </div>
        </div>
    </div>
    <?php
}
//add_action('woocommerce_after_customer_login_form', 'bold_after_customer_login_form'); // HIde other links on Login page - Gaurav


function hide_rls_option() {
    if ( is_checkout() ) {
        $isSTD = false;
        foreach( WC()->session->get( 'chosen_shipping_methods' ) as $method ){
            if( $method == 'STD' ){
                $isSTD = true;
            }
        }
        if(!$isSTD){
            wp_register_style( 'dummy-handle', false );
            wp_enqueue_style( 'dummy-handle' );
            wp_add_inline_style( 'dummy-handle', '.rlc-special-shipping{ display:none; }' );
        }
    }
}


add_filter( 'woocommerce_available_payment_gateways', 'hide_gateways' );
function hide_gateways( $available_gateways ) {

    //print_r( array_keys($available_gateways) );

    //echo "total=".WC()->cart->total;
    $limit_amout = 2000;

    $user_id = get_current_user_id();
    $isWholesaleUser = false;
    if($user_id){
        $user_meta = get_userdata( $user_id );
        $isWholesaleUser = in_array( 'wholesale_customer', $user_meta->roles );
    }
    if( !$isWholesaleUser ){
        if((WC()->customer) && (WC()->customer->get_billing_country() != 'CA' || WC()->customer->get_shipping_country() != 'CA')){
            unset( $available_gateways[ 'cheque' ] );
            unset( $available_gateways[ 'bacs' ] );
            unset( $available_gateways[ 'ibs_stripe_pad' ] );
        }
        
    }else{
        if( WC()->cart->total < $limit_amout && (WC()->customer) && (WC()->customer->get_billing_country() != 'CA' || WC()->customer->get_shipping_country() != 'CA')){
            unset( $available_gateways[ 'cheque' ] );
            unset( $available_gateways[ 'bacs' ] );

        }
        elseif(WC()->cart->total < $limit_amout && (WC()->customer) && (WC()->customer->get_billing_country() == 'CA' || WC()->customer->get_shipping_country() == 'CA')){
            unset( $available_gateways[ 'cheque' ] );
        }else{

            unset( $available_gateways[ 'stripe_googlepay' ] );
            unset( $available_gateways[ 'yith-stripe' ] );
            unset( $available_gateways[ 'cheque' ] );
            unset( $available_gateways[ 'stripe_cc' ] );
        }
        if((WC()->customer) && (WC()->customer->get_billing_country() != 'CA' || WC()->customer->get_shipping_country() != 'CA')){
            unset( $available_gateways[ 'cheque' ] );
            unset( $available_gateways[ 'bacs' ] );
            unset( $available_gateways[ 'ibs_stripe_pad' ] );
        }
    }

    /*
    if( $isWholesaleUser and WC()->cart->total > $limit_amout ){
        foreach( array_keys( $available_gateways ) as $key_payment ){
            if( $key_payment != 'stripe_ach' ){
                unset( $available_gateways[ $key_payment ] );
            }
        }
    }
    */
    if ( is_wc_endpoint_url( 'order-pay' ) ) {
        $order = wc_get_order( absint( get_query_var('order-pay') ) );

        if ( is_a( $order, 'WC_Order' ) && $order->has_status('on-hold') ) {
            
            if($isWholesaleUser){
                if($order->get_total() > $limit_amout){
                    unset( $available_gateways[ 'stripe_googlepay' ] );
                    unset( $available_gateways[ 'yith-stripe' ] );
                    unset( $available_gateways[ 'cheque' ] );
                    unset( $available_gateways[ 'stripe_cc' ] );
                }
                else{
                    unset( $available_gateways[ 'cheque' ] );
                    unset( $available_gateways[ 'bacs' ] );
                }
                   
                
            }
            else{
                 unset( $available_gateways[ 'cheque' ] );
                unset( $available_gateways[ 'bacs' ] );
            }
            
        } 
    } 
    //unset($available_gateways['stripe_ach']);
    return $available_gateways;
}


add_action( 'init', 'woocommerce_clear_cart_url' );
function woocommerce_clear_cart_url() {
    if ( isset( $_GET['cxc_empty_cart'] ) ) {
        WC()->cart->empty_cart();
    }
}


function wc_empty_cart_redirect_url() {
    return '/';
}
add_filter( 'woocommerce_return_to_shop_redirect', 'wc_empty_cart_redirect_url' );


function Awards_custom_post_type() {
    // Set UI labels for Custom Post Type
    $labels = array(
        'name'                => _x( 'Awards', 'Post Type General Name', 'storefront' ),
        'singular_name'       => _x( 'Award', 'Post Type Singular Name', 'storefront' ),
        'menu_name'           => __( 'Awards', 'storefront' ),
        'parent_item_colon'   => __( 'Parent', 'storefront' ),
        'all_items'           => __( 'All Awards', 'storefront' ),
        'view_item'           => __( 'View Awar', 'storefront' ),
        'add_new_item'        => __( 'Add New Award', 'storefront' ),
        'add_new'             => __( 'Add New', 'storefront' ),
        'edit_item'           => __( 'Edit Award', 'storefront' ),
        'update_item'         => __( 'Update Award', 'storefront' ),
        'search_items'        => __( 'Search Award', 'storefront' ),
        'not_found'           => __( 'Not Found', 'storefront' ),
        'not_found_in_trash'  => __( 'Not found in Trash', 'storefront' ),
    );
    // Set other options for Custom Post Type
    $args = array(
        'label'               => __( 'awards', 'storefront' ),
        'description'         => __( 'Awards', 'storefront' ),
        'labels'              => $labels,
        'supports'            => array( 'title', 'thumbnail',),
        'hierarchical'        => false,
        'public'              => true,
        'show_ui'             => true,
        'show_in_menu'        => true,
        'show_in_nav_menus'   => true,
        'show_in_admin_bar'   => true,
        'menu_position'       => 5,
        'can_export'          => true,
        'has_archive'         => true,
        'exclude_from_search' => false,
        'publicly_queryable'  => true,
        'capability_type'     => 'post',
        'show_in_rest' => true,
    );
    // Registering your Custom Post Type
    register_post_type( 'awards', $args );
}
add_action( 'init', 'Awards_custom_post_type', 0 );


add_action( 'woocommerce_variation_options_pricing', 'bbloomer_add_custom_field_to_variations', 10, 3 );


function bbloomer_add_custom_field_to_variations( $loop, $variation_data, $variation ) {

    woocommerce_wp_text_input( array(
        'id' => 'bold_category_data[' . $loop . ']',
        'class' => 'long',
        'label' => __( 'Category Data', 'woocommerce' ),
        'value' => get_post_meta( $variation->ID, 'bold_category_data', true )
    ) );
}

add_action( 'woocommerce_save_product_variation', 'bbloomer_save_custom_field_variations', 10, 2 );

function bbloomer_save_custom_field_variations( $variation_id, $i ) {
    $bold_category_data = $_POST[ 'bold_category_data' ][ $i ];
    if ( isset( $bold_category_data ) ) update_post_meta( $variation_id, 'bold_category_data', esc_attr( $bold_category_data ) );
}

add_filter( 'woocommerce_available_variation', 'bbloomer_add_custom_field_variation_data' );

function bbloomer_add_custom_field_variation_data( $variations ) {
    $variations[ 'bold_category_data' ] = '<br/><div class="woocommerce_custom_field">Category Data: <span>' . get_post_meta( $variations[ 'variation_id' ], 'bold_category_data', true ) . '</span></div>';
    return $variations;
}



add_action( 'init', 'cxc_woocommerce_empty_cart_url' );

function cxc_woocommerce_empty_cart_url() {
    global $woocommerce;
    if ( isset( $_GET['cxc_empty_cart'] ) ) {
        $cart_url = function_exists( 'wc_get_cart_url' ) ? wc_get_cart_url() : $woocommerce->cart->get_cart_url();
        $woocommerce->cart->empty_cart();
        wp_redirect( $cart_url );
        exit;
    }
}



//Callbacks
include 'bold-inventory/ajax_callbacks.php';


add_action( 'woocommerce_cart_calculate_fees', function() {
    global $WOOCS;
    if ( is_admin() && !defined( 'DOING_AJAX' ) ) {
        return;
    }

    if ( ! WC()->cart->prices_include_tax ) {
        $total = WC()->cart->cart_contents_total;
    } else {
        $total = WC()->cart->cart_contents_total + WC()->cart->tax_total;
    }

    $cart = WC()->cart;
   
    //$branding_limit = get_option( 'dkabz_branding_free' );
    $branding_limit = get_option( 'dkabz_branding_free' );

    //echo "total=".$total."<br/>";
    //echo "branding_limit=".$WOOCS->woocs_exchange_value( $branding_limit );

    $branding_array = Array(
        "count"             => 0,
        "price_per_piece"   => get_option( 'dkabz_branding_cost' ),
        "items"             => Array(
            "iron"          => Array(
                "price"     => get_option( 'dkabz_branding_iron' ),
                "piece"     => get_option( 'dkabz_branding_iron_piece' ),
                "count"     => 0,
                "title"     => 'Iron branding setup'
            ),
            "laser"         => Array(
                "price"     => get_option( 'dkabz_branding_laser' ),
                "piece"     => get_option( 'dkabz_branding_laser_piece' ),
                "count"     => 0,
                "title"     => 'Laser branding setup'
            ),
            "stampstick"       => Array(
                "price"     => get_option( 'dkabz_branding_stampstick' ),
                "piece"     => get_option( 'dkabz_branding_stampstick_piece' ),
                "count"     => 0,
                "title"     => 'Chalk & Tape branding setup'
            )
        )
    );
    // ----Special Discount On Cart----
    $parent_categories = ['Volumes', 'Holds', 'Macros', 'Training'];
    $cat_array = array();
    $special_total = 0;
    $Getuser_id = get_current_user_id();
    $user_role = get_userdata( $Getuser_id );
    $isWholesaleCustomer = false;
    if( $Getuser_id ){
        $isWholesaleCustomer = in_array( 'wholesale_customer', $user_role->roles );
    }

    foreach ( WC()->cart->get_cart() as $cart_item_key=>$cart_item ) {

        if ( isset( $cart_item[ 'brand' ][ 'type' ] ) ){
            switch ( $cart_item[ 'brand' ][ 'type' ] ) {

                case 'stamp':
                    $pack_quantity  = preg_replace( '/[^0-9]/', '', $cart_item[ 'variation' ][ 'attribute_pack' ] );
                    $quantity       = $cart_item[ 'quantity' ] * $pack_quantity;
                    $branding_array [ 'count' ] += $quantity;
                    $branding_array [ 'items' ][ 'stampstick' ][ 'count' ] += $quantity;
                    break;

                case 'sticker':
                    $pack_quantity  = preg_replace( '/[^0-9]/', '', $cart_item[ 'variation' ][ 'attribute_pack' ] );
                    $quantity       = $cart_item[ 'quantity' ] * $pack_quantity;
                    $branding_array [ 'count' ] += $quantity;
                    $branding_array [ 'items' ][ 'stampstick' ][ 'count' ] += $quantity;
                    break;

                default :
                    $pack_quantity  = preg_replace( '/[^0-9]/', '', $cart_item[ 'variation' ][ 'attribute_pack' ] );
                    $quantity       = $cart_item[ 'quantity' ] * $pack_quantity;
                    $branding_array [ 'count' ] += $quantity;
                    $branding_array [ 'items' ][ $cart_item[ 'brand' ][ 'type' ] ][ 'count' ] += $quantity;

            }
        }

        $_productID = $cart_item['product_id'];
        $_itemtotal = $cart_item['line_total'];
       
        $categories = get_the_terms( $_productID, 'product_cat' );
        $finalarraytocheck = array();
        foreach ( $categories as $category ) {
            $finalarraytocheck[] = $category->name;
            
        }
        if(in_array('Volumes',$finalarraytocheck)){
            if(isset($cat_array['Volumes'])){
                $cat_array['Volumes']['total'] += $_itemtotal;
            }else{
                $cat_array['Volumes']['total'] = $_itemtotal;
            }
        }
        if(in_array('Holds',$finalarraytocheck)){
            if(isset($cat_array['Holds'])){
                $cat_array['Holds']['total'] += $_itemtotal;
            }else{
                $cat_array['Holds']['total'] = $_itemtotal;
            }
        }
        if(in_array('Macros',$finalarraytocheck)){
            if(isset($cat_array['Macros'])){
                $cat_array['Macros']['total'] += $_itemtotal;
            }else{
                $cat_array['Macros']['total'] = $_itemtotal;
            }
        }
        if(in_array('Training',$finalarraytocheck)){
            if(isset($cat_array['Training'])){
                $cat_array['Training']['total'] += $_itemtotal;
            }else{
                $cat_array['Training']['total'] = $_itemtotal;
            }
        }



    }
   // echo '<pre>'; print_r($cat_array); echo '</pre>';
    
    if( $branding_array [ 'count' ] ){
        if( $total < $branding_limit ){
            $total_per_piece = 0;
            foreach( $branding_array[ 'items' ] as $branding_item ){
                if( $branding_item[ 'count' ] ){
                    WC()->cart->add_fee( $branding_item[ 'title' ], $branding_item[ 'price' ]);
                    $total_per_piece += $branding_item[ 'count' ] * (double)$branding_item[ 'piece' ];
                }
            }
            if( $total_per_piece ){
                WC()->cart->add_fee( 'Branding items', $total_per_piece );
            }
        }else{
            WC()->cart->add_fee( 'Branding fee', 0 );
        }
    }
    // -----Make Condition Special Discount
    $bulkdiscount_value = isset($_COOKIE['bulkdiscount']) ? $_COOKIE['bulkdiscount'] : '';
    global $totalvallue;
    if($bulkdiscount_value == 'removed'){
        $fees = WC()->cart->get_fees();
        foreach ($fees as $key => $fee) {
            $label_Name = $fees[$key]->name;
            $matches = 'Bold Discount';
            if (preg_match("/\b{$matches}\b/", $label_Name)) {
                unset($fees[$key]);
                setcookie('bulkdiscount', 'removed', 0, '/');
                break;
            }
            
        }
        $all_cat_total = 0;
        if($cat_array){
            foreach($cat_array as $key=>$val){
                $all_cat_total = $all_cat_total + $val['total'];
            }
        }
        $totalvallue = $all_cat_total;
        
    }
    else{
        $all_cat_total = 0;
        $fromreachAmount = 0;
        $OnePercetage = get_option( "dkabz_cart_discount_25_5k" ) ? get_option( "dkabz_cart_discount_25_5k" ) : 0;
        $TwoPercetage = get_option( "dkabz_cart_discount_5k_7500" ) ? get_option( "dkabz_cart_discount_5k_7500" ) : 0;
        $ThreePercetage = get_option( "dkabz_cart_discount_7500_10k" ) ? get_option( "dkabz_cart_discount_7500_10k" ) : 0;
        $FourPercetage = get_option( "dkabz_cart_discount_10K_15k" ) ? get_option( "dkabz_cart_discount_10K_15k" ) : 0;
        $FivePercetage = get_option( "dkabz_cart_discount_above_15k" ) ? get_option( "dkabz_cart_discount_above_15k" ) : 0;
        if($cat_array){
        foreach($cat_array as $key=>$val){
                $all_cat_total = $all_cat_total + $val['total'];
            }
        }
        if($all_cat_total != 0){
            $finalpercetagediscounted = 0;
            $finaldiscounttitle = '';
            $percentageAmount = 0;
            if($isWholesaleCustomer){
                if($all_cat_total >= 15000){
                    $fromreachAmount =  150000 - $all_cat_total;
                    $percentageAmount = 15;
                    $finalpercetagediscounted = $FivePercetage;
                    $finaldiscounttitle = 'Bold Discount: 15k -5% off';
                }
                elseif($all_cat_total >= 10000 && $all_cat_total < 15000){
                    $fromreachAmount =  15000 - $all_cat_total;
                    $finalpercetagediscounted = $FourPercetage;
                    $percentageAmount = 10;
                    $finaldiscounttitle = 'Bold Discount: 10k -4% off';
                }
                elseif($all_cat_total >= 7500 && $all_cat_total < 10000){
                    $fromreachAmount = 10000 - $all_cat_total;
                    $finalpercetagediscounted = $ThreePercetage;
                    $percentageAmount = 7.5;
                    $finaldiscounttitle = 'Bold Discount: 7.5k -3% off';
                }
                elseif($all_cat_total >= 5000 && $all_cat_total < 7500){
                    $fromreachAmount = 7500 - $all_cat_total;
                    $finalpercetagediscounted = $TwoPercetage;
                    $percentageAmount = 5;
                    $finaldiscounttitle = 'Bold Discount: 5k -2% off';
                }
                elseif($all_cat_total >= 2500 && $all_cat_total < 5000){
                    $fromreachAmount = 5000 - $all_cat_total;
                    $finalpercetagediscounted = $OnePercetage;
                    $percentageAmount = 2.5;
                    $finaldiscounttitle = 'Bold Discount: 2.5k -1% off';
                }
                else{
                    $fromreachAmount = 2500 - $all_cat_total;
                    setcookie('bulkdiscount', '', 0, '/');
                }
            }
            else{
               
            }
            global $SpecialDiscountAmount, $SpecialPercentagAmount, $FinalDiscountedCartAmount, $FinalitemtotalAmount;
            $FinalDiscountedCartAmount = $fromreachAmount;
            if($finalpercetagediscounted != 0){
                $SpecialDiscountAmount = $finalpercetagediscounted;
                $SpecialPercentagAmount = $percentageAmount;
                $FinalDiscountedCartAmount = $fromreachAmount;
                $FinalitemtotalAmount = $all_cat_total;
                $discountedValue = $all_cat_total * $finalpercetagediscounted/100;
                $finalvaluetodis = $discountedValue;
                WC()->cart->add_fee( $finaldiscounttitle, -$finalvaluetodis );
                setcookie('bulkdiscount', 'add', 0, '/');

            }
                
                
        }
    }

});

function mycustompage(){
    global $SpecialDiscountAmount, $SpecialPercentagAmount, $FinalDiscountedCartAmount, $FinalitemtotalAmount, $totalvallue;
    echo '<div class="final_special_cart_discount" style="display:none">
            <input type"hidden" class="discountedAmount" name="discountedAmount" data-percentage="'.$SpecialDiscountAmount.'">
            <input type"hidden" class="percentageAmount" name ="percentageAmount" data-amount="'.$SpecialPercentagAmount.'">
            <input type"hidden" class="cartAmount" name="cartAmount" data-cartamount="'. $FinalDiscountedCartAmount .'">
            <input type"hidden" class="totalcartAmount" name="totalcartAmount" data-totalartamount="'. $FinalitemtotalAmount .'">
            <span class="label">Bold Discount: '.$SpecialPercentagAmount.'k -'.$SpecialDiscountAmount.'% off <span class="discountlable">Only applies to holds, macros, volumes & training products after any other discounts are applied</span></span>
            <input type="hidden" class="hiddenvalue" name="totalvalue" data-val="'.$totalvallue.'">
          </div>';
}
add_action('woocommerce_after_cart_totals', 'mycustompage');


// ----- Add this text “Costs for importing and GST “Importing/GST Fee”
add_action('woocommerce_cart_calculate_fees', function() {
    if (is_admin() && !defined('DOING_AJAX')) {
        return;
    }
    // MX
    // --- For Canada
    $Fee_amount = get_option("importing_gst_fee") ? get_option("importing_gst_fee") : 0;
    $Fee_percentage_products = get_option("total_product_percentage_importing_gst_fee") ? get_option("total_product_percentage_importing_gst_fee") : 0;
    // ----For Maxico
    $Fee_amount_mx = get_option("importing_gst_fee_mexico") ? get_option("importing_gst_fee_mexico") : 0;
    $Fee_percentage_products_mx = get_option("total_product_percentage_importing_gst_fee_mexico") ? get_option("total_product_percentage_importing_gst_fee_mexico") : 0;
    $cart = WC()->cart;
    global $woocommerce;
    $total = $cart->get_cart_contents_total();

    $final_total_fees = $Fee_amount + ($Fee_percentage_products / 100) * $total;
    
    $shipping_country = WC()->customer->get_shipping_country();
    if ($shipping_country === 'CA') {
        $bold_customers_outside = isset($_GET['bold_customers_outside']) ? wc_clean($_GET['bold_customers_outside']) : '';
        $bold_customers_outside = WC()->session->get('bold_customers_outside');
         if ($bold_customers_outside === 'bold') {
             $custom_fee = $final_total_fees;         
		 }
         else {
            $custom_fee = 0;
        }
    }else if($shipping_country === 'MX'){
        $final_total_fees = $Fee_amount_mx + ($Fee_percentage_products_mx / 100) * $total;
        $bold_customers_outside = WC()->session->get('bold_customers_outside');
         if ($bold_customers_outside === 'bold') {
             $custom_fee = $final_total_fees;         
		 }
         else {
            $custom_fee = 0;
        }
    }
    else {
        $custom_fee = 0;
    }
    

    if ($custom_fee > 0) {
      $cart->add_fee(__('Importing/GST Fee', 'txtdomain'), $custom_fee);
    }else{
        $fees = $cart->get_fees();
        foreach ($fees as $key => $fee) {
            if ($fee->name == 'Importing/GST Fee') {
                unset($cart->fees_api()->fees[$key]);
            }
        }
    }
});

// Mtech Update order Review  “Importing/GST Fee”
add_action('woocommerce_checkout_update_order_review', 'update_bold_customers_outside_session_fun');
function update_bold_customers_outside_session_fun($posted_data) {
    parse_str($posted_data, $output);
    if (isset($output['bold_customers_outside'])) {
        WC()->session->set('bold_customers_outside', $output['bold_customers_outside']);
    }
}


// Save cart item custom meta as order item meta data and display it everywhere on orders and email notifications.
add_action( 'woocommerce_checkout_create_order_line_item', 'save_cart_item_custom_meta_as_order_item_meta', 10, 4 );
function save_cart_item_custom_meta_as_order_item_meta( $item, $cart_item_key, $values, $order ) {

    $product_id = $item->get_product_id();
    $cats = get_the_terms ( $product_id, 'product_cat' );
    $brand_value = "";
    foreach ( $cats as $cat ) {
        $cat_id = $cat->term_id;
        $brand = get_term_meta( $cat_id , 'bold_product_brand', true );
        if( $brand == "Yes" ){
            $brand_value = $cat->name;
        }
    }
    if( $brand_value ){
        //$item->update_meta_data( 'Brand', $brand_value );
    }
    /* Gaurav 29 Aug 2023 */
    $custom_brand = get_post_meta($product_id, 'product_brand', true);
    if( $custom_brand ){
        $item->update_meta_data( 'Brand', $custom_brand );
    }
    /* --21--Oct-23 */
    $tax = get_the_terms($product_id,'product_cat');
    $isfamily = '';
    foreach($tax as $familyline){
        $family = get_term_meta($familyline->term_id,'bold_product_line', true);
        if( $family == 'Yes' ){
            $isfamily =  $familyline->name;
        }
    }
    if( $isfamily ){
        $item->update_meta_data( 'Line', $isfamily );
    }

    $manufacturer = get_post_meta($product_id, 'bold_product_manufacturer', true);
    if($manufacturer){
        $item->update_meta_data( 'Manufacturer', $manufacturer );
    }
    
    /* The End */
    if( isset( $values[ 'brand' ][ 'type' ] ) ){
        $item->update_meta_data( 'Branding', $values[ 'brand' ][ 'type' ] );
    }
}

//Showing shipping type at the backend
function actionCheckoutCreateOrderShippingItem( $item, $package_key, $package, $order ){
    $pack_name_array = explode("<span", $package['name'] );
    if( $pack_name_array ){
        $pack_name = $pack_name_array[ 0 ];
    }else{
        $pack_name = $package['name'];
    }
    if($package['destination']['weight']){
        $pack_name_new = $pack_name.' = Weight : '.$package['destination']['weight'];
    }
    else{
        $pack_name_new = $pack_name; 
    }
   
   // $item->update_meta_data( 'Shipping', $pack_name );
    $item->update_meta_data( 'Shipping', $pack_name_new );
}
add_action( 'woocommerce_checkout_create_order_shipping_item', 'actionCheckoutCreateOrderShippingItem', 10, 4 );


/*
Remove recalculation of shipping cost when Add-to-Cart. This prevents slow add-to-cart.

function filter_need_shipping ( $val ) {
    if(!is_admin()){
        $prevent_after_add = WC()->cart->prevent_recalc_on_add_to_cart;
        return $val && !$prevent_after_add;
    }
    return false;
}
add_filter( 'woocommerce_cart_needs_shipping', 'filter_need_shipping' );

function mark_cart_not_to_recalc ( $cart_item_key, $product_id, $quantity, $variation_id, $variation, $cart_item_data ) {
    WC()->cart->prevent_recalc_on_add_to_cart = true;
}
add_action( 'woocommerce_add_to_cart', 'mark_cart_not_to_recalc', 10, 6 );
/** */

function filter_need_shipping($val) {
    $prevent_after_add = (isset(WC()->cart->prevent_recalc_on_add_to_cart)) ? true : false;
    return $val && !$prevent_after_add;
}
add_filter('woocommerce_cart_needs_shipping', 'filter_need_shipping');
function mark_cart_not_to_recalc($cart_item_key, $product_id, $quantity, $variation_id, $variation, $cart_item_data) {
    WC()->cart->prevent_recalc_on_add_to_cart = true;
}
add_action('woocommerce_add_to_cart', 'mark_cart_not_to_recalc', 10, 6);


add_filter( 'woocommerce_single_product_carousel_options', 'sf_update_woo_flexslider_options' );
/**
 * Filer WooCommerce Flexslider options - Add Navigation Arrows
 */
function sf_update_woo_flexslider_options( $options ) {

    $options[ 'directionNav' ] = true;

    return $options;
}
/*
add_filter( 'woocommerce_available_payment_gateways', 'hide_gateways' );
function hide_gateways( $available_gateways ) {
    if( isset( WC()->cart->total ) ){
        if ( WC()->cart->total > '2000' ) {
            unset( $available_gateways[ 'stripe_cc' ] );
            unset( $available_gateways[ 'stripe_applepay' ] );
            unset( $available_gateways[ 'stripe_googlepay' ] );
        }
    }
    return $available_gateways;
}
*/
function theme_enqueue_styles() {

    if( function_exists( 'ws_scripts_in_footer' ) ) {
        $footer = ws_scripts_in_footer();
    } else {
        $footer = false;
    }

    wp_enqueue_style( 'compiled-css', get_stylesheet_directory_uri() . '/includes/css/compiled.css', array( 'bootstrap-css', 'font-awesome' ) );
    wp_enqueue_style( 'child-css', get_stylesheet_directory_uri() . '/style.css', array( 'compiled-css' ) );
    wp_enqueue_style( 'customizing-css', get_template_directory_uri() . '/includes/css/bold-customizing-css.css', array( 'custom-css',) );
   

    wp_enqueue_script( 'compiled-js', get_stylesheet_directory_uri() . '/includes/js/compiled.js', array( 'jquery' ), '', $footer );
    wp_enqueue_script( 'cookie-js', get_stylesheet_directory_uri() . '/includes/js/jquery.cookie.js', array( 'jquery' ), '', $footer );

    if( is_page_template( 'template-product-category.php') ){
        wp_enqueue_script( 'ui-slider', get_stylesheet_directory_uri() . '/includes/js/ui-slider.js', array( 'compiled-js' ), '', $footer );
        wp_enqueue_script( 'child-js', get_stylesheet_directory_uri() . '/includes/js/child.js', array( 'ui-slider' ), '', $footer );
    }else{
        wp_enqueue_script( 'child-js', get_stylesheet_directory_uri() . '/includes/js/child.js', array( 'compiled-js' ), '', $footer );
    }

    wp_localize_script( 'child-js', 'my_ajax_object', array( 'ajax_url' => admin_url( 'admin-ajax.php' ) ) );

    
    if( is_product() ){

        wp_enqueue_script( 'threesixty-js', get_stylesheet_directory_uri() . '/includes/js/threesixty.js', array( 'compiled-js' ), '', $footer );

    }
    

}



add_action( 'wp_enqueue_scripts', 'theme_enqueue_styles', 12 );


/* ADD YOUR CUSTOM FUNCTIONS BELOW */

/*** CUSTOM POST TYPE FOR COLORS ***/

/*** CMB2 ***/

// register car listing post type

function register_bold_summary_type_post_type() {

    $labels = array(
        'name'                  => _x( 'Bold Summary Type', 'post type general name', 'previews-textdomain' ),
        'singular_name'         => _x( 'Bold Summary Type', 'post type singular name', 'previews-textdomain' ),
        'menu_name'             => _x( 'Bold Summary Types', 'admin menu', 'previews-textdomain' ),
        'name_admin_bar'        => _x( 'Bold Summary Types', 'add new on admin bar', 'previews-textdomain' ),
        'add_new'               => _x( 'Add Bold Summary Type', 'previews', 'previews-textdomain' ),
        'add_new_item'          => __( 'Add New Bold Summary Typeg', 'previews-textdomain' ),
        'new_item'              => __( 'New Bold Summary Type', 'previews-textdomain' ),
        'edit_item'             => __( 'Edit Bold Summary Type', 'previews-textdomain' ),
        'view_item'             => __( 'View Bold Summary Type', 'previews-textdomain' ),
        'all_items'             => __( 'All Bold Summary Types', 'previews-textdomain' ),
        'search_items'          => __( 'Search Bold Summary Types', 'previews-textdomain' ),
        'parent_item_colon'     => __( 'Parent Bold Summary Type:', 'previews-textdomain' ),
        'not_found'             => __( 'No Bold Summary Type found.', 'previews-textdomain' ),
        'not_found_in_trash'    => __( 'No Bold Summary Type found in Trash.', 'previews-textdomain' )
    );

    $args = array(
        'labels'                => $labels,
        'description'           => __( 'Bold Summary Type', 'previews-textdomain' ),
        'public'                => true,
        'menu_icon'             => 'dashicons-admin-post',
        'taxonomies'            => array('post_tag'),
        'publicly_queryable'    => true,
        'show_ui'               => true,
        'show_in_menu'          => true,
        'show_in_rest'          => true,
        'query_var'             => true,
        'rewrite'               => array( 'slug' => 'bold-summary-type' ),
        'capability_type'       => 'post',
        'has_archive'           => true,
        'hierarchical'          => true,
        'menu_position'         => null,
        'supports'              => array( 'title', 'editor', 'author', 'thumbnail', 'excerpt', 'post-formats' )
    );

    register_post_type( 'bold-summary-type', $args );

}

add_action( 'init', 'register_bold_summary_type_post_type' );

function add_bold_summary_post_type_meta(){

    $cmb_user = new_cmb2_box( array(
        'id'            => 'additional_bold_summary_type_meta',
        'title'         => __( 'Additional Page Meta', 'cmb2' ),
        'object_types'  => array( 'bold-summary-type' ), // Tells CMB2 to use user_meta vs post_meta
        'show_names'    => true,
    ));

    $cmb_user->add_field( array(
        'name'         => __( 'Colors', 'cmb2' ),
        'id'           => 'bold_summary_type_colors',
        'description'  => 'Comma separated list of simple colors, add "DUAL TEX" if dual tex',
        'type'         => 'text',
    ));

}

add_action( 'cmb2_init' , 'add_bold_summary_post_type_meta' );


/*** END CUSTOM POST TYPE FOR COLORS ***/

// fix terms filter

// Step 1. Add the filters surrounding the get_terms (which should be used in your code)

add_filter( 'terms_pa_color', 'rs_replace_inner_with_straight_joins', 20 );
//$terms = get_terms( $args );
remove_filter( 'terms_pa_color', 'rs_replace_inner_with_straight_joins', 20 );

// Step 2. Add to functions.php or similar:
function rs_replace_inner_with_straight_joins( $pieces, $taxonomies = null, $args = null ) {
    global $wpdb;

    $s = 'INNER JOIN ' . $wpdb->prefix;
    $r = 'STRAIGHT_JOIN ' . $wpdb->prefix;
    $pieces['join'] = str_replace( $s, $r, $pieces['join'] );

    return $pieces;
}



/**
 * @snippet       Disable WooCommerce Ajax Cart Fragments Everywhere
 * @how-to        Get CustomizeWoo.com FREE
 * @author        Rodolfo Melogli
 * @compatible    WooCommerce 3.6.4
 * @donate $9     https://businessbloomer.com/bloomer-armada/
 */

add_action( 'wp_enqueue_scripts', 'bbloomer_disable_woocommerce_cart_fragments', 11 );

function bbloomer_disable_woocommerce_cart_fragments() {
    wp_dequeue_script( 'wc-cart-fragments' );
}

/*** login page redirects ***/

function redirect_logged_in_user(){
    if( is_user_logged_in() && ( is_page( 46 ) || is_page( 44 ) ) ){
        wp_redirect( get_permalink( 9 ) );
        exit;
    }
}

add_action('template_redirect', 'redirect_logged_in_user');

/*** end login page redirects ***/

/*** separate registration page ***/

function wd_separate_registration_form() {
    if ( is_admin() ) return;
    if ( is_user_logged_in() ) return;
    ob_start();

    // NOTE: THE FOLLOWING <FORM></FORM> IS COPIED FROM woocommerce\templates\myaccount\form-login.php
    // IF WOOCOMMERCE RELEASES AN UPDATE TO THAT TEMPLATE, YOU MUST CHANGE THIS ACCORDINGLY

    do_action( 'woocommerce_before_customer_login_form' );

    ?>
    <form method="post" class="woocommerce-form woocommerce-form-register register" <?php do_action( 'woocommerce_register_form_tag' ); ?> >

        <?php do_action( 'woocommerce_register_form_start' ); ?>

        <?php if ( 'no' === get_option( 'woocommerce_registration_generate_username' ) ) : ?>

            <p class="woocommerce-form-row woocommerce-form-row--wide form-row form-row-wide">
                <label for="reg_username"><?php esc_html_e( 'Username', 'woocommerce' ); ?> <span class="required">*</span></label>
                <input type="text" class="woocommerce-Input woocommerce-Input--text input-text" name="username" id="reg_username" autocomplete="username" value="<?php echo ( ! empty( $_POST['username'] ) ) ? esc_attr( wp_unslash( $_POST['username'] ) ) : ''; ?>" /><?php // @codingStandardsIgnoreLine ?>
            </p>

        <?php endif; ?>

        <p class="woocommerce-form-row woocommerce-form-row--wide form-row form-row-wide">
            <label for="reg_email"><?php esc_html_e( 'Email address', 'woocommerce' ); ?> <span class="required">*</span></label>
            <input type="email" class="woocommerce-Input woocommerce-Input--text input-text" name="email" id="reg_email" autocomplete="email" value="<?php echo ( ! empty( $_POST['email'] ) ) ? esc_attr( wp_unslash( $_POST['email'] ) ) : ''; ?>" /><?php // @codingStandardsIgnoreLine ?>
        </p>

        <?php if ( 'no' === get_option( 'woocommerce_registration_generate_password' ) ) : ?>

            <p class="woocommerce-form-row woocommerce-form-row--wide form-row form-row-wide">
                <label for="reg_password"><?php esc_html_e( 'Password', 'woocommerce' ); ?> <span class="required">*</span></label>
                <input type="password" class="woocommerce-Input woocommerce-Input--text input-text" name="password" id="reg_password" autocomplete="new-password" />
            </p>

        <?php else : ?>

            <p><?php esc_html_e( 'A password will be sent to your email address.', 'woocommerce' ); ?></p>

        <?php endif; ?>

        <?php do_action( 'woocommerce_register_form' ); ?>

        <p class="woocommerce-FormRow form-row">
            <?php wp_nonce_field( 'woocommerce-register', 'woocommerce-register-nonce' ); ?>
            <button type="submit" class="woocommerce-Button woocommerce-button button woocommerce-form-register__submit" name="register" value="<?php esc_attr_e( 'Register', 'woocommerce' ); ?>"><?php esc_html_e( 'Register', 'woocommerce' ); ?></button>
        </p>

        <?php do_action( 'woocommerce_register_form_end' ); ?>

    </form>

    <?php

    return ob_get_clean();
}

add_shortcode( 'wc_reg_form_websitedepot', 'wd_separate_registration_form' );
function get_brand($id){

    $tax = get_the_terms($id,'product_cat');

    foreach($tax as $item){
        $brand = get_term_meta($item->term_id,'bold_product_brand', true);

        if( $brand == 'Yes' ){
            return $item->name;
        }
    }

}

function get_brand_id($id){

    $tax = get_the_terms($id,'product_cat');

    foreach($tax as $item){
        $brand = get_term_meta($item->term_id,'bold_product_brand', true);

        if( $brand == 'Yes' ){
            return $item->term_id;
        }
    }

}

function get_manufacturer($id){

    $tax = get_the_terms($id,'product_cat');
    foreach($tax as $item){
        $manufacturer = get_term_meta($item->term_id,'bold_product_manufacturer', true);
        if( $manufacturer == 'Yes' ){
            return $item->name;
        }
    }

}

function get_family($id){

    $tax = get_the_terms($id,'product_cat');
    foreach($tax as $item){
        $family = get_term_meta($item->term_id,'bold_product_line', true);
        if( $family == 'Yes' ){
            return $item->name;
        }
    }
}

function get_family_ID($id){

    $tax = get_the_terms($id,'product_cat');
    foreach($tax as $item){
        $family = get_term_meta($item->term_id,'bold_product_line', true);
        if( $family == 'Yes' ){
            return $item->term_id;
        }
    }
}

function get_color_terms($id){

    $tax = wc_get_product_terms( $id, 'pa_color' );
    $brand_id = get_brand_id($id);
    $color_order = explode(', ', get_term_meta($brand_id, 'bold_color_order', true ));

    $sortable_array = array();
    $count = 0;

    foreach( $color_order as $color ){

        foreach( $tax as $item ){

            $color_name = $item->name;

            // remove black gloss

            $color_name = str_replace(' / Black Gloss', '', $color_name);

            $standard = get_term_meta($item->term_id,'bold_product_color_dual_texture', true);

            // standard colors

            if( strpos( $color_name, $color ) !== false ){

                $sortable_array[$count] = $item;

            }

            // dual texture colors

            if( $standard == 'Yes' ){

                $dual_tex = str_replace( 'Dual Tex', '', $color );

                if( strpos( $color_name, $dual_tex ) !== false ){

                    $sortable_array[$count] = $item;

                }

            }


        }

        $count++;

    }

    ksort($sortable_array);

    return $sortable_array;

}

function display_family_products($id){

    $family_id = get_family_ID($id);

    $args = array(
        'post_type' => 'product',
        'posts_per_page' => 5,
        'tax_query' => array(
            array(
                'field' => 'term_id',
                'taxonomy' => 'product_cat',
                'terms' => $family_id
            )
        )
    );

    $family_products = get_posts($args);

    $output = '';

    $output .= '<div class="product-container">';

    foreach( $family_products as $family_product ){

        $_product = wc_get_product($family_product->ID);
        $product_size = get_post_meta($family_product->ID, 'bold_product_size', true);

        // check if product is a variable product
        if( $_product->is_type( 'variable' ) ) {
            $product_price = $_product->get_variation_price();
        }else{
            $product_price = $_product->get_price();
        }

        $featured_img = get_the_post_thumbnail_url($family_product,'thumbnail');

        if( $featured_img == '' ){
            $featured_img = wp_get_attachment_url(34169);
        }

        $output .= '<div class="product-wrapper">';
        $output .= '<a class="product-image" href="' . get_permalink($family_product->ID) . '"><img alt="' . $family_product->post_title . '" src="' . $featured_img . '"/></a>';
        $output .= '<h3>' . $family_product->post_title . '</h3>';

        $output .= '<div class="price-wrapper">';

        if( $product_size != '' ){
            $output .= '<span class="product-size">' . $product_size . ' &#8226; </span> ';
        }


        $output .= '<span class="product-price">$' . $product_price . '</span>';
        $output .= '</div>';

        $output .= '<a class="add-to-cart-btn" href="' . get_permalink($family_product->ID) . '">Add to Cart</a>';
        $output .= '</div>';
    }

    $output .= '</div>';

    return $output;

}

function display_related_products($id){

    $related_products = wc_get_related_products( $id, '8' );

    $output = '';

    $output .= '<div class="product-container">';

    foreach( $related_products as $product ){
        $product_post = get_post($product);
        $_product = wc_get_product($product);
        $product_size = get_post_meta($product, 'bold_product_size', true);

        // check if product is a variable product
        if( $_product->is_type( 'variable' ) ) {
            $product_price = $_product->get_variation_price();
        }else{
            $product_price = $_product->get_price();
        }

        $featured_img = get_the_post_thumbnail_url($product,'thumbnail');

        if( $featured_img == '' ){
            $featured_img = wp_get_attachment_url(34169);
        }

        $output .= '<div class="product-wrapper">';
        $output .= '<a class="product-image" href="' . get_permalink($product) . '"><img alt="' . $product_post->post_title . '" src="' . $featured_img . '"/></a>';
        $output .= '<h3>' . $product_post->post_title . '</h3>';

        $output .= '<div class="price-wrapper">';

        if( $product_size != '' ){
            $output .= '<span class="product-size">' . $product_size . ' &#8226; </span> ';
        }

        $output .= '<span class="product-price">$' . $product_price . '</span>';
        $output .= '</div>';

        $output .= '<a class="add-to-cart-btn" href="' . get_permalink($product) . '">Add to Cart</a>';
        $output .= '</div>';
    }

    $output .= '</div>';

    return $output;

}

function get_type($id){

    $tax = get_the_terms($id,'product_cat');
    foreach($tax as $item){

        $type = get_term_meta($item->term_id,'bold_product_type', true);
        if( $type == 'Yes' ){
            return $item->name;
        }
    }
}

function get_product_types(){

    $sortable_array = array( '12' => 'Holds', '66' => 'Macros', '64' => 'Volumes', '34175' => 'Training' );

    return $sortable_array;

}

function get_related_colors($color){

    $args = array(
        'taxonomy' => 'pa_color',
        'hide_empty' => false
    );

    $tax = get_terms($args);
    $sortable_array = array();

    foreach( $tax as $item ){

        $standard = get_term_meta( $item->term_id, 'bold_product_color_dual_texture', true );

        foreach( $color as $chosen ){

            $dual_texture = str_replace(' Dual Tex', '', $chosen);

            if( strpos( $item->name, $dual_texture ) !== false ){

                if( strpos( $chosen, 'Dual Tex' ) !== false  ){
                    $dual_texture_color = $dual_texture;
                    $sortable_array[] = $dual_texture_color;
                }elseif( strpos( $chosen, 'Dual Tex' ) === false ){
                    $sortable_array[] = $item->name;
                }

            }

        }

    }

    return $sortable_array;

}
function get_related_colors_slug($color){
    $args = array(
        'taxonomy' => 'pa_color',
        'hide_empty' => false
    );
    $tax = get_terms($args);
    $sortable_array = array();
    foreach( $tax as $item ){
        foreach( $color as $key=>$chosen ){
            $dual_texture = str_replace(' Dual Tex', '', $chosen);
            if( strpos( $item->name, $dual_texture ) !== false ){
                $sortable_array[] = $item->slug;
            }
        }
    }
    return $sortable_array;
}
function get_size_names(){

//    $args = array(
//        'post_type' => 'product',
//        'hide_empty' => false,
//        'posts_per_page' => -1
//    );
//
//    $tax = get_posts($args);
//    $sortable_array = array();
//
//    foreach( $tax as $item ){
//        $size = get_post_meta($item->ID,'bold_product_size', true );
//        if( $size != '' ){
    //
//            $sortable_array[$key] = $size;

//        }
//    }
//
//    $sortable_array = array_unique($sortable_array);
    // sort($sortable_array);

    $sortable_array = array('X-Small', 'Small', 'Medium', 'Large', 'X-Large', 'Giant');

    return $sortable_array;
}

function get_variation_stock($color,$product){

    // global $product;

    $color_name = $color->slug;

    $product = wc_get_product($product);

    $variations = $product->get_available_variations();

    foreach($variations as $variation){
        $variation_id = $variation['variation_id'];
        $variation_obj = new WC_Product_variation($variation_id);

        $variation_attributes = $variation_obj->get_variation_attributes();
        $variation_name = $variation_attributes['attribute_pa_color'];

        $stock = $variation_obj->get_stock_quantity();

        if( $color_name == $variation_name ){
            return $stock;
        }

    }

}

function get_variation_id_by_color($color,$product){
    //global $product;

    $product = wc_get_product($product);
    $color_name = $color->slug;
    $variations = $product->get_available_variations();

    foreach($variations as $variation){
        $variation_id = $variation['variation_id'];
        $variation_obj = new WC_Product_variation($variation_id);

        $variation_attributes = $variation_obj->get_variation_attributes();
        $variation_name = $variation_attributes['attribute_pa_color'];

        if( $color_name == $variation_name ){
            return $variation_id;
        }

    }
}

function get_variation_id_by_best_color($color,$product){



    $variations = $product->get_available_variations();

    foreach($variations as $variation){
        $variation_id = $variation['variation_id'];
        $variation_obj = new WC_Product_variation($variation_id);

        $variation_attributes = $variation_obj->get_variation_attributes();
        ws_test($variation_attributes);

        $variation_name = $variation_attributes['attribute_pa_color'];

        ws_test($color);
        ws_test($variation_name);

        if( strpos($color, $variation_name ) !== false ){
            return $variation_id;
        }

    }
}


/*** CUSTOM WHOLESELLER META ***/

function add_wholesale_cmb2_meta(){

    $cmb_user = new_cmb2_box(array(
        'id' => 'additional_user_meta',
        'title' => __('Additional Wholesale User Meta', 'cmb2'),
        'object_types' => array('user'), // Tells CMB2 to use user_meta vs post_meta
        'show_names' => true,
    ));
    /*
    $cmb_user->add_field(array(
         'name' => __('Is this a wholesale user?', 'cmb2'),
         'id' => 'bold_wholesale_account',
         'type'    => 'radio_inline',
         'options' => array(
             'No' => __( 'No', 'cmb2' ),
             'Yes' => __( 'Yes', 'cmb2' ),
         )
     ));
     */

    $cmb_user->add_field(array(
        'name' => __("Deposit", 'cmb2'),
        'id' => 'bold_deposit_type',
        'type'             => 'radio',
        'show_option_none' => false,
        'options'          => array(
            'default'   => __( 'No terms - default', 'cmb2' ),
            'deposit1'  => __( '50/50 Terms', 'cmb2' ),
            'deposit2'  => __( '0/100 Terms', 'cmb2' ),
        ),
        'default' => 'default',
    ));

    $cmb_user->add_field(array(
        'name' => __("Retail manager's name", 'cmb2'),
        'id' => 'bold_wholesale_retails_manager_name',
        'type'    => 'text',
    ));

    $cmb_user->add_field(array(
        'name' => __("Retail manager's email", 'cmb2'),
        'id' => 'bold_wholesale_retails_manager_email',
        'type'    => 'text',
    ));
    $cmb_user->add_field(array(
        'name' => __("Head Setter's name", 'cmb2'),
        'id' => 'bold_wholesale_head_setters_name',
        'type'    => 'text',
    ));
    $cmb_user->add_field(array(
        'name' => __("Head Setter's email", 'cmb2'),
        'id' => 'bold_wholesale_head_setters_email',
        'type'    => 'text',
    ));
    $cmb_user->add_field(array(
        'name' => __('Business Name', 'cmb2'),
        'id' => 'bold_wholesale_business_name',
        'type'    => 'text',
    ));

    $cmb_user->add_field(array(
        'name' => __('Business Street Address', 'cmb2'),
        'id' => 'bold_wholesale_street_address',
        'type'    => 'text',
    ));

    $cmb_user->add_field(array(
        'name' => __('Business Street Address 2', 'cmb2'),
        'id' => 'bold_wholesale_street_address_two',
        'type'    => 'text',
    ));

    $cmb_user->add_field(array(
        'name' => __('Business City', 'cmb2'),
        'id' => 'bold_wholesale_city',
        'type'    => 'text',
    ));

    $cmb_user->add_field(array(
        'name' => __('Business Zipcode', 'cmb2'),
        'id' => 'bold_wholesale_zip',
        'type'    => 'text',
    ));

    $cmb_user->add_field(array(
        'name' => __('Business Website', 'cmb2'),
        'id' => 'bold_wholesale_website',
        'type'    => 'text',
    ));

    $cmb_user->add_field(array(
        'name' => __('Business Phone 1', 'cmb2'),
        'id' => 'bold_wholesale_phone_one',
        'type'    => 'text',
    ));

    $cmb_user->add_field(array(
        'name' => __('Business First Name', 'cmb2'),
        'id' => 'bold_wholesale_first_name',
        'type'    => 'text',
    ));

    $cmb_user->add_field(array(
        'name' => __('Business Last Name', 'cmb2'),
        'id' => 'bold_wholesale_last_name',
        'type'    => 'text',
    ));

    $cmb_user->add_field(array(
        'name' => __('Title/Position in Business', 'cmb2'),
        'id' => 'bold_wholesale_title',
        'type'    => 'text',
    ));

    $cmb_user->add_field(array(
        'name' => __('Business Phone 2', 'cmb2'),
        'id' => 'bold_wholesale_phone_two',
        'type'    => 'text',
    ));

    $cmb_user->add_field(array(
        'name' => __('Business Email', 'cmb2'),
        'id' => 'bold_wholesale_email',
        'type'    => 'text',
    ));

    /*
     $cmb_user->add_field(array(
        'name' => __("Deposit", 'cmb2'),
        'id' => 'bold_deposit_type',
        'type'             => 'radio',
        'show_option_none' => false,
        'options'          => array(
            'default'   => __( 'No terms - default', 'cmb2' ),
            'deposit1'  => __( '50/50 Terms', 'cmb2' ),
            'deposit2'  => __( '0/100 Terms', 'cmb2' ),
        ),
        'default' => 'default',
    ));

     $cmb_user->add_field(array(
        'name' => __('Business Name', 'cmb2'),
        'id' => 'bold_wholesale_business_name',
        'type'    => 'text',
    ));
    */
    $cmb_user->add_field(array(
        'name' => __("Customers outside of the USA", 'cmb2'),
        'id' => 'bold_customers_outside',
        'type'             => 'radio',
        'show_option_none' => false,
        'options'          => array(
            'bold'      => __( "Use Bold Climbing's customs broker", 'cmb2' ),
            'own'       => __( "Use our own customs broker", 'cmb2' ),
        ),
        'default' => 'bold',
    ));
    $cmb_user->add_field(array(
        'name' => __('Custom broker', 'cmb2'),
        'id' => 'bold_custom_broker',
        'type'    => 'text',
    ));
    $cmb_user->add_field(array(
        'name' => __('Custom broker number', 'cmb2'),
        'id' => 'bold_custom_broker_number',
        'type'    => 'text',
    ));


}

add_action('cmb2_init', 'add_wholesale_cmb2_meta');

/*** CUSTOM TAXONOMY META ***/

function add_taxonomy_cmb2_meta(){

    $cmb_user = new_cmb2_box(array(
        'id' => 'additional_taxonomy_meta',
        'title' => __('Additional Brand Meta', 'cmb2'),
        'object_types' => array('term'), // Tells CMB2 to use user_meta vs post_meta
        'show_names' => true,
        'taxonomies'       => array( 'product_cat', 'post_tag' ),
    ));

    $cmb_user->add_field(array(
        'name' => __('Custom Banner', 'cmb2'),
        'id' => 'bold_custom_banner_image',
        'description' => 'Add custom banner image 1920px by 1080px',
        'type'    => 'file',
    ));

    $cmb_user->add_field(array(
        'name' => __('Subcategory', 'cmb2'),
        'id' => 'bold_branded_category',
        'type'    => 'radio_inline',
        'options' => array(
            'No' => __( 'No', 'cmb2' ),
            'Yes' => __( 'Yes', 'cmb2' ),
        )
    ));

    $cmb_user->add_field(array(
        'name' => __('Brand', 'cmb2'),
        'id' => 'bold_product_brand',
        'description' => 'Blocz, Blue Pill, Art Line, etc',
        'type'    => 'radio_inline',
        'options' => array(
            'No' => __( 'No', 'cmb2' ),
            'Yes' => __( 'Yes', 'cmb2' ),
        )
    ));

    $cmb_user->add_field(array(
        'name' => __('Retail items', 'cmb2'),
        'id' => 'bold_product_retail_items',
        'description' => 'Accesories,training',
        'type'    => 'radio_inline',
        'options' => array(
            'No' => __( 'No', 'cmb2' ),
            'Yes' => __( 'Yes', 'cmb2' ),
        )
    ));
    
    /* Added By Gaurav - 25 Sug 2023 */
    $cmb_user->add_field(array(
        'name' => __('Line', 'cmb2'),
        'id' => 'bold_product_line',
        'description' => '',
        'type'    => 'radio_inline',
        'options' => array(
            'No' => __( 'No', 'cmb2' ),
            'Yes' => __( 'Yes', 'cmb2' ),
        )
    ));
    /* The End */
    
    /*
    $cmb_user->add_field(array(
        'name' => __('Color Order', 'cmb2'),
        'id' => 'bold_color_order',
        'description' => 'Use simple color separated by commas, if dual texture, add "Dual Tex" to end of name, i.e., Red Dual Tex. For colors like Green 16-16 and Neon Green, use exact match.',
        'type'    => 'text',
    ));

    $cmb_user->add_field(array(
        'name' => __('Type', 'cmb2'),
        'id' => 'bold_product_type',
        'description' => 'Volumes, Marcros, Holds, etc',
        'type'    => 'radio_inline',
        'options' => array(
            'No' => __( 'No', 'cmb2' ),
            'Yes' => __( 'Yes', 'cmb2' ),
        )
    ));



    $cmb_user->add_field(array(
        'name' => __('Line', 'cmb2'),
        'id' => 'bold_product_line',
        'description' => 'Triangles, Squares, etc',
        'type'    => 'radio_inline',
        'options' => array(
            'No' => __( 'No', 'cmb2' ),
            'Yes' => __( 'Yes', 'cmb2' ),
        )
    ));

    $cmb_user->add_field(array(
        'name' => __('Manufacturer', 'cmb2'),
        'id' => 'bold_product_manufacturer',
        'description' => 'Blocz, Simpl, 360 etc',
        'type'    => 'radio_inline',
        'options' => array(
            'No' => __( 'No', 'cmb2' ),
            'Yes' => __( 'Yes', 'cmb2' ),
        )
    ));

    $cmb_user->add_field(array(
        'name' => __('Wholesale', 'cmb2'),
        'id' => 'bold_product_wholesale',
        'description' => 'This product category is not available to regular customers',
        'type'    => 'radio_inline',
        'options' => array(
            'No' => __( 'No', 'cmb2' ),
            'Yes' => __( 'Yes', 'cmb2' ),
        )
    ));
   */

    $cmb_user->add_field(array(
        'name'          => __('Standart Color Caption', 'cmb2'),
        'id'            => 'bold_standart_caption',
        'description'   => '',
        'type'          => 'text',
    ));
    $cmb_user->add_field(array(
        'name'          => __('Dual Tex Color Caption', 'cmb2'),
        'id'            => 'bold_dual_caption',
        'description'   => '',
        'type'          => 'text',
    ));
    $cmb_user->add_field(array(
        'name'          => __('Shipping info', 'cmb2'),
        'id'            => 'bold_shipping_info',
        'description'   => '',
        'type'          => 'textarea',
    ));

    $cmb_user->add_field(array(
        'name'          => __('Sort order', 'cmb2'),
        'id'            => 'bold_category_sort_order',
        'description'   => '',
        'type'          => 'text',
    ));

    $cmb_user->add_field(array(
        'name'          => __('Color table', 'cmb2'),
        'id'            => 'bold_colortable_info',
        'description'   => '',
        'type'          => 'wysiwyg',
    ));


}

add_action( 'cmb2_init' , 'add_taxonomy_cmb2_meta' );

function add_page_meta(){

    $cmb_user = new_cmb2_box(array(
        'id' => 'additional_page_meta',
        'title' => __('Additional Page Meta', 'cmb2'),
        'object_types' => array('page'), // Tells CMB2 to use user_meta vs post_meta
        'show_names' => true,
    ));

    $cmb_user->add_field(array(
        'name' => __('Product Category ID', 'cmb2'),
        'id' => 'bold_product_category_id',
        'description' => 'Add ID of product category',
        'type'    => 'text',
    ));

    $cmb_user->add_field(array(
        'name' => __('Banner Title', 'cmb2'),
        'id' => 'bold_line_banner_title',
        'description' => 'Add a custom title to the banner',
        'type'    => 'text',
    ));

    $cmb_user->add_field(array(
        'name' => __('Accessory Page', 'cmb2'),
        'id' => 'bold_product_accessory',
        'description' => 'This is an accesory page with limited filter functionality',
        'type'    => 'radio_inline',
        'options' => array(
            'No' => __( 'No', 'cmb2' ),
            'Yes' => __( 'Yes', 'cmb2' ),
        )
    ));

    $cmb_user->add_field(array(
        'name' => __('Branded Page', 'cmb2'),
        'id' => 'bold_product_branded',
        'description' => 'This is an branded page',
        'type'    => 'radio_inline',
        'options' => array(
            'No' => __( 'No', 'cmb2' ),
            'Yes' => __( 'Yes', 'cmb2' ),
        )
    ));

    $cmb_user->add_field(array(
        'name' => __('H1 Title color', 'cmb2'),
        'id' => 'bold_h1_color',
        'type'    => 'text',
        'default'   => '#fff'
    ));

}

add_action( 'cmb2_init' , 'add_page_meta' );


function add_product_meta(){

    /*
    $cmb_user_data = new_cmb2_box(array(
        'id' => 'add_product_meta',
        'title' => __('Add Product Meta', 'cmb2'),
        'object_types' => array('product'),
        'show_names' => true,
    ));

    $cmb_user_data->add_field(array(
        'name' => __('Category Data', 'cmb2'),
        'id' => 'bold_category_data',
        'type'    => 'text',
    ));
    */

    $cmb_user = new_cmb2_box( array(
        'id'            => 'additional_product_meta',
        'title'         => __( 'Additional Product Meta', 'cmb2' ),
        'object_types'  => array( 'product' ), // Tells CMB2 to use user_meta vs post_meta
        'show_names'    => true,
    ));

    // Add checkbox fields for stock sale options
    $cmb_user->add_field(array(
        'name' => __('Stock Sale Option', 'cmb2'),
        'id'   => 'stock_sale_option',
        'type' => 'title',
    
    ));
    $cmb_user->add_field(array(
        'name' => __('Current', 'cmb2'),
        'id'   => 'stock_sale_current',
        'type' => 'checkbox',
    ));
    
    $cmb_user->add_field(array(
        'name' => __('Future', 'cmb2'),
        'id'   => 'stock_sale_future',
        'type' => 'checkbox',
    ));
    
    $cmb_user->add_field(array(
        'name' => __('MTO', 'cmb2'),
        'id'   => 'stock_sale_mto',
        'type' => 'checkbox',
    ));

    // discounted fields
    $cmb_user->add_field( array(
        'name'      => __( 'Sale/Discounted ', 'cmb2' ),
        'id'        => 'sale_discounted_item',
        'type'      => 'radio_inline',
        'options'   => array(
            'None'  => __( 'None', 'cmb2' ),
            'Sale'    => __( 'Sale', 'cmb2' ),
            'Discounted'   => __( 'Discounted', 'cmb2' ),
        ),
        'default'   => 'None'
    ));
    $cmb_user->add_field( array(
        'name'      => __( 'Hide incoming stock row ', 'cmb2' ),
        'id'        => '_hide_incoming_stock',
        'type'      => 'radio_inline',
        'options'   => array(
            'None'  => __( 'None', 'cmb2' ),
            'Yes'    => __( 'Yes', 'cmb2' ),
            'No'   => __( 'No', 'cmb2' ),
        ),
        'default'   => 'None'
    ));

    $cmb_user->add_field( array(
        'name'      => __( 'Discount Retail Cost %', 'cmb2' ),
        'id'        => 'discount_retail_cost',
        'type'      => 'text',
    ));
    $cmb_user->add_field( array(
        'name'      => __( 'Discount Wholesale Cost %', 'cmb2' ),
        'id'        => 'discount_wholesale_cost',
        'type'      => 'text',
    ));
    $cmb_user->add_field( array(
        'name'      => __( 'Discount Retail', 'cmb2' ),
        'id'        => 'retail_discount_cost',
        'type'      => 'text',
    ));
    $cmb_user->add_field( array(
        'name'      => __( 'Discount Wholesale', 'cmb2' ),
        'id'        => 'wholesale_discount_cost',
        'type'      => 'text',
    ));
    $cmb_user->add_field( array(
        'name'      => __( 'Discount Title', 'cmb2' ),
        'id'        => 'item_discount_title',
        'type'      => 'text',
    ));
    $cmb_user->add_field( array(
        'name'      => __( 'Discount Description', 'cmb2' ),
        'id'        => 'item_discount_desc',
        'type'      => 'text',
    ));
    // End


    $cmb_user->add_field( array(
        'name'      => __( 'Product Material', 'cmb2' ),
        'id'        => 'bold_product_material',
        'type'      => 'text',
    ));
//
//    $cmb_user->add_field(array(
//         'name' => __('# of holds', 'cmb2'),
//         'id' => 'bold_product_holds',
//         'type'    => 'text',
//    ));
//
    /*
        $cmb_user->add_field(array(
             'name' => __('Hold Type', 'cmb2'),
             'id' => 'bold_product_hold_type',
             'type'    => 'text',
        ));
    */
    $cmb_user->add_field( array(
        'name'      => __( 'Bolt Size', 'cmb2' ),
        'id'        => 'bold_product_bolt_size',
        'type'      => 'text',
    ));


    $cmb_user->add_field( array(
        'name'      => __( 'Features', 'cmb2' ),
        'id'        => 'bold_product_features',
        'type'      => 'text',
    ));


    $cmb_user->add_field( array(
        'name'      => __( 'Size', 'cmb2' ),
        'id'        => 'bold_product_size',
        'type'      => 'text',
    ));

    $cmb_user->add_field( array(
        'name'      => __( 'T-nuts', 'cmb2' ),
        'id'        => 'bold_product_tnut',
        'type'      => 'radio_inline',
        'options'   => array(
            'None'  => __( 'None', 'cmb2' ),
            'No'    => __( 'No', 'cmb2' ),
            'Yes'   => __( 'Yes', 'cmb2' ),
        ),
        'default'   => 'None'
    ));

    $cmb_user->add_field( array(
        'name'      => __( 'Bolt-on', 'cmb2' ),
        'id'        => 'bold_product_bolt_on',
        'type'      => 'radio_inline',
        'options'   => array(
            'None'  => __( 'None', 'cmb2' ),
            'No'    => __( 'No', 'cmb2' ),
            'Yes'   => __( 'Yes', 'cmb2' ),
        ),
        'default'   => 'None'
    ));

    $cmb_user->add_field( array(
        'name'      => __( 'Quote / Pallet', 'cmb2' ),
        'id'        => 'bold_product_quote_pallet',
        'type'      => 'radio_inline',
        'options'   => array(
            'None'      => __( 'None', 'cmb2' ),
            'Quote'     => __( 'Quote', 'cmb2' ),
            'Pallet'    => __( 'Pallet', 'cmb2' ),
        ),
        'default'   => 'None'
    ));

    $cmb_user->add_field( array(
        'name'      => __( 'USAC', 'cmb2' ),
        'id'        => 'bold_product_usac',
        'type'      => 'radio_inline',
        'options'   => array(
            'None'  => __( 'None', 'cmb2' ),
            'No'    => __( 'No', 'cmb2' ),
            'Yes'   => __( 'Yes', 'cmb2' ),
        ),
        'default'   => 'None'
    ));

    $cmb_user->add_field( array(
        'name'      => __( 'IFSC', 'cmb2' ),
        'id'        => 'bold_product_ifsc',
        'type'      => 'radio_inline',
        'options'   => array(
            'None'  => __( 'None', 'cmb2' ),
            'No'    => __( 'No', 'cmb2' ),
            'Yes'   => __( 'Yes', 'cmb2' ),
        ),
        'default'   => 'None'
    ));

    $cmb_user->add_field( array(
        'name'      => __( 'Tokyo', 'cmb2' ),
        'id'        => 'bold_product_tokyo',
        'type'      => 'radio_inline',
        'options'   => array(
            'None'  => __( 'None', 'cmb2' ),
            'No'    => __( 'No', 'cmb2' ),
            'Yes'   => __( 'Yes', 'cmb2' ),
        ),
        'default'   => 'None'
    ));

    /*
    $cmb_user->add_field(array(
         'name' => __('Grip List', 'cmb2'),
         'id' => 'bold_product_grip_list',
         'type' => 'radio_inline',
         'options'    => array(
            'None' => __( 'None', 'cmb2' ),
            'No' => __( 'No', 'cmb2' ),
            'Yes' => __( 'Yes', 'cmb2' ),
         ),
         'default'=>'None'
    ));
    */
    //bold_product_grip_lists
    $cmb_user->add_field( array(
        'name'  => __( 'Grip List Award', 'cmb2' ),
        'id'    => 'bold_product_grip_lists',
        'type'  => 'text',
    ));
    /*
    $cmb_user->add_field(array(
         'name' => __('Angle', 'cmb2'),
         'id' => 'bold_product_angle',
         'type' => 'text',
    ));
    */

    $cmb_user->add_field( array(
        'name'  => __( 'Manufacturer', 'cmb2' ),
        'id'    => 'bold_product_manufacturer',
        'type'  => 'text',
    ));

    $cmb_user->add_field( array(
        'name'  => __( 'Texture', 'cmb2' ),
        'id'    => 'bold_product_texture',
        'type'  => 'text',
    ));

    $cmb_user->add_field( array(
        'name'  => __( 'Hold Type', 'cmb2' ),
        'id'    => 'bold_product_line_type',
        'type'  => 'text',
    ));

    $cmb_user->add_field( array(
        'name'  => __( '# of Sets', 'cmb2' ),
        'id'    => 'bold_product_number_of_sets',
        'type'  => 'text',
    ));

    $cmb_user->add_field( array(
        'name'  => __( '360 Images', 'cmb2' ),
        'id'    => 'bold_product_view_gallery',
        'type'  => 'file_list',
    ));

    $cmb_user->add_field( array(
        'name'  => __( 'Product Line', 'cmb2' ),
        'id'    => 'bold_product_line',
        'type'  => 'text',
    ));

    $cmb_user->add_field( array(
        'name'  => __( 'Product Year', 'cmb2' ),
        'id'    => 'bold_product_year',
        'type'  => 'text',
    ));

    $cmb_user->add_field( array(
        'name'  => __( 'MSRP', 'cmb2'),
        'id'    => 'bold_msrp',
        'type'  => 'text',
    ));
    /*
    $cmb_user->add_field(array(
        'name' => __('Manufacturer shipment', 'cmb2'),
        'id' => 'bold_manufacturer_shipment',
        'type' => 'radio_inline',
        'options'    => array(
           'No' => __( 'No', 'cmb2' ),
           'Yes' => __( 'Yes', 'cmb2' ),
        ),
        'default'=>'No'
    ));
   */
    /*
    $cmb_user->add_field(array(
        'name' => __('flag_update', 'cmb2'),
        'id' => 'flag_update',
        'type' => 'text',
    ));
    */
    $cmb_user->add_field( array(
        'name'  => __( 'Brading options', 'cmb2' ),
        'id'    => 'brading_options',
        'type'  => 'text',
    ));
    
    $cmb_user->add_field( array(
        'name'  => __( 'Accessory / Branded', 'cmb2' ),
        'id'    => 'accessory_branded',
        'type'  => 'text',
    ));

    $cmb_user->add_field( array(
        'name'  => __( 'post_views', 'cmb2' ),
        'id'    => 'post_views',
        'type'  => 'text',
    ));
    $cmb_user->add_field( array(
        'name'  => __( 'Category Data', 'cmb2' ),
        'id'    => 'bold_category_data',
        'type'  => 'text',
    ));
    /* Added By Gaurav - 25 Sug 2023 */
    $cmb_user->add_field(array(
         'name' => __('Only for Wholesale Users', 'cmb2'),
         'id' => 'only_for_wholesale_users',
         'type'      => 'radio_inline',
         'options'   => array(
            'No'    => __( 'No', 'cmb2' ),
            'Yes'   => __( 'Yes', 'cmb2' ),
        ),
        'default'   => 'No'
    ));
    
    $cmb_user->add_field( array(
        'name'  => __( 'Instock Date', 'cmb2' ),
        'id'    => 'instock_date',
        'type'  => 'text',
   ));
    
    $cmb_user->add_field( array(
        'name'  => __( 'Brand', 'cmb2' ),
        'id'    => 'product_brand',
        'type'  => 'text',
   ));
    $cmb_user->add_field( array(
        'name'  => __( 'Main Category', 'cmb2' ),
        'id'    => 'main_category',
        'type'  => 'text',
   ));

   $cmb_user->add_field( array(
        'name'  => __( 'Position Variations', 'cmb2' ),
        'id'    => 'position',
        'type'  => 'text',
    ));
   $cmb_user->add_field( array(
        'name'  => __( 'Position Line', 'cmb2' ),
        'id'    => 'position_line',
        'type'  => 'text',
    ));

    /* ---- */
    $cmb_user->add_field( array(
        'name'  => __( 'Line', 'cmb2' ),
        'id'    => 'product_line',
        'type'  => 'text',
    )); 
    $cmb_user->add_field(array(
         'name' => __('Only for Full Line Product', 'cmb2'),
         'id' => 'only_full_line_product',
         'type'      => 'radio_inline',
         'options'   => array(
            'no'    => __( 'No', 'cmb2' ),
            'yes'   => __( 'Yes', 'cmb2' ),
        ),
        'default'   => 'no'
    ));
    $cmb_user->add_field( array(
        'name'  => __( 'Full Line XS', 'cmb2' ),
        'id'    => 'full_line_xs',
        'type'  => 'text',
   ));
    $cmb_user->add_field( array(
        'name'  => __( 'Full Line S', 'cmb2' ),
        'id'    => 'full_line_s',
        'type'  => 'text',
   ));
    $cmb_user->add_field( array(
        'name'  => __( 'Full Line M', 'cmb2' ),
        'id'    => 'full_line_m',
        'type'  => 'text',
   ));
    $cmb_user->add_field( array(
        'name'  => __( 'Full Line L', 'cmb2' ),
        'id'    => 'full_line_l',
        'type'  => 'text',
   ));
    $cmb_user->add_field( array(
        'name'  => __( 'Full Line XL', 'cmb2' ),
        'id'    => 'full_line_xl',
        'type'  => 'text',
   ));
    $cmb_user->add_field( array(
        'name'  => __( 'Full Line Giant/Feature', 'cmb2' ),
        'id'    => 'full_line_giant_feature',
        'type'  => 'text',
   ));
    $cmb_user->add_field(array(
         'name' => __('Only for Hold Type Product', 'cmb2'),
         'id' => 'only_for_hold_type_product',
         'type'      => 'radio_inline',
         'options'   => array(
            'no'    => __( 'No', 'cmb2' ),
            'yes'   => __( 'Yes', 'cmb2' ),
        ),
        'default'   => 'no'
    ));
    $cmb_user->add_field( array(
        'name'  => __( 'Hold Type Edges', 'cmb2' ),
        'id'    => 'hold_type_edges',
        'type'  => 'text',
   ));
    $cmb_user->add_field( array(
        'name'  => __( 'Hold Type Feet', 'cmb2' ),
        'id'    => 'hold_type_feet',
        'type'  => 'text',
   ));
    $cmb_user->add_field( array(
        'name'  => __( 'Hold Type Jugs', 'cmb2' ),
        'id'    => 'hold_type_jugs',
        'type'  => 'text',
   ));
    $cmb_user->add_field( array(
        'name'  => __( 'Hold Type Pinches', 'cmb2' ),
        'id'    => 'hold_type_pinches',
        'type'  => 'text',
   ));
    $cmb_user->add_field( array(
        'name'  => __( 'Hold Type Pockets', 'cmb2' ),
        'id'    => 'hold_type_pockets',
        'type'  => 'text',
   ));
    $cmb_user->add_field( array(
        'name'  => __( 'Hold Type Slopers', 'cmb2' ),
        'id'    => 'hold_type_slopers',
        'type'  => 'text',
   ));
    
    $cmb_user->add_field( array(
        'name'  => __( 'Featured Video Link', 'cmb2' ),
        'id'    => 'featured_video_link',
        'type'  => 'text',
   ));

    $cmb_user->add_field( array(
        'name'  => __( 'Product Length', 'cmb2' ),
        'id'    => 'product_length',
        'type'  => 'text',
    ));
    $cmb_user->add_field( array(
        'name'  => __( 'Product Width', 'cmb2' ),
        'id'    => 'product_width',
        'type'  => 'text',
    ));
    
    $cmb_user->add_field( array(
        'name'  => __( 'Product Height', 'cmb2' ),
        'id'    => 'product_height',
        'type'  => 'text',
    ));

    /* The End */
}

add_action( 'cmb2_init', 'add_product_meta' );

function add_attribute_meta(){
    $cmb_user = new_cmb2_box(array(
        'id' => 'additional_attribute_meta',
        'title' => __('Additional Brand Meta', 'cmb2'),
        'object_types' => array('term'), // Tells CMB2 to use user_meta vs post_meta
        'show_names' => true,
        'taxonomies'    => array( 'pa_color' ),
    ));

    $cmb_user->add_field(array(
        'name' => __('Color Hex', 'cmb2'),
        'id' => 'bold_product_color_hex',
        'type'    => 'text',
    ));

    $cmb_user->add_field(array(
        'name' => __('Sort order', 'cmb2'),
        'id' => 'bold_product_color_sortorder',
        'type'    => 'text',
    ));

    /*
    $cmb_user->add_field(array(
        'name' => __('Color Caption', 'cmb2'),
        'id' => 'bold_product_color_caption',
        'type'    => 'text',
        'default' => '#ffffff'
    ));
    */

    $cmb_user->add_field(array(
        'name' => __('Dual Texture?', 'cmb2'),
        'id' => 'bold_product_color_dual_texture',
        'type'    => 'radio_inline',
        'options' => array(
            'No' => __( 'No', 'cmb2' ),
            'Yes' => __( 'Yes', 'cmb2' ),
        )
    ));
    
    


}

add_action( 'cmb2_init', 'add_attribute_meta' );

function get_product_category_hero( $id ){

    $product_category_id = get_post_meta( $id, 'bold_product_category_id', true );
    //$custom_banner = get_term_meta($product_category_id,'bold_custom_banner_image',true);
    $custom_banner = '';
    $output = '';

    $title_color = get_post_meta( $id, 'bold_h1_color', true );
    if(!$title_color){
        $title_color = '#fff';
    }

    if ( has_post_thumbnail( $id ) ){
        $image = wp_get_attachment_image_src( get_post_thumbnail_id( $id ), 'single-post-thumbnail' );
        $custom_banner = $image[0];
        $custom_banner_description = '';
        //$custom_banner_description = get_term( $product_category_id, 'product_cat' )->description;
        /*
        if( $custom_banner == '' ){
            // set to volumes default
            $custom_banner = get_term_meta(35, 'bold_custom_banner_image', true );
            $custom_banner_description = get_term(35,'product_cat')->description;
        }
        */
        //$custom_banner = get_term_meta(35, 'bold_custom_banner_image', true );


        $output .= '<div class="product-category-hero-image" style="background-image: url(' . $custom_banner . ');">';
        $output .= '    <div class="container">' . $custom_banner_description;

        $output .= '    </div>';
        $output .= '    <h1 style="color:'.$title_color.'" class="entry-title">' . get_the_title() . '</h1>';
        $output .= '</div>';

    }
    /*
        echo '<img src="'. $image[0] .'" alt="'. get_the_title() .'" />';
        <?php endif; ?>
    */


    return $output;
}

function get_product_line_hero($id){

    $custom_banner = get_the_post_thumbnail(get_post($id), 'full')[0];
    $custom_banner_description = get_post_meta($id, 'bold_line_banner_title' , true );

    if( $custom_banner == '' ){
        // set to volumes default
        $custom_banner = get_term_meta(35, 'bold_custom_banner_image', true );
        $custom_banner_description = get_term(35,'product_cat')->description;
    }

    $output = '';
    $output .= '<div class="product-category-hero-image" style="background-image: url(' . $custom_banner . ');">';
    $output .= '<div class="container">' . $custom_banner_description . '</div>';
    $output .= '</div>';
    return $output;

}

function filter_variation_price($product_ids, $min_price, $max_price){

    global $product;
    $filtered_product_ids = array();

    foreach( $product_ids as $product ){
        $_product = wc_get_product($product);

        // check if product is a variable product
        if( $_product->is_type( 'variable' ) ) {
            $product_price = $_product->get_variation_price();
            $min = $_product->get_variation_price();
            $max = $_product->get_variation_price('max');
        }else{
            $product_price = $_product->get_price();
            $min = $_product->get_price();
            $max = $_product->get_price();
        }

        if( check_if_price_in_range( $min, $min_price, $max_price ) == true && check_if_price_in_range( $max, $min_price, $max_price == true )){

            $filtered_product_ids[] = $product;

        }
    }

    return $filtered_product_ids;

}
function get_products_args($data){


    $posts_per_page = 15;

    //Page
    if(isset($data['page_number'])){
        $page_number=$data['page_number']*1;
    }else{
        $page_number=1;
    }

    $product_category_ids=explode(",",$data['product_category_id']);
    $search_args = array(
        'post_type'      => 'product',

        'post_status'    => 'publish',
        'posts_per_page' => $posts_per_page,
        //'orderby'        => 'title',
        //'order'          => 'ASC',
        'paged'          => $page_number,
        'tax_query'      => array(
            'relation' => 'AND',
            array(
                'field' => 'term_id',
                'taxonomy' => 'product_cat',
                'terms' => $product_category_ids
                //'terms' => [412,420]
            )
        ),
        'meta_query' => array(
            'relation' => 'AND',
        )
    );
    $parent_ids=[9];
    if(isset($data['one-five'])){
        //print_r($colors);
        $args = array(
            'post_type'     => 'product_variation',
            'meta_query'    => array(
                'relation' => 'AND',
                array(
                    'key'     => '_stock_status',
                    'value'   => 'instock',
                    'compare' => '=',
                )
            ),
            'fields'         => 'id=>parent',
            'posts_per_page' => -1,
            'groupby'        => 'post_parent', // *this is a custom query arg
        );
    }


    if(isset($data['six-weeks'])){
        $date6weeks = date('Y-m-d', strtotime("+42 days"));

        $args = array(
            'post_type'     => 'product_variation',
            'meta_query'    => array(
                'relation' => 'AND',

                array(
                    'key'     => '_backorder_future_date',
                    'value'   => $date6weeks,
                    'compare' => '<=',
                ),
                array(
                    'key'     => '_backorder_future_date',
                    'value'   => '',
                    'compare' => '!=',
                ),
                array(
                    'key'     => '_backorder_future',
                    'value'   => '0',
                    'compare' => '>',
                )
            ),
            'fields'         => 'id=>parent',
            'posts_per_page' => -1,
            'groupby'        => 'post_parent', // *this is a custom query arg
        );
    }
    if(isset($data['one-five']) or isset($data['six-weeks'])){
        if(isset($data['product-color'])){
            $colors = get_related_colors_slug($data['product-color']);
            $args['meta_query'][] = array(
                'key'     => 'attribute_pa_color', // Product variation attribute
                'value'   => $colors, // Term slugs only
                'compare' => 'IN',
            );
        }

        $q = new WP_Query( $args );

        $parent_ids = wp_list_pluck( $q->posts, 'post_parent' );
        if($parent_ids){
            $search_args['post__in'] = $parent_ids;
        }else{
            $search_args['post__in'] = [0];
        }
    }
    //print_r($search_args);
    //Filter by price
    /*
    if(isset($data['price-filter-min']) && isset($data['price-filter-max'])){
        $search_price_args =
            array(
                'key' => '_price',
                'value' => array($data['price-filter-min']*1, $data['price-filter-max']*1),
                'compare' => 'BETWEEN',
                'type' => 'NUMERIC'
            );
        $search_args['meta_query'][] = $search_price_args;
    }
    */
    if(isset($data['price-filter-max']) and $data['price-filter-max']>0){
        $search_price_args =
            array(
                'key' => '_price',
                'value' => $data['price-filter-max']*1,
                'compare' => '<=',
                'type' => 'NUMERIC'
            );
        $search_args['meta_query'][] = $search_price_args;
    }
    if(isset($data['price-filter-min']) and $data['price-filter-min']>0){
        $search_price_args =
            array(
                'key' => '_price',
                'value' => $data['price-filter-min']*1,
                'compare' => '>=',
                'type' => 'NUMERIC'
            );
        $search_args['meta_query'][] = $search_price_args;
    }
    //if( in_array('new', $options ) ){
    if(isset($data['new'])){
        //echo "ok";
        $search_data[] =
            array(
                'key' => 'bold_product_year',
                'value' => date("Y")//2022
            );
        $search_args['meta_query'][] = $search_data;
    }

    //Filter by product type
    /*
    if(isset($data['product-type'])){
        if($data['product-type']){
            $search_type_args =
                array(
                    'taxonomy' => 'product_cat',
                    'field' => 'name',
                    'terms' => $data['product-type'],
                );
            $search_args['tax_query'][] = $search_type_args;
        }
    }
    */

    //Filter by Brand, Line
    if(isset($data['cat'])){
        $search_type_args =
            array(
                'taxonomy' => 'product_cat',
                'field' => 'name',
                'terms' => $data['product-brand'],
            );
        $search_args['tax_query'][] = $search_type_args;
    }

    //Filter by Family
    if(isset($data['product-family'])){
        $search_type_args =
            array(
                'taxonomy' => 'product_cat',
                'field' => 'name',
                'terms' => $data['product-family'],
            );
        $search_args['tax_query'][] = $search_type_args;
    }

    //Filter by Size
    if(isset($data['product-size'])){
        $search_size_args =
            array(
                'key' => 'bold_product_size',
                'value' => $data['product-size']
            );
        $search_args['meta_query'][] = $search_size_args;
    }

    if(isset($data['product-color'])){
        $colors = get_related_colors($data['product-color']);
        //print_r($colors);
        $search_color_args =
            array(
                'taxonomy' => 'pa_color',
                'field' => 'name',
                'terms' => $colors,
            );
        $search_args['tax_query'][] = $search_color_args;
    }
    //Options
    if(isset($data['product-options'])){

        if( in_array('Bolt-on', $data['product-options'] ) ){
            $search_options_args =
                array(
                    'key' => 'bold_product_bolt_on',
                    'value' => 'Yes'
                );
            $search_args['meta_query'][] = $search_options_args;
        }
        if( in_array('Screw-on', $data['product-options'] ) ){
            $search_options_args =
                array(
                    'key' => 'bold_product_bolt_on',
                    'value' => 'No'
                );
            $search_args['meta_query'][] = $search_options_args;
        }
        if( in_array('T-nuts', $data['product-options'] ) ){
            $search_options_args =
                array(
                    'key' => 'bold_product_tnut',
                    'value' => 'Yes'
                );
            $search_args['meta_query'][] = $search_options_args;
        }
        if( in_array('No T-nuts', $data['product-options'] ) ){
            $search_options_args =
                array(
                    'key' => 'bold_product_tnut',
                    'value' => 'No'
                );
            $search_args['meta_query'][] = $search_options_args;
        }
        if( in_array('USAC', $data['product-options'] ) ){
            $search_options_args =
                array(
                    'key' => 'bold_product_usac',
                    'value' => 'Yes'
                );
            $search_args['meta_query'][] = $search_options_args;
        }
        if( in_array('IFSC', $data['product-options'] ) ){
            $search_options_args =
                array(
                    'key' => 'bold_product_ifsc',
                    'value' => 'Yes'
                );
            $search_args['meta_query'][] = $search_options_args;
        }
        if( in_array('Tokyo', $data['product-options'] ) ){
            $search_options_args =
                array(
                    'key' => 'bold_product_tokyo',
                    'value' => 'Yes'
                );
            $search_args['meta_query'][] = $search_options_args;
        }
        if( in_array('CBJ', $data['product-options'] ) ){
            $search_options_args =
                array(
                    'key' => 'bold_product_grip_list',
                    'value' => 'Yes'
                );
            $search_args['meta_query'][] = $search_options_args;
        }

        $search_manufacturers = array(
            'relation' => 'OR'
        );
        if( in_array('Produced by Proxy', $data['product-options'] ) ){
            $search_manufacturers[] =
                array(
                    'key' => 'bold_product_manufacturer',
                    'value' => 'Proxy'
                );
            $search_args['meta_query'][2] = $search_manufacturers;
        }
        if( in_array('Produced by Composite-X', $data['product-options'] ) ){
            $search_manufacturers[] =
                array(
                    'key' => 'bold_product_manufacturer',
                    'value' => 'Composite-X'
                );
            $search_args['meta_query'][2] = $search_manufacturers;
        }
        if( in_array('Produced by Blocz', $data['product-options'] ) ){
            $search_manufacturers[] =
                array(
                    'key' => 'bold_product_manufacturer',
                    'value' => 'Blocz'
                );
            $search_args['meta_query'][2] = $search_manufacturers;
        }
        if( in_array('Produced by 360', $data['product-options'] ) ){
            $search_manufacturers[] =
                array(
                    'key' => 'bold_product_manufacturer',
                    'value' => '360'
                );
            $search_args['meta_query'][2] = $search_manufacturers;
        }
        if( in_array('Produced by Simpl', $data['product-options'] ) ){
            $search_manufacturers[] =
                array(
                    'key' => 'bold_product_manufacturer',
                    'value' => 'Simpl'
                );
            $search_args['meta_query'][2] = $search_manufacturers;
        }

        if( in_array('Produced by Goodgrip', $data['product-options'] ) ){
            $search_manufacturers[] =
                array(
                    'key' => 'bold_product_manufacturer',
                    'value' => 'Goodgrip'
                );
            $search_args['meta_query'][2] = $search_manufacturers;
        }
    }

    //$search_args['meta_query'][]

    //ws_test($search_args);
    //print_r($search_args);
    /*

    */
    /*
    $search_args['meta_query'][] = [
        //'relation' => 'AND',
        [
            'taxonomy' => 'pa_color',
            'key'     => '_stock_status',
            'value'   => 'instock',
            'compare' => '=',
        ]

    ];

/*
    $search_args['tax_query'][] =
        array(
           'taxonomy' => 'pa_color',
           'field' => '_stock_status',
           'terms' => 'instock'
        )

    /*
    $search_args['tax_query'][] = [
        'relation' => 'AND',
        [
            'key'     => '_stock_status',
            'value'   => 'instock',
            'compare' => '=',
        ],
        [
            'key'     => '_stock',
            'type'    => 'numeric',
            'value'   => '1',
            'compare' => '=',
        ],

    ];
    */
    //Sorting
    $search_args['orderby'] = 'menu_order';
    $search_args['order'] = 'ASC';
    if(isset($data['sort-by'])){
        // sort by line - добавить
        //meta_key' => 'client_feedback_score',
        if( $data['sort-by'] == 'line' ){
            $search_args['meta_key'] = 'bold_product_line';
            $search_args['orderby'] = 'bold_product_line';
            $search_args['order'] = 'ASC';
        }

        // sort by title
        if( $data['sort-by'] == 'a-z' ){
            $search_args['orderby'] = 'title';
            $search_args['order'] = 'ASC';
        }
        // sort by price
        if( $data['sort-by'] == 'price' ){
            $search_args['meta_key'] = '_price';
            $search_args['orderby'] = 'meta_value_num';
            $search_args['order'] = 'ASC';
        }
        // sort by popularity
        if( $data['sort-by'] == 'popularity' ){
            $search_args['suppress_filters'] = 'false';
            $search_args['orderby'] = 'post_views';
            $search_args['order'] = 'DESC';
        }
        if( $data['sort-by'] == 'date' ){
            $search_args['orderby'] = 'date';
            $search_args['order'] = 'DESC';
        }
    }
    //print_r($search_args);
    return $search_args;
}
function get_product_search_query($product_category_id, $type, $brand, $family, $size, $color, $options, $min_price, $max_price, $page_number, $mto ){

    $posts_per_page = '15';

    // if no search entered set args

    $search_args = array(
        'post_type'      => 'product',
        'post_status'    => 'publish',
        'posts_per_page' => $posts_per_page,
        'orderby'        => 'title',
        'order'        => 'ASC',
        'paged'          => $page_number,
        'tax_query' => array(

            'relation' => 'AND',

            array(
                'field' => 'term_id',
                'taxonomy' => 'product_cat',
                'terms' => $product_category_id
            )

        ),
        'meta_query' => array(

            'relation' => 'AND',

        )
    );

    // type

    if( $type != '' ){

        $search_type_args =

            array(
                'taxonomy' => 'product_cat',
                'field' => 'name',
                'terms' => $type,
            );


        $search_args['tax_query'][] = $search_type_args;
    }

    // brand

    if( $brand != '' ){

        $search_type_args =

            array(
                'taxonomy' => 'product_cat',
                'field' => 'name',
                'terms' => $brand,
            );


        $search_args['tax_query'][] = $search_type_args;
    }

    // family/line

    if( $family != '' ){

        $search_type_args =

            array(
                'taxonomy' => 'product_cat',
                'field' => 'name',
                'terms' => $family,
            );

        $search_args['tax_query'][] = $search_type_args;
    }

    // size

    if( $size != '' ){

        $search_size_args =

            array(
                'key' => 'bold_product_size',
                'value' => array( $size )
            );


        $search_args['meta_query'][] = $search_size_args;
    }

    // shipping rules

    if( $mto != '' ){

        if( $mto == 'on' ){
            $value = 'MTO';
        }

        $search_shipping_args =

            array(
                'key' => 'bold_product_stock_mto',
                'value' => $value
            );



        $search_args['meta_query'][] = $search_shipping_args;

    }

    // color

    if( $color != '' ){

        $colors = get_related_colors($color);

        $search_color_args =

            // 'relation' => 'AND',

            array(
                'taxonomy' => 'pa_color',
                'field' => 'name',
                'terms' => array($colors),
            );

        $search_args['tax_query'][] = $search_color_args;

    }

    // min price and max price between

    if( $min_price != '' && $max_price != '' ){

        $search_price_args =

            array(
                'key' => '_price',
                'value' => array($min_price, $max_price),
                'compare' => 'BETWEEN',
                'type' => 'NUMERIC'

            );



        $search_args['meta_query'][] = $search_price_args;

    }

    if( !empty($options) ){

        if( in_array('Bolt-on', $options ) ){

            $search_options_args =

                array(
                    'key' => 'bold_product_bolt_on',
                    'value' => 'Yes'
                );

            $search_args['meta_query'][] = $search_options_args;

        }

        if( in_array('Screw-on', $options ) ){

            $search_options_args =

                array(
                    'key' => 'bold_product_bolt_on',
                    'value' => 'No'
                );

            $search_args['meta_query'][] = $search_options_args;

        }


        if( in_array('T-nuts', $options ) ){

            $search_options_args =

                array(
                    'key' => 'bold_product_tnut',
                    'value' => 'Yes'
                );

            $search_args['meta_query'][] = $search_options_args;

        }

        if( in_array('No T-nuts', $options ) ){

            $search_options_args =

                array(
                    'key' => 'bold_product_tnut',
                    'value' => 'No'
                );

            $search_args['meta_query'][] = $search_options_args;

        }


        if( in_array('USAC', $options ) ){

            $search_options_args =

                array(
                    'key' => 'bold_product_usac',
                    'value' => 'Yes'
                );

            $search_args['meta_query'][] = $search_options_args;

        }

        if( in_array('IFSC', $options ) ){

            $search_options_args =

                array(
                    'key' => 'bold_product_ifsc',
                    'value' => 'Yes'
                );

            $search_args['meta_query'][] = $search_options_args;

        }

        if( in_array('Tokyo', $options ) ){

            $search_options_args =

                array(
                    'key' => 'bold_product_tokyo',
                    'value' => 'Yes'
                );

            $search_args['meta_query'][] = $search_options_args;

        }

        if( in_array('CBJ', $options ) ){

            $search_options_args =

                array(
                    'key' => 'bold_product_grip_list',
                    'value' => 'Yes'
                );

            $search_args['meta_query'][] = $search_options_args;

        }

        $search_manufacturers = array(
            'relation' => 'OR'
        );

        if( in_array('Produced by Proxy', $options ) ){

            $search_manufacturers[] =

                array(
                    'key' => 'bold_product_manufacturer',
                    'value' => 'Proxy'
                );

            $search_args['meta_query'][2] = $search_manufacturers;

        }

        if( in_array('Produced by Composite-X', $options ) ){


            $search_manufacturers[] =

                array(
                    'key' => 'bold_product_manufacturer',
                    'value' => 'Composite-X'
                );

            $search_args['meta_query'][2] = $search_manufacturers;

        }

        if( in_array('Produced by Blocz', $options ) ){

            $search_manufacturers[] =

                array(
                    'key' => 'bold_product_manufacturer',
                    'value' => 'Blocz'
                );

            $search_args['meta_query'][2] = $search_manufacturers;

        }

        if( in_array('Produced by 360', $options ) ){

            $search_manufacturers[] =

                array(
                    'key' => 'bold_product_manufacturer',
                    'value' => '360'
                );

            $search_args['meta_query'][2] = $search_manufacturers;

        }

        if( in_array('Produced by Simpl', $options ) ){

            $search_manufacturers[] =

                array(
                    'key' => 'bold_product_manufacturer',
                    'value' => 'Simpl'
                );

            $search_args['meta_query'][2] = $search_manufacturers;

        }

        if( in_array('Produced by Goodgrip', $options ) ){

            $search_manufacturers[] =

                array(
                    'key' => 'bold_product_manufacturer',
                    'value' => 'Goodgrip'
                );

            $search_args['meta_query'][2] = $search_manufacturers;

        }

        ws_test($search_args);

    }

    return $search_args;

}



function get_product_info($product_id){
    $_product = wc_get_product($product_id);
    $product_size = get_post_meta($product_id, 'bold_product_size', true);

    $image = wp_get_attachment_image_src( get_post_thumbnail_id( $product_id ), 'single-post-thumbnail' );

    if(isset($image[0])){
        $featured_img = $image[0];
        $gallery_images = $_product->get_gallery_image_ids();
        $hover_image = wp_get_attachment_url($gallery_images[0], 'full');
    }else{
        $featured_img = "";
        $hover_image="";
    }
    if($_product->is_type( 'variable' ) ) {
        $product_price = number_format( $_product->get_variation_price(), 2 );

        //if(!empty($standard_colors )){
        //    $add_button = '<a data-id="' . $product_id . '" class="add-to-cart-btn add-to-cart-trigger" href="#">Add to Cart</a>';
        //}else{
        //    $add_button = '<a data-id="' . $product_id . '" class="add-to-cart-btn" href="' . $product_link . '">Add to Cart</a>';
        //}
    }else{
        $product_price = $_product->get_price();
        //$add_button = '<a class="add-to-cart-btn" href="' . $product_link . '?add-to-cart=' . $product_id . '">Add to Cart</a>';
    }


    $product_data=Array(
        "title"=>$_product->get_title(),
        "link"=>get_permalink($product_id),
        "price"=>$product_price,
        "image"=>$featured_img,
        "hover_image"=>$hover_image,
        "size"=>$product_size,
        //"variations"=>$_product->get_available_variations()
        "variations"=>$_product->get_children()

    );
    return $product_data;
}

function custom_woocommerce_placeholder_img_src( $src ) {
    $src = wp_get_attachment_url(34169);
    return $src;
}

add_filter('woocommerce_placeholder_img_src', 'custom_woocommerce_placeholder_img_src');



function check_dual_tex($standard_colors){
    foreach( $standard_colors as $color ){
        $color_code = get_term_meta($color->term_id, 'bold_product_color_hex', true);
        $standard = get_term_meta($color->term_id,'bold_product_color_dual_texture', true);
        if( $standard == 'Yes' ){
            return true;
        }
    }
}
/*
function check_standard_colors($standard_colors){
     foreach( $standard_colors as $color ){
        $color_code = get_term_meta($color->term_id, 'bold_product_color_hex', true);
        $standard = get_term_meta($color->term_id,'bold_product_color_dual_texture', true);
        if( $standard != 'Yes' ){
            return true;
        }
     }
}
*/
function color_code_swaps($color_code){
    $color_swaps = array(

        '#FFF' => '#FFF', // white
        '#ffff00' => '#ffff00', // red
        '#f1dd38' => '#f1dd38', // yellow
        '#6dff2c' => '#6dff2c', // neon green
        '#ffb500' => '#ffb500', // orange
        '#f616ff' => '#f616ff',
        '#fb6bff' => '#fb6bff',
        '#7df24f' => '#7df24f',

    );

    if( in_array($color_code, $color_swaps ) ){
        return true;
    }
}

/*** attribute tabs for ordering - on single product page ***/
/*
function get_attribute_tabs($id){

    // id is the post id

    $standard_colors = get_color_terms($id);

    $product = get_post($id);
    $now = time(); // текущее время (метка времени)
    if( check_dual_tex($standard_colors) === true ){
        $adjustment = 'dual-tex';
    }

    // for variable products only

    $_product = wc_get_product( $id );

    if( $_product->is_type( 'variable' ) && !empty($standard_colors) ) {

    echo '<div class="attribute-row">';
    echo '<ul>';
    echo '<li data-name="my-order" class="active">My Order</li>';
    echo '<li data-name="color-info">Colors</li>';
    echo '<li data-name="shipping-info">Shipping Info</li>';
    echo '</ul>';
    echo '</div>';

    // Ordering Sheet

    echo '<div class="my-order info-tab attribute-wrapper active">';

    echo '<div class="stock-placeholder">';

    echo '<div class="stock-separator">';
    echo '<span>IN STOCK</span>';
    echo '</div>';
    echo '<div class="stock-separator">';
    echo '<span>IN STOCK WITHIN 6 WEEKS</span>';
    echo '</div>';

    echo '<div class="stock-separator">';
    echo '<span>MY ORDER</span>';
    echo '</div>';



    echo '</div>';

    echo '<div class="inventory-wrapper">';

    echo '<div class="attribute-stock">';

        echo '<div class="standard-stock">';

        echo '<div class="type-stock">';
        echo '<div class="line"></div> <span class="color-type">Standard</span> <div class="line"></div>';
        echo '</div>';

        echo '<div class="color-inventory">';

        foreach( $standard_colors as $color ){
            // ws_test($color);
            $standard = get_term_meta($color->term_id,'bold_product_color_dual_texture', true);

//$variation_id=$color['variation']['variation_id'];
//echo "!".$variation_id."!";

$variation_obj = new WC_Product_variation($variation_id);
$stock = $variation_obj->get_stock_quantity();
//print_r($variation_obj);
//$backorders=$variation_obj->get_backorders();
//print_r($variation_obj->get_variation_attributes ( ));
//echo "!".$variation_obj->backorder_future."!<br/>";
//echo "!".$variation_obj->backorder_future_date."!<br/>";
$f_date=$variation_obj->backorder_future_date;
$backorder_cnt="-";
if($f_date){
    $your_date = strtotime($f_date);
    $datediff = $your_date - $now;
    $datediff_days=ceil($datediff / (60 * 60 * 24))."<br>";
    if($datediff_days<=42){
        $backorder_cnt=$variation_obj->backorder_future;
    }
}


            echo '<div class="color-wrapper">';

            if( $standard != 'Yes' ){

                $color_code = get_term_meta($color->term_id, 'bold_product_color_hex', true);
                $stock = get_variation_stock($color, $product);
                $color_variation_id = get_variation_id_by_color($color, $product);

                $variation_obj = new WC_Product_variation($color_variation_id);

                $f_date=$variation_obj->backorder_future_date;

                $backorder_cnt="-";
                if($f_date){
                    $your_date = strtotime($f_date);
                    $datediff = $your_date - $now;
                    $datediff_days=ceil($datediff / (60 * 60 * 24))."<br>";
                    if($datediff_days<=42){
                        $backorder_cnt=$variation_obj->backorder_future;
                    }
                }

                if( $stock == '' ){
                    $stock = '-';
                }

                echo '<div class="color-block" style="background-color: ' . $color_code . '">';

                if( color_code_swaps($color_code) === true ){
                    echo '<span class="color-name-dark">' . $color->name . '</span>';
                }else{
                    echo '<span class="color-name">' . $color->name . '</span>';
                }

                echo '</div>';

                echo '<div class="in-stock">';

                if( color_code_swaps($color_code) === true ){
                    echo '<span style="background-color: ' . $color_code . '" class="color-stock color-name-dark">' . $stock . '</span>';
                }else{
                    echo '<span style="background-color: ' . $color_code . '" class="color-stock color-name">' . $stock . '</span>';
                }

                if( color_code_swaps($color_code) === true ){
                    echo '<span style="background-color: ' . $color_code . '" class="color-stock color-name-dark">' . $backorder_cnt . '</span>';
                }else{
                    echo '<span style="background-color: ' . $color_code . '" class="color-stock color-name">' . $backorder_cnt . '</span>';
                }

                if( color_code_swaps($color_code) === true ){
                    echo '<input style="background-color: ' . $color_code . '" name="variation_color" class="my-stock my-stock-input color-name-dark" data-variation-id="' . $color_variation_id . '" id="' . $color_variation_id . '" type="text" min="0" value="0">';
                }else{
                    echo '<input style="background-color: ' . $color_code . '" name="variation_color" class="my-stock my-stock-input color-name" data-variation-id="' . $color_variation_id . '" id="' . $color_variation_id . '" type="text" min="0" value="0">';
                }

                echo '</div>';

            }

            echo '</div>';

        }

        echo '</div>';
        echo '</div>';

        // check if dual tex exists

        if( $adjustment == 'dual-tex' ){

            echo '<div class="dual-stock ' . $adjustment . '">';

            echo '<div class="type-stock">';
            echo '<div class="line"></div><span class="color-type">Dual Tex</span><div class="line"></div>';
            echo '</div>';

            echo '<div class="color-inventory">';

            foreach( $standard_colors as $color ){

                $standard = get_term_meta($color->term_id,'bold_product_color_dual_texture', true);

                echo '<div class="color-wrapper">';

                if( $standard == 'Yes' ){

                    $color_code = get_term_meta($color->term_id, 'bold_product_color_hex', true);
                    $stock = get_variation_stock($color, $product);
                    $color_variation_id = get_variation_id_by_color($color, $product);
                    $variation_obj = new WC_Product_variation($color_variation_id);

                    $f_date=$variation_obj->backorder_future_date;

                    $backorder_cnt="-";
                    if($f_date){
                        $your_date = strtotime($f_date);
                        $datediff = $your_date - $now;
                        $datediff_days=ceil($datediff / (60 * 60 * 24))."<br>";
                        if($datediff_days<=42){
                            $backorder_cnt=$variation_obj->backorder_future;
                        }
                    }
                    if( $stock == '' ){
                        $stock = '-';
                    }

                    echo '<div class="color-block" style="background-color: ' . $color_code . '">';

                    if( color_code_swaps($color_code) === true  ){
                        echo '<span class="color-name-dark">' . $color->name . '</span>';
                    }else{
                        echo '<span class="color-name">' . $color->name . '</span>';
                    }

                    echo '</div>';

                    echo '<div class="in-stock">';

                    if( color_code_swaps($color_code) === true ){
                        echo '<span style="background-color: ' . $color_code . '" class="color-stock color-name-dark">' . $stock . '</span>';
                    }else{
                        echo '<span style="background-color: ' . $color_code . '" class="color-stock color-name">' . $stock . '</span>';
                    }
                    if( color_code_swaps($color_code) === true ){
                        echo '<span style="background-color: ' . $color_code . '" class="color-stock color-name-dark">' . $backorder_cnt . '</span>';
                    }else{
                        echo '<span style="background-color: ' . $color_code . '" class="color-stock color-name">' . $backorder_cnt . '</span>';
                    }

                    if( color_code_swaps($color_code) === true ){
                        echo '<input style="background-color: ' . $color_code . '" name="variation_color" class="my-stock my-stock-input color-name-dark" data-variation-id="' . $color_variation_id . '" id="' . $color_variation_id . '" type="text" min="0" value="0">';
                    }else{
                        echo '<input style="background-color: ' . $color_code . '" name="variation_color" class="my-stock my-stock-input color-name" data-variation-id="' . $color_variation_id . '" id="' . $color_variation_id . '" type="text" min="0" value="0">';
                    }

                    echo '</div>';


                }

                echo '</div>';

            }

            echo '</div>';
        echo '</div>';

    }

    echo '</div>';

    echo '</div>';

    echo '</div>';

    echo '</div>';

    // may have to adjust this later for other simple products

    // color info tab

    echo '<div class="info-tab color-info">';

    echo get_template_part('templates/single-product/color-info');

    echo '</div>';

    }

    // shipping info tab

    echo '<div class="info-tab shipping-info">';

    echo '<h2>Shipping Info</h2>';

    echo '</div>';

}

/***
* Remove tabs
***/

remove_action( 'woocommerce_after_single_product_summary', 'woocommerce_output_product_data_tabs', 10 );

/*** Product Details on Single Product Page ***/

function add_info_under_title(){
    $product_id     = get_the_ID();

    $helper = new BoldHelper;

    $brand_name = $helper->getBrand( $product_id );
    //echo '<div class="product_info_brand">Brand: <strong>' . $brand_name . '</strong></div>';
    /* Gaurav Nee Brand field */ 
    $custom_brand = get_post_meta($product_id, 'product_brand', true);
    if($custom_brand){
        echo '<div class="product_info_brand">Brand: <strong>' . $custom_brand . '</strong></div>';
    }
    /* The End */
    //$dimensions     = get_post_meta( $product_id, 'bold_product_dimensions', true );

    $size           = get_post_meta( $product_id, 'bold_product_size', true );
    $size_str       = "";
    switch ( $size ){
        case "XS":
            $size_str = "X-Small";
            break;

        case "S":
            $size_str = "Small";
            break;

        case "M":
            $size_str = "Medium";
            break;

        case "L":
            $size_str = "Large";
            break;

        case "XL":
            $size_str = "X-Large";
            break;

        default:
            $size_str = $size;
    }
    //echo "size_str=".$size_str;
    $product = wc_get_product( $product_id );
    //echo $product->get_length() . get_option( 'woocommerce_dimension_unit' );
   /* $product_length = $product->get_length();
    $product_width  = $product->get_width();
    $product_height = $product->get_height();*/
    
    $product_length = get_post_meta($product_id,'product_length',true);
    $product_width  = get_post_meta($product_id,'product_width',true);
    $product_height = get_post_meta($product_id,'product_height',true);
    $dimensions_array = [];
    if( (double)$product_length * 1 ){
        $dimensions_array[] = "L " . $product_length . "''";
    }
    if( (double)$product_width * 1 ){
        $dimensions_array[] = "W " . $product_width . "''";
    }
    if( (double)$product_height * 1 ){
        $dimensions_array[] = "H " . $product_height . "''";
    }

    $dimensions_str = implode( " x ", $dimensions_array );

    if( $size_str ){
        echo '<span class="title-size">' . $size_str . ( $dimensions_str ? ' - ' . $dimensions_str : '') . '</span>';
    }else{
        if( $dimensions_str ){
            echo '<span class="title-size">' . $dimensions_str . '</span>';
        }
    }

}
add_action('woocommerce_single_product_summary', 'add_info_under_title', 6 );

function add_product_summary(){
    $product_id     = get_the_ID();
    $bold_product   = new BoldProduct( $product_id );

    //echo $bold_product->productSummary($product_id);
    echo $bold_product->productSummary();
    echo the_content();
    echo $bold_product->colorTable();

    do_action( 'woocommerce_before_add_to_cart_button' );

}

add_action('woocommerce_before_add_to_cart_form', 'add_product_summary', 20 );


function get_family_products(){
    global $product;
    $product_id=get_the_ID();

    $family = get_family($product_id);
    $family_cat_id= get_family_id($product_id);
    $categories=$product->get_category_ids();
    $link="#";

    //Holds by ID=12
    if(array_intersect (explode(",",get_post_meta(12, 'bold_product_category_id', true )),$categories)){
        $link="/holds/?cat[]=".$family_cat_id;
    }

    //Macros by ID=66
    if(array_intersect (explode(",",get_post_meta(66, 'bold_product_category_id', true )),$categories)){
        $link="/macros/?cat[]=".$family_cat_id;
    }

    //Volumes by ID=64
    if(array_intersect (explode(",",get_post_meta(64, 'bold_product_category_id', true )),$categories)){
        $link="/volumes/?cat[]=".$family_cat_id;
    }

    //Accessories by ID=40799
    if(array_intersect (explode(",",get_post_meta(40799, 'bold_product_category_id', true )),$categories)){
        $link="/all-accessories/?&product-family[]=".$family;
    }

    $output = '';
    $getvideolink = get_post_meta($product_id,'featured_video_link',true);
    //echo 'Iamhere'.$getvideolink;
    if($getvideolink){
        $output .= '<div class="videosectionproduct" style="text-align:center;"><iframe width="700" height="450" src="'.$getvideolink.'" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen style="width:95% !important;"></iframe></div>';
    }
    
    if($family){
        $output .= '<div class="family-heading h1 text-center">' . $family . '</div>';
        $output .= '<p class="family-p text-center">We Belong Together! Check out the full ' . $family . ' <a href="'.$link.'">HERE</a></p>';
    }
    $output .= display_family_products($product_id);
    return $output;
}

add_shortcode('woocommerce-family-products', 'get_family_products');

function get_related_products(){
    $output = '';
    $output .= '<img src="' . wp_get_attachment_image_src(172,'full')[0] . '" alt="Related Products" />';
    $output .= '<div class="family-heading h1 text-center">Related Products</div>';
    $output .= display_related_products(get_the_ID());
    return $output;
}

add_shortcode('woocommerce-related-products-bold', 'get_related_products');

function get_share_icons(){
    echo '<div class="share-wrapper">';
    echo '<span class="share">SHARE ON</span>';
    echo do_shortcode('[share-icons]');
    echo '</div>';
}

//add_action('woocommerce_after_add_to_cart_button', 'get_share_icons');

function get_share_icons_links(){
    $output = '';
    $output .= '<div class="share-social-wrapper">';
    $output .= '<a aria-label="Share on Facebook" href="#"><span class="fab fa-facebook"></span></a>';
    $output .= '<a class="twitter-share-button" aria-label="Share on Twitter" href="https://twitter.com/intent/tweet"><span class="fab fa-twitter"></span></a>';
    $output .= '</div>';
    return $output;
}

//add_shortcode('share-icons', 'get_share_icons_links');

// wholesale field

// Add Simple Product wholesale Field

// The code for displaying WooCommerce Product Custom Fields
//add_action( 'woocommerce_product_options_general_product_data', 'woocommerce_product_simple_wholesale_field' );

// Following code Saves  WooCommerce Product Custom Fields
//add_action( 'woocommerce_process_product_meta', 'woocommerce_product_wholesale_field_save' );

/*
function woocommerce_product_simple_wholesale_field()
{
    global $woocommerce, $post;
    echo '<div class="product_custom_field form-row form-row-full">';
    // Custom Product Text Field
    woocommerce_wp_text_input(
        array(
            'id' => '_wholesale_product_text_field',
            'placeholder' => 'Wholesale Price',
            'label' => __('Wholesale Price ($)', 'woocommerce'),
            'desc_tip' => 'true'
        )
    );

    echo '</div>';
}

function woocommerce_product_wholesale_field_save($post_id)
{
    // Custom Product Text Field
    $woocommerce_custom_product_text_field = $_POST['_wholesale_product_text_field'];
    if (!empty($woocommerce_custom_product_text_field))
        update_post_meta($post_id, '_wholesale_product_text_field', esc_attr($woocommerce_custom_product_text_field));

}
*/
// Add Variation Product wholesale field

// Create new fields for variations
/*
function woo_variable_fields( $loop, $variation_data, $variation ) {

  echo '<div class="variation-custom-fields">';

      // Text Field
      woocommerce_wp_text_input(
        array(
          'id'          => '_wholesale_variable_field['. $loop .']',
          'label'       => __( 'Wholesale Price ($)', 'woocommerce' ),
          'placeholder' => '5.00',
          //'desc_tip'    => true,
          'wrapper_class' => 'form-row form-row-full',
          //'description' => __( 'Enter the custom value here.', 'woocommerce' ),
          'value'       => get_post_meta($variation->ID, '_wholesale_variable_field', true)
        )
      );


  echo "</div>";

}

//Display Fields in admin on product edit screen
add_action( 'woocommerce_product_after_variable_attributes', 'woo_variable_fields', 10, 3 );
*/
/** Save new fields for variations */
function save_variation_fields( $variation_id, $i) {

    // Text Field
    $text_field = stripslashes( $_POST['_text_field'][$i] );
    //$back_order = stripslashes( $_POST['_backorder_future'][$i] );
    //$back_order_date = stripslashes( $_POST['_backorder_future_date'][$i] );
    update_post_meta( $variation_id, '_text_field', esc_attr( $text_field ) );
    //update_post_meta( $variation_id, '_backorder_future', esc_attr( $back_order ) );
    //update_post_meta( $variation_id, '_backorder_future_date', esc_attr( $back_order_date ) );

}

//Save variation fields values
add_action( 'woocommerce_save_product_variation', 'save_variation_fields', 10, 2 );

// add backorder/future stock fields to variations

// Create new fields for backorder/future order
/*
function woo_variable_fields_backorder_future( $loop, $variation_data, $variation ) {

  echo '<div class="variation-custom-fields">';

      // Text Field
      woocommerce_wp_text_input(
        array(
          'id'          => '_backorder_future['. $loop .']',
          'label'       => __( 'Backorder/Future Order Quantity', 'woocommerce' ),
          'placeholder' => '0',
          //'desc_tip'    => true,
          'wrapper_class' => 'form-row form-row-full',
          //'description' => __( 'Enter the custom value here.', 'woocommerce' ),
          'value'       => get_post_meta($variation->ID, '_backorder_future', true)
        )
      );


  echo "</div>";

}

//Display Fields in admin on product edit screen
add_action( 'woocommerce_product_after_variable_attributes', 'woo_variable_fields_backorder_future', 10, 3 );

// add date in stock for future order

function woo_variable_fields_backorder_future_date( $loop, $variation_data, $variation ) {

  echo '<div class="variation-custom-fields">';

      // Text Field
      woocommerce_wp_text_input(
        array(
          'id'          => '_backorder_future_date['. $loop .']',
          'label'       => __( 'Backorder/Future Date in Stock', 'woocommerce' ),
          'placeholder'       => 'YYYY-MM-DD',
          'type' => 'text',
          'class' => 'date-picker hasDatepicker',
          'wrapper_class' => 'form-row form-row-full',
          //'desc_tip'    => true,
          //'description' => __( 'Enter the custom value here.', 'woocommerce' ),
          'value'       => get_post_meta($variation->ID, '_backorder_future_date', true),
          'custom_attributes' => array(
              'pattern' => apply_filters( 'woocommerce_date_input_html_pattern', '[0-9]{4}-(0[1-9]|1[012])-(0[1-9]|1[0-9]|2[0-9]|3[01])' ),
          ),
        )
      );


  echo "</div>";

}

//Display Fields in admin on product edit screen
add_action( 'woocommerce_product_after_variable_attributes', 'woo_variable_fields_backorder_future_date', 10, 3 );
*/

// custom fields to checkout
/*
function new_peanut_field( $checkout ) {
    woocommerce_form_field( 'peanut_allergy', array(
    'type' => 'radio',
    'class' => array( 'form-row-wide', 'update_totals_on_change' ),
    'options' => array('1' => 'Yes','2' => 'No',),
    'label'  => __("Are you allergic to peanuts?"),
    'required'=>true,
    ), $checkout->get_value('peanut_allergy'));
}
add_action( 'woocommerce_after_checkout_billing_form', 'new_peanut_field' );
*/

add_action('woocommerce_after_order_notes', 'custom_checkout_field');
function custom_checkout_field($checkout){
    $shipping_country = WC()->session->get('customer')['shipping_country'];
    //echo "shipping_country=".$shipping_country;


    //echo bold_customers_outside
    $user_id = get_current_user_id();

    $bold_customers_outside = get_user_meta($user_id, 'bold_customers_outside', true );

    if(!$bold_customers_outside){
        $bold_customers_outside = 'bold';
    }
    $class_hide="";
    if($shipping_country == "US"){
        $class_hide="broker_block_hide";
    }

    echo '<div id="custom_checkout_broker_field" class="broker_fields_block '.$class_hide.'"><h3>Custom broker</h3>';
    $options = array(
        'bold' => "Use Bold Climbing's Customs Broker",
        'own' => 'Use our own Customs Broker'
    );
  
	
    woocommerce_form_field('bold_customers_outside', array(
        'type' => 'radio',
        'options'=> $options,
        'default' => $bold_customers_outside,
    ),
        $checkout->get_value('bold_customers_outside'));


    $bold_custom_broker = get_user_meta($user_id, 'bold_custom_broker', true );

    woocommerce_form_field('bold_custom_broker', array(
        'type' => 'text',
        'label'=> 'Custom broker',
        'class'=> [ 'hide_broker_'.$bold_customers_outside, 'broker_bold_field' ],
        'default'=>$bold_custom_broker
    ),
        $checkout->get_value('bold_custom_broker'));


    $bold_custom_broker_number = get_user_meta($user_id, 'bold_custom_broker_number', true );
    woocommerce_form_field('bold_custom_broker_number', array(
        'type' => 'text',
        'label'=>'Custom broker number',
        'class'=> [ 'hide_broker_'.$bold_customers_outside, 'broker_bold_field' ],
        'default'=>$bold_custom_broker_number
    ),
        $checkout->get_value('bold_custom_broker_number'));

    
    echo '</div>';
}





function md_custom_woocommerce_checkout_fields( $fields )
{
    $fields[ 'order' ][ 'order_comments' ][ 'placeholder' ] = 'Special notes';
    $fields[ 'order' ][ 'order_comments' ][ 'label' ] = '<h3>Special Notes</h3><p>Need a custom color? Have a special request? Need your order delivered in time for a comp or event?</p>';

    $fields[ 'order' ][ 'company_po' ][ 'placeholder' ] = 'Company PO#';
    $fields[ 'order' ][ 'company_po' ][ 'label' ] = '<h3>Company PO</h3>';


    return $fields;
}
add_filter( 'woocommerce_checkout_fields', 'md_custom_woocommerce_checkout_fields' );

// cart page magic

// line pages

function get_brand_title( $atts ){

    $atts = shortcode_atts( array(
        'title' => '',
        'logo' => '',
    ), $atts );

    $title  = $atts[ 'title' ];
    $logo   = $atts[ 'logo' ];

    $output = '';
    $output .= '<span class="family-heading h1">' . $title . '</span>';
    return $output;

}

add_shortcode( 'brand-title', 'get_brand_title' );

function get_brand_item( $atts ){

    $atts = shortcode_atts( array(
        'title'         => '',
        'img'           => '',
        'line'          => '',
        'type'          => '',
        'product_brand' => '',
    ), $atts );

    $title  = $atts[ 'title' ];
    $img    = $atts[ 'img' ];
    $line   = $atts[ 'line' ];
    $type   = $atts[ 'type' ];
    $brand  = $atts[ 'product_brand' ];

    if( $type == 'macros' ){
        $type = 'macros';
    }

    //$link = home_url() . '/' . $type . '/?product_type=' . $type . '&price-filter-min=0&price-filter-max=2000&product-brand=' . $brand . '&product-family=' . $line . '&action=product-search';

    $link = home_url() . '/' . $type . '/?product-brand[]=' . $brand . '&product-family[]=' . $line;

    if( $img == '' ){
        $img = wp_get_attachment_url(34169);
    }

    $output = '';

    $output .= '<div class="col-md-4 col-sm-6 col-xs-12">';
    $output .= '<a class="brand-item-link" href="' . $link . '"><div class="brand-item-image" style="background-image: url(' . $img . ');"></div></a>';
//    $output .= '<span class="family-heading h1">' . $title . '</span>';
    $output .= '<a class="brand-item-link" href="' . $link . '">' .  $line . '</a>';
    $output .= '</div>';

    return $output;

}

add_shortcode('brand-item','get_brand_item');


function get_bold_lines($attr){
    $category_id = $attr[ 'category-id' ];
    $BoldLines = new BoldLines( $category_id );
    return $BoldLines->category_lines();
}
add_shortcode('bold-lines','get_bold_lines');


function get_cart_disclaimers($type){

    $cart_contents = WC()->cart->get_cart();

    foreach( $cart_contents as $cart_item_key => $cart_item ){

        $product_data = $cart_item;


        $product_id = $cart_item['product_id'];
        $_product = wc_get_product( $product_id );
        $product_size = get_post_meta($product_id, 'bold_product_size', true);
        $product_brand = get_brand($product_id);
        $product_type = get_type($product_id);
        $product_family = get_family($product_id);

        $product_ship_type = get_post_meta( $product_id, 'bold_product_quote_pallet', true );
        $product_mto = get_post_meta( $product_id, 'bold_product_stock_mto', true );

        // quote

        if( $product_ship_type == $type ){
            $type = 'Quote';
            return $type;
        }

        // mto

        if( $product_mto == $type ){
            $type = 'MTO';
            return $type;
        }

        // pallet

        if( $product_ship_type == $type ){
            $type = 'Pallet';
            return $type;
        }

    }

    //return $type;

}
/**/
function check_mto( $product_id ){

    if( get_post_meta( $product_id, 'bold_product_stock_mto', true ) == 'MTO'){
        return '<span class="product-shipping-marker">MTO</span>';
    }
}


function check_quote($product_id){

    if( get_post_meta( $product_id, 'bold_product_quote_pallet', true ) == 'Quote'){
        return '<span class="product-shipping-marker">Quote</span>';
    }

}

function get_shipping_preferences_cart(){

    if ( isset($_COOKIE['bold_shipping_option']) and  $_COOKIE['bold_shipping_option'] == "ship-separate"){
        $ship_option1 = "";
        $ship_option2 = "checked";
    }else{
        $ship_option1 = "checked";
        $ship_option2 = "";
    }

    // Start --- %  give a warning Message to customer
    $cart = WC()->cart;
    if (empty($cart->get_cart())) {
        return;
    }
    global $wpdb;
    $user_id = get_current_user_id();
    $isWholesaleUser = false;
    if ($user_id) {
        $user_meta = get_userdata($user_id);
        $isWholesaleUser = in_array('wholesale_customer', $user_meta->roles);
    }
    
    $_itemtotal = 0;
    $total_qty = 0;
    $current_stock_total = 0;
    $future_stock_total = 0;
    $mto_stock_total = 0;

    foreach ($cart->get_cart() as $cart_item_key => $cart_item) {
        $product_id = $cart_item['product_id']; 
        $product = wc_get_product($product_id);
        if ($product->is_type('variable')) {
            $variation_id = $cart_item['variation_id'];
            $variation = wc_get_product($variation_id);
        } else {
            $variation = $product;
            $variation_id = $product_id;
        }

        $quantity = $cart_item['quantity'];
        $total_qty += $quantity;
        $_itemtotal += $cart_item['line_total'];
        
        $current_stock = get_option('percentage_of_current_product') ? get_option('percentage_of_current_product') : 0;
        $future_stock = get_option('percentage_of_future_product') ? get_option('percentage_of_future_product') : 0;
        
        if ($current_stock != 0 || $future_stock != 0) {
            $sql_inbound = $wpdb->prepare(
                "SELECT wm.stock_quantity as inbound_stock 
                FROM wp_atum_inventories wi
                LEFT JOIN wp_atum_inventory_meta wm ON wi.id = wm.inventory_id
                WHERE wi.product_id = %d AND wi.priority = 1",
                $variation_id
            );

            $future_stock_item = $wpdb->get_var($sql_inbound);
            $future_stock_item = $future_stock_item ? $future_stock_item : 0;

            $current_stock_item = $wpdb->get_var(
                $wpdb->prepare(
                    "SELECT stock_quantity FROM wp_wc_product_meta_lookup WHERE product_id = %d",
                    $variation_id
                )
            );
            $current_stock_item = $current_stock_item ? $current_stock_item : 0;

            if ($quantity <= $current_stock_item) {
                $current_stock_total += $quantity;
            } else {
                $current_stock_total += $current_stock_item;
                $remaining_qty = $quantity - $current_stock_item;

                if ($remaining_qty <= $future_stock_item) {
                    $future_stock_total += $remaining_qty;
                } else {
                    $future_stock_total += $future_stock_item;
                    $mto_stock_total += ($remaining_qty - $future_stock_item);
                }
            }
        }
    }

    $total_stock = $current_stock_total + $future_stock_total + $mto_stock_total;
    $current_condition = ($current_stock_total / $total_stock) * 100;
    $current_future_condition = (($current_stock_total + $future_stock_total) * 100) / $total_stock;
    $return_val = 0;
    if ($current_stock != 0 || $future_stock != 0) {
        if ($current_condition > $current_stock && $current_condition <= 99.99) {
            // wc_print_notice('It looks like most of your order is from current stock, but a few items you selected are coming from future stock or are MTO (Made to order). If you need all your items to come from current stock, please replace these items.', 'notice');
            echo '<div class="percentage_warning_msg">
                    <p style="text-align:center; color:red;">It looks like most of your order is from current stock, but a few items you selected are coming from future stock or are MTO (made to order).</p>
                    <p style="text-align:center; color:red;>If you need all your items to come from current stock, please replace these items.</p>
                  </div>';
            $return_val = 1;
        }

        if ($current_future_condition > $future_stock && $current_future_condition <= 99.99) {
            if($return_val == 0){
                //wc_print_notice('It looks like most of your order is from current or future stock, but a few items you selected are MTO (made to order). If you need all your items to come from current or future stock, please replace these items.', 'notice');
               echo '<div class="percentage_warning_msg">
                        <p style="text-align:center; color:red;">It looks like most of your order is from current or future stock, but a few items you selected are MTO (made to order).</p>
                        <p style="text-align:center; color:red;> If you need all your items to come from current or future stock, please replace these items.</p>
                    </div>';
            }
        }
    }
    // End

    echo '<div class="col-md-6">
            <div class="header-title h1">Shipping Times</div>
            <p>In-stock items usually ship in 1-5 business days</p>
            <p>Holds usually ship in 4-12 weeks depending on manufacturer</p>
            <p>If items are out of stock or MTO shipping time can vary</p>

            <div class="header-title h1">Shipping Preference</div>
            <p>*Please choose your prefered shipping preference:</p>
            <!--
            <ul class="shipping-preference">
                <li> In-stock volumes & fiberglass ships in 3-5 business days.</li>
                <li>* Other in-stock products ships in 2 business days.</li>
                <li>* Holds ship in 4-8 weeks.</li>
            </ul>
            -->
        </div>
        <div class="col-md-12 shipping-options">
            <div class="choice"><input '.$ship_option1.' type="radio" name="ship-options" value="ship-together" id="ship-together"> <label for="ship-together"><b>Ship order when all products are in stock</b> - Cheapest</label></div>
            <div class="choice"><input '.$ship_option2.' type="radio" name="ship-options" value="ship-separate" id="ship-separate"> <label for="ship-separate"><b>Ship as soon as possible (multiple shipments)</b> - Quickest</label></div>
            <!--<div class="choice"><input type="radio" name="ship-options" value="ship-manufacturer" id="ship-manufacturer"> <label for="ship-manufacturer"><b>Ship direct from manufacturer</b> - Quickest if in stock</label></div>-->
            <p>Questions? See our <a href="/ordering-info/">ordering info page</a> for more details.</p>
            <p>Still have question? Give us as call at '.do_shortcode('[ws-phone-link]').' between 9am-5pm PST or email us at ' . do_shortcode('[ws-business-info key="email"]') . '</p>
            <!--
            <p>Can be more expensive but all products available. Best for orders over 10k. Choose any product, any color and any customization. Usually delivered in 1-3 months.</p>
            <p>See our <a href="' . get_permalink(28) . '">shipping page</a> for more info.</p>
            <p>Contact us at ' . do_shortcode('[ws-phone-link]') . ' or ' . do_shortcode('[ws-business-info key="email"]') . ' with any other questions.</p>
            -->
        </div>';

    ?>
    <div class="ramsingh">
        <input type="hidden" name="nnam" value="10">
    </div>
    <?php
    

}

add_action('woocommerce_after_cart_table', 'get_shipping_preferences_cart', 9);



function footer_support_brands($atts){

    $atts = shortcode_atts( array(
        'imgs' => '',

    ), $atts );

    $output = '';

    $output .= '<div class="logo-container">';
    $output .= '<span>Support the brands that support the sport</span>';
    $output .= '<div>';

    $imgs = explode(',', $atts['imgs']);

    foreach( $imgs as $img ){
        $output .= wp_get_attachment_image($img, 'full');
    }

    $output .= '</div>';
    $output .= '</div>';

    return $output;

}

add_shortcode('footer-brands', 'footer_support_brands');

function check_pallet_product(){
    $cart = WC()->cart->get_cart();

    foreach($cart as $cart_item) {

        $product_id = $cart_item['product_id'];
        $quote_pallet = get_post_meta($product_id, 'bold_product_quote_pallet', true );

        if( $quote_pallet == 'Pallet' ){
            return true;
        }
    }

}

/*
function check_mto_product(){
    $cart = WC()->cart->get_cart();

    foreach($cart as $cart_item) {

        $product_id = $cart_item['product_id'];
        $mto = get_post_meta($product_id, 'bold_product_stock_mto', true );

         if( $mto == 'MTO' ){
            return true;
         }
    }

}

function check_mto_product_count(){
    $cart = WC()->cart->get_cart();
    $mto_count = array();

    foreach($cart as $cart_item) {

        $product_id = $cart_item['product_id'];
        $mto = get_post_meta($product_id, 'bold_product_stock_mto', true );

         if( $mto == 'MTO' ){
            $mto_count[] = $product_id;
         }
    }

    return count($mto_count);
}

/*** Pallet Shipping Rules ***/
/*
function calculate_pallet_shipping_cost( $package ){

    if( is_admin() && !defined('DOING_AJAX') )
        return;

    global $woocommerce;

    //
    // check which option is checked
    // ship-together - ship when all products are in stock
    // ship-separate - ship products in stock now, rest later
    // ship-manufacturer - ship directly from manufacturer


    // get choice selected from input in cart-totals

    $new_cart = array();
    $cart = WC()->cart->get_cart();
    $product_ids_with_mto = array();
    $compx_product = false;
    $pallet_product = check_pallet_product();
    $mto_product = check_mto_product();
    $mto_product_count = check_mto_product_count();
    $line_items = count( $woocommerce->cart->get_cart() );
//
//    print_r($line_items);
//    print_r($mto_product_count);

    // check if array contains a pallet product

     // Loop through line items
     foreach($cart as $cart_item) {

        // Get product id
       $product_id = $cart_item['product_id'];

//       $stock_qty = $product->get_stock_quantity();

       $item_qty  = $cart_item['quantity'];
       $mto = get_post_meta($product_id, 'bold_product_stock_mto', true );
       $quote_pallet = get_post_meta($product_id, 'bold_product_quote_pallet', true );
       $compx = get_post_meta($product_id, 'bold_product_manufacturer', true );

          $product = wc_get_product( $product_id );

          if( $mto != 'MTO' && $quote_pallet != 'Quote' ) { // if mto / quote remove from shipping costs - website will not calculate, pallet calculated next
              echo "ok1";
              if( $pallet_product === true ){
                   $cart_item['data']->set_shipping_class_id('436');
              }

              array_push($new_cart, $cart_item);

          }elseif( $mto_product === true && ( $mto_product_count == $line_items ) ) { // check that only MTO products are in cart
               array_push($new_cart, $cart_item);
          }

          // if proxy - change zip to 84104



   }

   $package[0]['contents'] = $new_cart;

   return $package;

}

/*
add_filter('woocommerce_cart_shipping_packages', 'calculate_pallet_shipping_cost', 10, 1);
function custom_shipping_rates($rates, $pkg) {
    echo "custom_shipping_rates";
    echo "rates";
    print_r($rates);
    echo "!";

   if ( is_admin() && ! defined( 'DOING_AJAX' ) ) return;

   global $woocommerce;

    //woocommerce_wf_shipping_ups_origin_postcode

   $mto_quote_product = check_mto_product();
   $compx_product = false;
   $proxy_product = false;
   $quote_pallet_product = false;
   $mto_product_count = check_mto_product_count();
   $line_items = count( $woocommerce->cart->get_cart() );

   $compx_calculation = array();
   $proxy_calculation = array();


   // Loop through line items for compx calcuation
   foreach( $pkg['contents'] as $line_item ) {

       $product_id = $line_item['product_id'];
       $quote_pallet = get_post_meta($product_id, 'bold_product_quote_pallet', true );
       $compx = get_post_meta($product_id, 'bold_product_manufacturer', true );
       $proxy = get_post_meta($product_id, 'bold_product_manufacturer', true );
       $product = wc_get_product( $product_id );
       $weight = $product->get_weight();
       $quantity = $line_item['quantity'];
       //echo "compx=".$compx."<br/>";

       if( $compx == 'Composite-X' ){
           $compx_product = true;
           $compx_calculation[] = 50.00 + $weight * $quantity;
       }

       if( $proxy == 'Proxy' ){
           $proxy_product = true;
       }

       // this will only work if not MTO

       if( $quote_pallet == 'Pallet' ){
           $quote_pallet_product = true;
       }

    }

    $compx_rate = array_sum($compx_calculation);
    //print_r($compx_calculation);
    //echo $compx_rate;

     // pallet rates
     // STD
     // GSDS
     // GSAM
     // GSHW
     //

    $r_l_keys = array('STD', 'GSDS', 'GSAM', 'GSHW' );
    $usps_rate_keys = array(
        'wf_shipping_usps:D_EXPRESS_MAIL',
        'wf_shipping_usps:D_MEDIA_MAIL',
        'wf_shipping_usps:D_LIBRARY_MAIL',
        'wf_shipping_usps:D_PRIORITY_MAIL'
    );

    $new_rates = array();

   if( $mto_product_count != $line_items ) { // regular cart rates including compx, and R+L, proxy

    foreach( $rates as $rate_key => $rate ){

            // check if single compx product
             if( $rate_key == 'flat_rate:3' && count($pkg['contents']) < 2 && $compx_product === true ){
                 $rates[$rate_key]->cost = $compx_rate;
                 return $rates;
             }elseif( count($pkg['contents']) < 2 && isset($rates['flat_rate:3']) ){
                 unset( $rates['flat_rate:3'] );
             }

             if( $quote_pallet_product === true ){ // for freight and pallet shipping

                // check for compx calcuation and pallet shipping

                if( in_array($rate_key, $r_l_keys) && $compx_product === true ){

                        $original_cost = $rates[$rate_key]->cost;

                        if( $rates[$rate_key]->cost ){
                          $rates[$rate_key]->cost = $original_cost + $compx_rate;
                          $new_rates[] = $rate;
                        }

                 }

             }else{

                 //
                    if( !in_array($rate_key, $usps_rate_keys) && $proxy_product === true ){ // UPS RATES ONLY for PROXY
                        echo 'test';
                       // add compx to existing rates and remove the compx (flat_rate:3) option
                         if( count($pkg['contents']) >= 2 && $compx_product === true ){

                              $original_cost = $rates[$rate_key]->cost;

                              if( $rates[$rate_key]->cost ){
                                  $rates[$rate_key]->cost = $original_cost + $compx_rate;
                                  $new_rates[] = $rate;
                              }

                         }elseif( $rate_key != 'flat_rate:3' && $rate_key != 'local_pickup:2' ){ // remove compx and MTO rate keys
                              $new_rates[] = $rate;
                         }
                    }else if( !in_array($rate_key,$r_l_keys) && $proxy_product === false ){ // for all other shipping methods

                         // add compx to existing rates and remove the compx (flat_rate:3) option
                         if( count($pkg['contents']) >= 2 && $compx_product === true ){

                              $original_cost = $rates[$rate_key]->cost;

                              if( $rates[$rate_key]->cost ){
                                  $rates[$rate_key]->cost = $original_cost + $compx_rate;
                                  $new_rates[] = $rate;
                              }

                         }elseif( $rate_key != 'flat_rate:3' && $rate_key != 'local_pickup:2' ){ // remove compx and MTO rate keys
                              $new_rates[] = $rate;
                         }

                     }
             }
     }
     return $new_rates;

    }else if ( $mto_quote_product === true ) {  // cart has only MTO | Quote

      $new_rates['local_pickup:2'] = $rates['local_pickup:2'];
      return $new_rates;

   }
   return $rates;

}
add_filter('woocommerce_package_rates', 'custom_shipping_rates', 999, 2);
/*
function custom_shipping_rates($rates, $pkg) {
    print_r($rates);
    return [];
}
add_filter('woocommerce_package_rates', 'custom_shipping_rates', 999, 2);
/**/

/*
function available_shipping_methods($available_methods){

    //
    $local_rate = 0.02;
    $ups_rate = 0.05;
    $usps_rate = 0.02;
    $rl_rate = 0.02;

    //
    $user_id = get_current_user_id();
    $user_meta = get_userdata( $user_id );
    $isWholesaleCustomer = false;
    if( $user_id ){
        $isWholesaleCustomer = in_array( 'wholesale_customer', $user_meta->roles );
    }

    foreach ( WC()->cart->get_cart() as $cart_item_key => $cart_item ) {

    }
    //Disable free shipping for wholesale users
    if( $isWholesaleCustomer ){
        unset( $available_methods['free_shipping:6'] );
    }

    $total_cost_cart = WC()->cart->cart_contents_total;
    //print_r($available_methods);
    foreach($available_methods as $key=>$available_method){

        $method_name_arr = explode(":",$key);
        $method_name = $method_name_arr[ 0 ];

        switch ($method_name){
            case 'local_pickup':        //Local pickup
                $available_method->cost = $total_cost_cart * $local_rate;
            break;

            case 'wf_shipping_ups':     //UPS Shipping
                $available_method->cost = $available_method->cost + $total_cost_cart * $ups_rate;
            break;

            case 'wf_shipping_usps':    //USPS Shipping
                $available_method->cost = $available_method->cost + $total_cost_cart * $usps_rate;
            break;

            case 'rlc':    //USPS Shipping
                $available_method->cost = $available_method->cost + $total_cost_cart * $rl_rate;
            break;




        }
    }

    //free_shipping


    //unset( $available_methods['local_pickup:2'] );
    //unset( $available_methods['flat_rate:3'] );
    return $available_methods;

}
function available_shipping_methods($available_methods){
#add_filter( 'woocommerce_package_rates', 'available_shipping_methods', 10, 2 );
*/
/*
function bulky_cw_woocommerce_package_cart( $packages ){

    //print_r( $packages );
    foreach ( WC()->cart->get_cart() as $item ) {
        $bulk_products[] = $item;


        if ( $item['data']->needs_shipping() ) {
            if ( $item['data']->get_shipping_class() == 'free' ) {
                $bulk_products[] = $item;
            } else {
                $regular_products[] = $item;
            }
        }


    }

    $packages[] = array(
        'ship_via'        => array( 'free_shipping' ),
        'contents'        => $bulk_products,
        'contents_cost'   => array_sum( wp_list_pluck( $bulk_products, 'line_total' ) ),
        'applied_coupons' => WC()->cart->applied_coupons,
        'destination'     => array(
            'country'   => WC()->customer->get_shipping_country(),
            'state'     => WC()->customer->get_shipping_state(),
            'postcode'  => WC()->customer->get_shipping_postcode()
         )
    );
    $packages[] = array(
        'ship_via'        => array( 'free_shipping' ),
        'contents'        => $bulk_products,
        'contents_cost'   => array_sum( wp_list_pluck( $bulk_products, 'line_total' ) ),
        'applied_coupons' => WC()->cart->applied_coupons,
        'destination'     => array(
            'country'   => WC()->customer->get_shipping_country(),
            'state'     => WC()->customer->get_shipping_state(),
            'postcode'  => WC()->customer->get_shipping_postcode()
         )
    );

    return $packages;

}
add_filter( 'cw_woocommerce_package_cart', 'bulky_cw_woocommerce_package_cart' );
*/


//function available_shipping_methods($available_methods){
//$boldShipping = new BoldShipping;
//return $boldShipping->getMethods($available_methods);
//}

function available_shipping_methods( $rates, $package ){
    $boldShipping   = new BoldShipping( false );
    $rates_list     = $boldShipping->getMethods( $rates, $package );
    
    $user_id = get_current_user_id();

    $wholesale_user = false;

    if( $user_id ){
        $user_meta = get_userdata( $user_id );
        $wholesale_user = in_array( 'wholesale_customer', $user_meta->roles );
    }
    
    $rates_for_formula = array( "STD", "GSDS", "wf_shipping_ups" );

    foreach( $rates_list as $key=>$rate ){
        //Formula will be apply if:

        if ( $key == "STD" or $key == "GSDS" ){
            $rates_array [ 'rls' ][] = Array(
                "key"   => $key,
                "cost"  => $rate->cost
            );
            continue;
        }
        if ( strpos( $key, 'wf_shipping_ups' ) !== false ){
            $rates_array [ 'ups' ][] = Array(
                "key"   => $key,
                "cost"  => $rate->cost
            );
            continue;
        }
        if ( strpos( $key, 'wf_shipping_usps' ) !== false ){
            $rates_array [ 'usps' ][] = Array(
                "key"   => $key,
                "cost"  => $rate->cost
            );
            continue;
        }

        if ( strpos( $key, 'flat_rate' ) !== false ){
            $rates_array [ 'flat_rate' ][] = Array(
                "key"   => $key,
                "cost"  => $rate->cost
            );
            continue;
        }
        $rates_array [ $key ][] = Array(
            "key"   => $key,
            "cost"  => $rate->cost
        );
    }

    foreach( $rates_array as $key=>$rates_array_item ){
        $temp = $rates_array_item;
        usort( $temp, function( $a, $b ){
            return ( $a[ 'cost' ] - $b[ 'cost' ] );
        } );
        $rates_array[ $key ] = $temp;
    }

    $exclude_formula = [ 'wf_shipping_ups:12'];

    $ups_multiply = get_option( 'dkabz_ups_rate_fix' ) ? get_option( 'dkabz_ups_rate_fix' ) : 1;
    $usps_multiply = get_option( 'dkabz_usps_rate_fix' ) ? get_option( 'dkabz_usps_rate_fix' ) : 1;
    $rl_multiply = get_option( 'dkabz_rl_rate_fix' ) ? get_option( 'dkabz_rl_rate_fix' ) : 1;


    $min_percent = get_option( 'dkabz_minperc_noshipping' ) ? get_option( 'dkabz_minperc_noshipping' ) : 0;
    $max_percent = get_option( 'dkabz_maxperc_noshipping' ) ? get_option( 'dkabz_maxperc_noshipping' ) : 100;
    $min_pack_cost = get_option( 'dkabz_amout_noshipping' ) ? get_option( 'dkabz_amout_noshipping' ) : 0;

    // 16-Oct-23
    $ups_ground_total_amount = get_option( 'ups_ground_total_amount' ) ? get_option( 'ups_ground_total_amount' ) : 0;
    $ups_usps_ground_minimum_amount = get_option( 'ups_usps_ground_minimum_amount' ) ? get_option( 'ups_usps_ground_minimum_amount' ) : 0;
    $frieght_total_amount = get_option( 'frieght_total_amount' ) ? get_option( 'frieght_total_amount' ) : 0;
    $frieght_minimum_amount = get_option( 'frieght_minimum_amount' ) ? get_option( 'frieght_minimum_amount' ) : 0;
    
    $use_formula = false;

    if ( $package[ 'totalamount' ] >= $ups_ground_total_amount ){
        $use_formula_for_UPS = true;
        
    }
    else{
        $use_formula_for_UPS = false;
        
    }
    if ( $package[ 'totalamount' ] >= $frieght_total_amount ){
        $use_formula_for_frieght = true;
        
    }
    else{
        $use_formula_for_frieght = false;
        
    }
    $applied_coupons = WC()->cart->get_applied_coupons();
    $specific_coupon_applied = in_array( 'stronghold', $applied_coupons );

    $final_rates = [];
    if( isset( $rates_array[ 'ups' ] ) ){
        foreach( $rates_array[ 'ups' ] as $itm ){
            $cost = $rates_list[ $itm[ 'key' ] ]->cost + $package[ 'totalamount' ] * $ups_multiply / 100;
            if( !in_array( $itm[ 'key' ], $exclude_formula ) and $use_formula_for_UPS and $package[ 'totalamount' ] ){
                $percent_shipping = 100 * $cost / $package[ 'totalamount' ];
                if( $percent_shipping < $min_percent ){
                    $cost = round( $package[ 'totalamount' ] * $min_percent / 100, 2 );
                }
                if( $percent_shipping > $max_percent ){
                    $cost = round( $package[ 'totalamount' ] * $max_percent / 100, 2 );
                }
            }
            if($cost < $ups_usps_ground_minimum_amount){
                $cost = $ups_usps_ground_minimum_amount;
            }
            // Add Percentage 
            if($specific_coupon_applied){
                $total_amount = $package[ 'totalamount' ];
                $percentage = 4;
                $cost = ($percentage / 100) * $total_amount;
            }
            // End
            $rates_list[ $itm[ 'key' ] ]->cost = $cost;
            $final_rates[ $itm[ 'key' ] ] = $rates_list[ $itm[ 'key' ] ];
        }
        
    }
    if( isset( $rates_array[ 'rls' ] ) ){
        foreach( $rates_array[ 'rls' ] as $itm ){
            $cost = $rates_list[ $itm[ 'key' ] ]->cost + $package[ 'totalamount' ] * $rl_multiply / 100;
            if( $use_formula_for_frieght and $package[ 'totalamount' ] ){
                $percent_shipping = 100 * $cost / $package[ 'totalamount' ];
                if( $percent_shipping < $min_percent ){
                    $cost = round( $package[ 'totalamount' ] * $min_percent / 100, 2 );
                }
                if( $percent_shipping > $max_percent ){
                    $cost = round( $package[ 'totalamount' ] * $max_percent / 100, 2 );
                }
            }
            if($cost < $frieght_minimum_amount){
                $cost = $frieght_minimum_amount;
            }

            // Add Percentage 
            if($specific_coupon_applied){
                $total_amount = $package[ 'totalamount' ];
                $percentage = 4;
                $cost = ($percentage / 100) * $total_amount;
            }
            // End

            $rates_list[ $itm[ 'key' ] ]->cost = $cost;
            $final_rates[ $itm[ 'key' ] ] = $rates_list[ $itm[ 'key' ] ];
        }
    }
    //----Old Code----//
    /*if( isset( $rates_array[ 'ups' ] ) ){
        foreach( $rates_array[ 'ups' ] as $itm ){
            //$cost = $rates_list[ $itm[ 'key' ] ]->cost * $ups_multiply;
            //$cost = $package[ 'cost' ] * $ups_multiply;

            $cost = $rates_list[ $itm[ 'key' ] ]->cost + $package[ 'contents_cost' ] * $ups_multiply / 100;

            if( !in_array( $itm[ 'key' ], $exclude_formula ) and $use_formula and $package[ 'contents_cost' ] ){
                $percent_shipping = 100 * $cost / $package[ 'contents_cost' ];
                if( $percent_shipping < $min_percent ){
                    $cost = round( $package[ 'contents_cost' ] * $min_percent / 100, 2 );
                }
                if( $percent_shipping > $max_percent ){
                    $cost = round( $package[ 'contents_cost' ] * $max_percent / 100, 2 );
                }
            }

            $rates_list[ $itm[ 'key' ] ]->cost = $cost;
            $final_rates[ $itm[ 'key' ] ] = $rates_list[ $itm[ 'key' ] ];
        }
    }
    if( isset( $rates_array[ 'rls' ] ) ){
        foreach( $rates_array[ 'rls' ] as $itm ){
            //echo "contents_cost=".$package[ 'contents_cost' ];
            //$cost = $rates_list[ $itm[ 'key' ] ]->cost * $rl_multiply;
            $cost = $rates_list[ $itm[ 'key' ] ]->cost + $package[ 'contents_cost' ] * $rl_multiply / 100;

            //$cost = $package[ 'cost' ] * $rl_multiply;
            //$cost = $package[ 'contents_cost' ];

            if( $use_formula and $package[ 'contents_cost' ] ){
                $percent_shipping = 100 * $cost / $package[ 'contents_cost' ];
                if( $percent_shipping < $min_percent ){
                    $cost = round( $package[ 'contents_cost' ] * $min_percent / 100, 2 );
                }
                if( $percent_shipping > $max_percent ){
                    $cost = round( $package[ 'contents_cost' ] * $max_percent / 100, 2 );
                }
            }


            $rates_list[ $itm[ 'key' ] ]->cost = $cost;
            $final_rates[ $itm[ 'key' ] ] = $rates_list[ $itm[ 'key' ] ];
        }
    }
    */
    if( isset( $rates_array[ 'flat_rate' ] ) ){
        foreach( $rates_array[ 'flat_rate' ] as $itm ){
            $final_rates[ $itm[ 'key' ] ] = $rates_list[ $itm[ 'key' ] ];
        }
    }

    if( isset( $rates_array[ 'flat_rate' ] ) ){
        foreach( $rates_array[ 'flat_rate' ] as $itm ){
            $final_rates[ $itm[ 'key' ] ] = $rates_list[ $itm[ 'key' ] ];
        }
    }

    if( isset( $rates_array[ 'proxy_shipping' ] ) ){
        foreach( $rates_array[ 'proxy_shipping' ] as $itm ){
            $final_rates[ $itm[ 'key' ] ] = $rates_list[ $itm[ 'key' ] ];
        }
    }

    if( isset( $rates_array[ 'aragon_shipping' ] ) ){
        foreach( $rates_array[ 'aragon_shipping' ] as $itm ){
            $final_rates[ $itm[ 'key' ] ] = $rates_list[ $itm[ 'key' ] ];
        }
    }


    if( isset( $rates_list[ 'local_pickup:5' ] ) ){
        $final_rates[ 'local_pickup:5' ] = $rates_list[ 'local_pickup:5' ];
    }

   
    if($wholesale_user){
        if( isset( $rates_list[ 'free_shipping:6' ] ) ){
            $final_rates[ 'free_shipping:6' ] = $rates_list[ 'free_shipping:6' ];
            unset( $final_rates[ 'free_shipping:6' ]);
        }
    }else{
        if( isset( $rates_list[ 'free_shipping:6' ] ) ){
            $final_rates[ 'free_shipping:6' ] = $rates_list[ 'free_shipping:6' ];
        }
    }

    if( isset( $rates_list[ 'kastline_pu' ] ) ){
        $final_rates[ 'kastline_pu' ] = $rates_list[ 'kastline_pu' ];
    }

    if( isset( $rates_list[ 'quote_required' ] ) ){
        $final_rates[ 'quote_required' ] = $rates_list[ 'quote_required' ];
    }
   
    return $final_rates;
}

add_filter( 'woocommerce_package_rates', 'available_shipping_methods', 10, 3 );


function custom_split_shipping_packages_shipping_class( $packages ) {

    $boldShipping = new BoldShipping( true );
    $packs = $boldShipping->getPackages();
    //print_r($packs);
    //print_r($packages);
    //print_r($packs);

    //return array_merge( $packages, $packages);
    //return $packs;
    //return $packages;
    //print_r($packages);
    //echo "!".$packages[0]['contents_cost']."!";
    //print_r($packs[0]['contents']);
    /*
    $pk[] = Array (
        'name'=>'test1',
        'contents'=>$packages[0]['contents'],
        'contents_cost'     => $packages[0]['contents_cost'],
        'ship_via'          => ['free_shipping'],
        'destination'       => $packages[0]['destination'],
        'user'              => $packages[0]['user']
    );
    $pk[] = Array (
        'name'=>'test2',
        'contents'=>$packages[1]['contents'],
        'contents_cost'     => $packages[1]['contents_cost'],
        'ship_via'          => ['free_shipping'],
        'destination'       => $packages[1]['destination'],
        'user'              => $packages[1]['user']
    );


    return $pk;

    //print_r($packages[0]['contents']);
    $pk = [];
    foreach($packs as $pack){
        //unset($pack['contents']);
        $temp = $pack;
        //unset($temp['contents']);
        $pk[] = $temp;
        //$pk[] = $pack;
    }
    return $pk;
    */
    return $packs;

}


add_filter( 'woocommerce_cart_shipping_packages', 'custom_split_shipping_packages_shipping_class', 10, 2 );

/**/
function rmg_package_names( $package_name, $i, $package ) {
    if ( ! empty( $package['name'] ) ) {
        $package_name = $package['name'];
    }
    return $package_name;
}
add_filter( 'woocommerce_shipping_package_name', 'rmg_package_names', 10, 3 );

/*
add_filter( 'woocommerce_cart_shipping_packages', 'disable_shipping_rates_cache' , 10, 2 );
function disable_shipping_rates_cache($packages) {
    print_r($packages[0]);
    //$packages[0]['contents'][0]['key']=rand();
    return $packages;
}
*/

/*
function ws_get_module( $section_id = 0 ) {

            if( ! $section_id ){
                return;
            }

            $meta_box_prefix = '_ws-';

            global $carousel_id;
            global $current_active_module;

            $current_active_module = $section_id;

            if ( ! isset( $carousel_id ) ) {
                $carousel_id = 0;
            } else {
                $carousel_id ++;
            }

            $section_slug                                  = 'section-' . $section_id;
            $wpautop                                       = true; //init
            $style                                         = 'display:block;clear:both;'; //default @todo - why aren't these baked into the CSS class?
            $outer_container_class                         = 'outer-container'; //default
            $module_template_class                         = ''; //default
            $inner_container_class                         = 'container'; //default
            $chrome_parallax_fix                           = $section_visibility_temp = ''; //strict PHP
            $section_visibility_array                      = ''; // it's really gonna be a string @todo - convert these over to real arrays with get_array_to_classnames
            $section_additional_classnames_array           = ''; // it's really gonna be a string
            $section_additional_container_classnames_array = ''; // it's really gonna be a string
            $section_html_id = ''; // it's really gonna be a string
            $ws_slider_module                              = '';
            $section_title                                 = '';
            $section_subtitle                              = '';
            $ws_slider_vars                                = '';
            $edit_section_string                           = ''; //blank by default, as it's always included in the final return. Will add the real link below if we're admins.

            if ( current_user_can( 'edit_posts' ) ) {
                $edit_section_string = '<a class="edit-section-link" href="' . get_edit_post_link( $section_id ) . '"><span class="' . get_array_to_classnames('fa-icon', fa_prefix(), 'fa-pencil') . '" aria-hidden="true"></span> EDIT</a>';
            }

            // Working postmetas
            // have a background color and image, so we need to overlay them
            if ( get_post_meta( $section_id, $meta_box_prefix . 'section_bg_color', true ) && get_post_meta( $section_id, $meta_box_prefix . 'section_bg_image', true ) ) {

                $background_color = get_post_meta( $section_id, $meta_box_prefix . 'section_bg_color', true );
                $background_image = get_post_meta( $section_id, $meta_box_prefix . 'section_bg_image', true );


                //    echo 'bg color: ' . $background_color;

                if ( apply_filters( 'ws_alternate_section_bg_technique', false, $section_id ) ) {
                    $style .= 'background:' . $background_color . ' url(' . $background_image . ');';
                } else {
                    $style .= 'background:linear-gradient( ' . $background_color . ', ' . $background_color . ' ),url(' . $background_image . ');';
                }

            } else {

                $style .= get_post_meta( $section_id, $meta_box_prefix . 'section_bg_color', true ) ? 'background-color:' . get_post_meta( $section_id, $meta_box_prefix . 'section_bg_color', true ) . ';' : '';
                $style .=get_post_meta( $section_id, $meta_box_prefix . 'section_bg_image', true ) ? 'background-image:url(' . get_post_meta( $section_id, $meta_box_prefix . 'section_bg_image', true ) . ');' : '';

            }


            $style .= get_post_meta( $section_id, $meta_box_prefix . 'section_bg_repeat', true ) ? 'background-repeat:' . get_post_meta( $section_id, $meta_box_prefix . 'section_bg_repeat', true ) . ';' : '';


            // if we've chosen a preset background size, we'll pull that, otherwise, we'll grab the custom one.
            if ( get_post_meta( $section_id, $meta_box_prefix . 'section_bg_size', true ) == 'other' ) {
                $style .= get_post_meta( $section_id, $meta_box_prefix . 'section_bg_size_custom', true ) ? 'background-size:' . get_post_meta( $section_id, $meta_box_prefix . 'section_bg_size_custom', true ) . ';' : '';
            } else {
                $style .= get_post_meta( $section_id, $meta_box_prefix . 'section_bg_size', true ) ? 'background-size:' . get_post_meta( $section_id, $meta_box_prefix . 'section_bg_size', true ) . ';' : '';
            }

            $style .= get_post_meta( $section_id, $meta_box_prefix . 'section_background_position', true ) ? 'background-position:' . get_post_meta( $section_id, $meta_box_prefix . 'section_background_position', true ) . ';' : '';
//          $style .= get_post_meta( $section_id, $meta_box_prefix . 'section_height', true ) ? 'height:' . get_post_meta( $section_id, $meta_box_prefix . 'section_height', true ) : '';
//          $style .= get_post_meta( $section_id, $meta_box_prefix . 'section_padding_top', true ) ? 'padding-top:' . get_post_meta( $section_id, $meta_box_prefix . 'section_padding_top', true ) . ';' : '';
//          $style .= get_post_meta( $section_id, $meta_box_prefix . 'section_padding_bottom', true ) ? 'padding-bottom:' . get_post_meta( $section_id, $meta_box_prefix . 'section_padding_bottom', true ) . ';' : '';
//          $style .= get_post_meta( $section_id, $meta_box_prefix . 'section_padding_left', true ) ? 'padding-left:' . get_post_meta( $section_id, $meta_box_prefix . 'section_padding_left', true ) . ';' : '';
//          $style .= get_post_meta( $section_id, $meta_box_prefix . 'section_padding_right', true ) ? 'padding-right:' . get_post_meta( $section_id, $meta_box_prefix . 'section_padding_right', true ) . ';' : '';
            $section_visibility_temp = get_post_meta( $section_id, $meta_box_prefix . 'section_responsive_visibility', true ) ? get_post_meta( $section_id, $meta_box_prefix . 'section_responsive_visibility', true ) : '';
            $wpautop = get_post_meta( $section_id, $meta_box_prefix . 'section_wpautop', true ) ? true : false; // YESSSSSS!!!!!
            $section_additional_classnames_array = get_post_meta( $section_id, $meta_box_prefix . 'section_additional_classnames', true ) ? get_post_meta( $section_id, $meta_box_prefix . 'section_additional_classnames', true ) : '';
            $section_additional_container_classnames_array = get_post_meta( $section_id, $meta_box_prefix . 'section_additional_container_classnames', true ) ? get_post_meta( $section_id, $meta_box_prefix . 'section_additional_container_classnames', true ) : '';

            $section_disable_row_class = get_post_meta( $section_id, $meta_box_prefix . 'section_disable_row_class', true ) ? true : false;




            // experimental auto height option
            if ( get_post_meta( $section_id, $meta_box_prefix . 'section_auto_min_height_bg', true ) && get_post_meta( $section_id, $meta_box_prefix . 'section_bg_image', true ) ) {

                $bg_img              = get_post_meta( $section_id, $meta_box_prefix . 'section_bg_image', true );

                $bg_image_properties = getimagesize( $bg_img );

                // couldn't get image with URL, so we need to try with the PATH
                if( !$bg_image_properties ){

                    $uploads_dir_object = wp_upload_dir();

                    $upload_url = $uploads_dir_object['baseurl'];
                    $upload_dir = $uploads_dir_object['basedir'];

                    $bg_img = str_replace( $upload_url, $upload_dir, $bg_img );

                    $bg_image_properties = getimagesize( $bg_img );

                }

                if( $bg_image_properties ) {


                    $bg_img_width = $bg_image_properties['0'];
                    $bg_img_height = $bg_image_properties['1'];

                    if ($bg_img_width && $bg_img_height) {
                        $bg_img_ratio = ($bg_img_height / $bg_img_width);
                        $bg_img_height_vw = ($bg_img_ratio * 100) . 'vw';
                        //            echo 'percentage: ' . $bg_img_ratio . '<br />';
                        //            echo 'height: ' . $bg_img_height_vw . '<br />';


                        $style .= 'min-height:' . $bg_img_height_vw . ';';
                    }
                }

            }


            if ( get_post_meta( $section_id, $meta_box_prefix . 'wsd_slider', true ) ) { // has slides
                $ws_slider_module = true;
                $ws_slider_vars   = get_post_meta( $section_id, $meta_box_prefix . 'wsd_slider', true );
            }

            if ( $section_visibility_temp != null ) {

            //Placed here twice?
            //if(!in_array(1, $temp_array)){
            //  $options_array .= ' hidden-xs ';
            //}
                if ( in_array( 'xs', $section_visibility_temp ) ) {
                    $section_visibility_array .= ' hidden-xs';
                }
                if ( in_array( 'sm', $section_visibility_temp ) ) {
                    $section_visibility_array .= ' hidden-sm';
                }
                if ( in_array( 'md', $section_visibility_temp ) ) {
                    $section_visibility_array .= ' hidden-md';
                }
                if ( in_array( 'lg', $section_visibility_temp ) ) {
                    $section_visibility_array .= ' hidden-lg';
                }
            }


            if ( get_post_meta( $section_id, $meta_box_prefix . 'display_parallax', true ) ) {
                $style               .= 'background-position:fixed;background-attachment:fixed;';
                $chrome_parallax_fix = 'webkit_parallax_fix';
            }


            // @todo - fix these get_post_meta calls later - not sure why changing them breaks things - revisit at another time

            get_post_meta( $section_id, $meta_box_prefix . 'section_outer_width', true ) == 1 ? $outer_container_class = 'container' : '';
//          get_post_meta( $section_id, $meta_box_prefix . 'section_inner_width', true ) == 1 ? $inner_container_class = 'container-fluid' : '';


            if( get_post_meta( $section_id, $meta_box_prefix . 'section_module_html_id', true ) ){
                $section_html_id = get_post_meta( $section_id, $meta_box_prefix . 'section_module_html_id', true );
            }
            if( get_post_meta( $section_id, $meta_box_prefix . 'section_inner_width', true ) ){
                $container_width_value = get_post_meta( $section_id, $meta_box_prefix . 'section_inner_width', true );

                if( '0' == $container_width_value ){
                    $inner_container_class = 'container';
                } elseif( '1' == $container_width_value ){
                    $inner_container_class = 'container-fluid';
                } elseif( '2' == $container_width_value ){
                    $inner_container_class = 'container container-narrow';
                } else {
                    // default
                    $inner_container_class = 'container';
                }
            }


//          $outer_container_class = get_post_meta( $section_id, $meta_box_prefix . 'section_outer_width', true ) == 1 ? 'container' : '';
//          $inner_container_class = get_post_meta( $section_id, $meta_box_prefix . 'section_inner_width', true ) == 1 ? 'container-fluid' : '';


            $outer_container_class = apply_filters( 'ws_section_outer_container_class_filter', $outer_container_class, $section_id );
            $inner_container_class = apply_filters( 'ws_section_inner_container_class_filter', $inner_container_class, $section_id );


            if ( $ws_slider_module ) { //slider and admin
                $num_of_slides = count( $ws_slider_vars );
                $slider_string = '';


                $slider_string .= '
            <div id="carousel" class="carousel slide" data-ride="carousel">
                <ol class="carousel-indicators">';

                $i = 0;
                while ( $i < $num_of_slides ) {
                    if ( $i == 0 ) {
                        $slider_string .= '<li data-target="#carousel" data-slide-to="' . $i . '" class="active"></li>';
                    } else {
                        $slider_string .= '<li data-target="#carousel" data-slide-to="' . $i . '"></li>';
                    }

                    $i ++;
                }

                $slider_string .= '</ol>';

                //<!-- Wrapper for slides -->
                $slider_string .= '<div class="carousel-inner" role="listbox">';

                $slider_init = 0;

                foreach ( $ws_slider_vars as $key=>$ws_slider ) {
                    // $ws_slider['title'] = '';
                    // echo '<pre>' . print_r($ws_slider, true) . '</pre>';

                    if ( $slider_init == 0 ) { //first slide set as active
                        $slider_string .= '<div class="item slide' . ++ $slider_init . ' active">'; //++$slider_init to increment before outputting
                    } else { //others aren't set as active
                        $slider_string .= '<div class="item slide' . $slider_init . '">';
                    }

                    // OLD CODE
                    // $slider_string .= '<img src="' . $ws_slider['image'] . '" alt="' . $ws_slider['alt_tag'] . '" ' . ws_get_image_size($ws_slider['image']) .'>';

                    // NEW CODE - YES, it's crazy, but it works for PHP Strict

                    if ( ws_responsive_images_enabled() ) {

                        if ( isset( $ws_slider['image_id'] ) && $ws_slider['image_id'] ) {

                            $slider_img_id = $ws_slider['image_id'];
                            $thumb_alt     = get_post_meta( $slider_img_id, '_wp_attachment_image_alt', true );

                            $img_other_atts = array( // gets the classname and alt tags
                                'class' => 'gallery-img img-responsive',
                                'title' => get_the_title( $slider_img_id ),
                                'alt'   => $thumb_alt,
                            );


                            $slider_string .= wp_get_attachment_image( $slider_img_id, 'full', '', $img_other_atts );
                        }

                    } else {
                        if( !$key ){
                            $slider_string .= '<div data-src="' . $ws_slider['image'] . '" class="slide-background" style="opacity:0;background-image: url(' . $ws_slider['image'] . ');">';
                        }else{
                            $slider_string .= '<div class="slide-background" style="background-image: url(' . $ws_slider['image'] . ');">';
                        }

//                      $slider_string .= isset( $ws_slider['image'] ) && $ws_slider['image'] ? ' src="' . $ws_slider['image'] . '"' : '';
//                      $slider_string .= isset( $ws_slider['alt_tag'] ) && $ws_slider['alt_tag'] ? ' alt="' . $ws_slider['alt_tag'] . '"' : '';
//                      $slider_string .= isset( $ws_slider['img_title_tag'] ) && $ws_slider['img_title_tag'] ? ' title="' . $ws_slider['img_title_tag'] . '"' : '';
//                      $slider_string .= isset( $ws_slider['image'] ) && $ws_slider['image'] && function_exists( 'ws_get_image_size' ) ? ' ' . ws_get_image_size( $ws_slider['image'] ) . '>' : '';

                    }


                    if ( ( isset( $ws_slider['title'] ) && $ws_slider['title'] ) || ( isset( $ws_slider['description'] ) && $ws_slider['description'] ) ) {
                        $slider_string .= '<div class="carousel-caption">';
                        $slider_string .= isset( $ws_slider['title'] ) ? '<div class="slider-title h3">' . $ws_slider['title'] . '</div>' : '';
                        $slider_string .= isset( $ws_slider['description'] ) ? '<div class="slider-description">' . do_shortcode( $ws_slider['description'] ) . '</div>' : '';
                        $slider_string .= '</div>';
                    }

                    $slider_string .= '</div>';
                    $slider_string .= '</div>';

                    $slider_init ++;

                }


                $slider_string .= '</div>';

                $slider_controls = '
              <a class="left carousel-control" href="#carousel" role="button" data-slide="prev">
                <span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
                <span class="sr-only">Previous</span>
              </a>
              <a class="right carousel-control" href="#carousel" role="button" data-slide="next">
                <span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
                <span class="sr-only">Next</span>
              </a>';


                $slider_string .= apply_filters( 'ws_bootstrap_slider_controls', $slider_controls, $section_id );

                $slider_string .= '</div>';

                $outer_container_classes = get_array_to_classnames(
                    array(
                        'ws-section',
                        'section',
                        'outer-container',
                        $outer_container_class,
                        $section_additional_classnames_array,
                        $chrome_parallax_fix,
                        $section_slug,
                        $section_visibility_array,
                    )
                );

                $inner_container_classes = get_array_to_classnames(
                    array(
                        $inner_container_class,
                        $section_additional_container_classnames_array
                    )
                );

                return '<div class="' . $outer_container_classes . '" style="' . $style . '">
                            <div class="' . $inner_container_classes . '">' . apply_filters( 'ws_section_before_content', '', $section_id ) . $slider_string . apply_filters( 'ws_section_after_content', '', $section_id ) . '</div>' . $edit_section_string . '
                        </div>';

            } else {


                if ( ! $wpautop ) { //if disabled
                    //$content_post = get_post( $section_id );
                    //$content      = $content_post->post_content;
                    //// $content = apply_filters('the_content', $content); // how about no?
                    //$content = str_replace( ']]>', ']]&gt;', $content );

                    $content_post = get_post( $section_id );
                    $content      = $content_post->post_content;
                    remove_filter('the_content','wpautop');
                    $content = apply_filters('the_content', $content); // how about no?
                    $content = str_replace( ']]>', ']]&gt;', $content );


                } else {
                    $content = apply_filters( 'the_content', get_post_field( 'post_content', $section_id ) );
                }



                //MODULE LOADER FUNCTIONALITY


                if( $section_id ) {
                    $ModuleLoader = new ModuleTemplateLoader( $section_id );
                    add_filter( 'scss_input_file_array', array( $ModuleLoader, 'maybe_add_scss_file_to_compiler' ), 1 );

                    if ( $ModuleLoader->is_enabled() && ! $ModuleLoader->uses_default_template( $section_id ) ) {

                        $prefix = $ModuleLoader->get_full_prefix();
                        $section_module_template = $ModuleLoader->get_current_template_name();
                        $module_template_class = 'module-template-' . $ModuleLoader->get_current_template_name();

                        ob_start();

//                      $content = file_get_contents ( get_template_directory() . '/addons/modules/' . $section_module_template . '/template.php' ) ;
//                      echo $ModuleLoader->get_content();
                        include ( get_theme_file_path( '/addons/modules/' . $section_module_template . '/template.php' ) ) ;

                        $content = ob_get_clean();
                        $content = do_shortcode( $content );
//                      $content = do_shortcode( '[ws-auto-p]' . $content . '[/ws-auto-p]');
                    } else {
                        $content = do_shortcode( $content );
                    }

                    ob_start();

                } else {
                    $content = do_shortcode( $content );
                }




                $outer_container_classes = get_array_to_classnames(
                    array(
                        'ws-section',
                        'section',
                        $outer_container_class,
                        $section_additional_classnames_array,
                        $chrome_parallax_fix,
                        $section_slug,
                        $section_visibility_array,
                        $module_template_class
                    )
                );

                $inner_container_classes = get_array_to_classnames(
                    array(
                        $inner_container_class,
                        $section_additional_container_classnames_array
                    )
                );


//              $section_html_id


                if( ws_val( $outer_container_classes ) ){
                    $additional_attributes_array[] = 'class="' . esc_attr__( $outer_container_classes ) . '"';
                }

                if( ws_val( $section_html_id ) ){
                    $additional_attributes_array[] = 'id="' . esc_attr__( $section_html_id ) . '"';
                }


                if( ws_val( $style ) ){
                    $additional_attributes_array[] = 'style="' . esc_attr__( $style ) . '"';
                }



                // convert the array to a string
                $additional_attributes = implode( " ", $additional_attributes_array );





                ?>

                <div <?php echo $additional_attributes; ?>>
                    <?php echo apply_filters( 'ws_section_before_content_before_container', '', $section_id ); ?>
                    <div class="<?php echo $inner_container_classes; ?>">
                        <?php if( ! $section_disable_row_class ) { echo '<div class="row">'; }; ?>
                            <?php do_action( 'ws_section_before_content', $section_id ); ?>
                            <?php echo apply_filters('ws_section_main_content', $content, $section_id ); ?>
                            <?php echo do_action( 'ws_section_after_content', $section_id ); ?>
                        <?php if( ! $section_disable_row_class ) { echo '</div><!-- .row -->'; }; ?>
                    </div>
                    <?php echo apply_filters( 'ws_section_after_content_after_container', '', $section_id ) . $edit_section_string; ?>
                </div>

                <?php

                $to_return = ob_get_clean();

//              if( $section_disable_row_class ) {
//
//                  $to_return = '<div class="' . $outer_container_classes . '" style="' . esc_attr( $style ) . '">
//              ' . apply_filters( 'ws_section_before_content_before_container', '', $section_id ) . '
//            <div class="' . $inner_container_classes . '">
//            ' . apply_filters( 'ws_section_before_content', '', $section_id ) . '
//                ' . do_shortcode( $content ) . '
//                ' . apply_filters( 'ws_section_after_content', '', $section_id ) . '
//            </div>' . apply_filters( 'ws_section_after_content_after_container', '', $section_id ) . $edit_section_string . '</div>';
//              } else {
//                  $to_return = '<div class="' . $outer_container_classes . '" style="' . esc_attr( $style ) . '">
//              ' . apply_filters( 'ws_section_before_content_before_container', '', $section_id ) . '
//            <div class="' . $inner_container_classes . '">
//                <div class="row">
//                ' . apply_filters( 'ws_section_before_content', '', $section_id ) . '
//                ' . do_shortcode( $content ) . '
//                ' . apply_filters( 'ws_section_after_content', '', $section_id ) . '
//                </div>
//            </div>' . apply_filters( 'ws_section_after_content_after_container', '', $section_id ) . $edit_section_string . '</div>';
//                }



                if ( ! $wpautop ) {
                    add_filter( 'the_content', 'wpautop' );
                }
                return $to_return;

            }
        }
*/

function woocommerce_variable_add_to_cart() {
    global $product;
    $out=add_product_summary();

}

function cw_change_product_price_display_old_function( $price ) {
    global $WOOCS;


    //$msrp = get_post_meta(get_the_ID(), 'bold_msrp', true );

    $msrp_price = get_post_meta( get_the_ID(), 'bold_msrp', true );

    //$msrp = wc_price( $WOOCS->woocs_exchange_value( $msrp_price ) );
    $msrp = wc_price(  $msrp_price  );

    if( $msrp_price ){
        return '<p class="price">MSRP (Retail) Price: ' . $msrp . '</p>';
    }else{

        //echo "!".$product->get_price()."!";
        /*
        if($product){
            return wc_price( $product->get_price() );
        }else{
            return $price;
        }
        */
        $user_id = get_current_user_id();

        $wholesale_user = false;

        if( $user_id ){
            $user_meta = get_userdata( $user_id );
            $wholesale_user = in_array( 'wholesale_customer', $user_meta->roles );
        }
        if( $wholesale_user ){
            $_product = wc_get_product( get_the_ID() );
            $prices = [];
            if($_product){
                foreach( $_product->get_children() as $variation_id ){
                    $prices[] = get_post_meta( $variation_id, 'wholesale_customer_wholesale_price', true ) ;
                }

                if($prices){
                    $price = wc_price( min( $prices ) );
                }else{
                    $price = wc_price( get_post_meta( get_the_ID(), 'wholesale_customer_wholesale_price', true ) );
                }
            }
        }
        return $price;
    }

}

/* New function added 22Aug 2023 - Old function above if something break any where */
function cw_change_product_price_display( $price ) {
    global $WOOCS;
    global $wpdb;
    $msrp_price = get_post_meta( get_the_ID(), 'bold_msrp', true );
    //$msrp = wc_price( $WOOCS->woocs_exchange_value( $msrp_price ) );
    $msrp = wc_price(  $msrp_price );
    $user_id = get_current_user_id();
    $_product_ = wc_get_product( get_the_ID() );
    $wholesale_user = false;
    $categories = array();
    $ExistingCat = ['holds', 'macros', 'volumes'];
    $terms = wp_get_post_terms( get_the_ID(), 'product_cat' );
    $sale_discount_item = get_post_meta(get_the_ID(), 'sale_discounted_item', true);
    foreach ( $terms as $term ) {
        $categories[] = $term->slug;
    }
    if (!array_intersect( $ExistingCat, $categories ) ) {
        if( $user_id ){
            $user_meta = get_userdata( $user_id );
            $wholesale_user = in_array( 'wholesale_customer', $user_meta->roles );
        }
        if($msrp_price != ''){
            $discount_title = get_post_meta(get_the_ID(), 'item_discount_title', true);
            $discount_desc = get_post_meta(get_the_ID(), 'item_discount_desc', true);
            if( $wholesale_user ){
                $discount_cost = get_post_meta(get_the_ID(), 'discount_wholesale_cost', true);
                $discount_sub_title = get_post_meta(get_the_ID(), 'wholesale_discount_cost', true);
                if($sale_discount_item == 'Discounted' || $sale_discount_item == 'Sale'){
                    $force_discount = $discount_cost * $msrp_price /100;
                    $discounted_msrp = $msrp_price - $force_discount;
                    //<p class="price">MSRP (Retail) Price:<del style=" margin-right: 4px;" > ' . $msrp . '</del> '.wc_price($discounted_msrp).' </p>
                    $final_respone .= '<p class="price">MSRP (Retail) Price: ' . $msrp . '</p>
                                      <div class="custominfosection">
                                        <div class="first-info"><p class="discounted-title">'.$discount_title.' '.$discount_sub_title.'</p><p>'.$discount_desc.'</p></div>
                                      </div>';
                    return $final_respone;
                }else{

                    return '<p class="price">MSRP (Retail) Price: ' . $msrp . '</p>';
                }
            }
            else{
                $discount_cost = get_post_meta(get_the_ID(), 'discount_retail_cost', true);
                $discount_sub_title = get_post_meta(get_the_ID(), 'retail_discount_cost', true);
                if($sale_discount_item == 'Discounted' || $sale_discount_item == 'Sale'){
                    $force_discount = $discount_cost * $msrp_price /100;
                    $discounted_msrp = $msrp_price - $force_discount;
                    $final_respone = '<p class="price"><del style=" margin-right: 4px;" > ' . $msrp . '</del> '.wc_price($discounted_msrp).' </p>
                                      <div class="custominfosection">
                                        <div class="first-info"><p class="discounted-title">'.$discount_title.' '.$discount_sub_title.'</p><p>'.$discount_desc.'</p></div>
                                      </div>';
                    return $final_respone;
                }else{
                    return '<p class="price">'.$msrp . '</p>';

                }
            }
        }
        /*else{
            if( $wholesale_user ){
                //return '<p class="price">MSRP (Retail) Price: ' . $msrp . '</p>';
            }
            else{
                return '<p class="price">'.$msrp . '</p>';
            }
        }*/
        
    }
    else{
        if( $user_id ){
            $user_meta = get_userdata( $user_id );
            $wholesale_user = in_array( 'wholesale_customer', $user_meta->roles );
        }
        $_product = wc_get_product( get_the_ID() );
        $standardprices = array();
        $dualprice = array();
        $variant_ids = array();
        if($_product){
            if ($_product->is_type('variable')) {
                $variations = $_product->get_children();
                foreach ($variations as $variation_id) {
                    $variant_ids[] = $variation_id;
                    $instock += get_post_meta('bold_product_number_of_sets', true);
                    $variation = wc_get_product($variation_id);
                    if ($variation) {
                        $attributes = $variation->get_attributes();
                        foreach ($attributes as $name => $value) {
                            $term = get_term_by('slug', $value, $name);
                            $term_metaData = get_term_meta($term->term_id,'bold_product_color_dual_texture', true);
                            if($term_metaData == 'Yes'){
                                $regular_price = $variation->get_regular_price();
                                $w_price =  get_post_meta( $variation_id, 'wholesale_customer_wholesale_price', true );
                                $dualprice['rprice'] = $regular_price; 
                                $dualprice['wprice'] = $w_price;

                            }else{
                                $regular_price = $variation->get_regular_price();
                                $w_price = get_post_meta( $variation_id, 'wholesale_customer_wholesale_price', true );
                                $standardprices['rprice'] = $regular_price; 
                                $standardprices['wprice'] = $w_price;
                            }
                        }
                    }
                }
            }
                
        }
        // --- Mtech check variation stock qty
        if($variant_ids){
            $totalstock = 0;
            $variants_str = implode( ",", $variant_ids );
            $sql_inbound = "SELECT wi.product_id, wm.stock_quantity as inbound_stock FROM wp_atum_inventories wi
                                LEFT JOIN wp_atum_inventory_meta wm ON wi.id = wm.inventory_id
                                WHERE wi.product_id IN (" . $variants_str . ") and wi.priority = 1";
    
                $meta_values = $wpdb->get_results(
                    $sql_inbound, ARRAY_A 
                );  
                foreach( $meta_values as $itm ){
                    $totalstock += $itm[ 'inbound_stock' ] * 1;
                }
    
                $meta_values = $wpdb->get_results(
                    "select product_id, stock_quantity from wp_wc_product_meta_lookup where product_id in (" . $variants_str . ")", 
                    ARRAY_A
                );
                foreach( $meta_values as $itm ){
                    $totalstock += $itm[ 'stock_quantity' ] * 1;
                }
            
        }
        //echo $totalstock.' :here';
        // ---Mtech 
        $finalhtmlforprice = '';
        $sale_discount_item = get_post_meta(get_the_ID(), 'sale_discounted_item', true);
        $special_item_text = '';
        $discount = '';
        $discount_cost = '';
        $discount_sub_title = '';
        if($sale_discount_item == 'Discounted' || $sale_discount_item == 'Sale'){
            if($wholesale_user){
                $discount_cost = get_post_meta(get_the_ID(), 'discount_wholesale_cost', true);
                $discount_sub_title = get_post_meta(get_the_ID(), 'wholesale_discount_cost', true);
            }else{
                $discount_cost = get_post_meta(get_the_ID(), 'discount_retail_cost', true);
                $discount_sub_title = get_post_meta(get_the_ID(), 'retail_discount_cost', true);

            }
            $discount_title = get_post_meta(get_the_ID(), 'item_discount_title', true);
            $discount_desc = get_post_meta(get_the_ID(), 'item_discount_desc', true);
           
        }
        // Check stock Sale
        $stock_sale_current = get_post_meta( get_the_ID(), 'stock_sale_current', true ) === 'on';
        $stock_sale_future = get_post_meta( get_the_ID(), 'stock_sale_future', true ) === 'on';
        $stock_sale_mto = get_post_meta( get_the_ID(), 'stock_sale_mto', true ) === 'on';
        if ( $stock_sale_current || $stock_sale_future || $stock_sale_mto ) {

            if($wholesale_user){
                $discount_sub_title = get_post_meta(get_the_ID(), 'wholesale_discount_cost', true);
            }else{
                $discount_sub_title = get_post_meta(get_the_ID(), 'retail_discount_cost', true);

            }
            $discount_title = get_post_meta(get_the_ID(), 'item_discount_title', true);
            $discount_desc = get_post_meta(get_the_ID(), 'item_discount_desc', true);
        }
        if($wholesale_user){
            $Get_ProductMetaText = get_post_meta(get_the_ID(), 'bold_product_texture', true);
            if($totalstock > 0){
                $special_item_text = '<div class="custominfosection">
                                        <div class="first-info"><p class="discounted-title">'.$discount_title.' '.$discount_sub_title.'</p><p>'.$discount_desc.'</p></div>
                                      </div>';
            }
            if($Get_ProductMetaText == "Standard & Dual Tex"){
                if($standardprices){
                    $rprice = $standardprices['rprice'];
                    $wprice = $standardprices['wprice'];
                    $force_discount_html = '';
                    if($discount_cost != ''){
                        $force_discount = $discount_cost * $wprice /100;
                        $discounted_wprice = $wprice - $force_discount;
                        $force_discount_html = '<del style=" margin-right: 4px;" >'.wc_price($wprice).'</del>'.wc_price($discounted_wprice);
                        $finalhtmlforprice .='<div class="custompricesection"><div class="custom_price_section" style="width: 13%;float: left;">Standard tex</div>
                                                <div class="pricearea">
                                                '.$force_discount_html .'
                                               </div>
                                            </div>';
                    }else{
                        $finalhtmlforprice .='<div class="custompricesection"><div class="custom_price_section" style="width: 13%;float: left;">Standard tex</div><div class="pricearea"><del style=" margin-right: 4px; ">'.wc_price($rprice).'</del>'.wc_price($wprice).'</div></div>';
                    }
                }
                if($dualprice){
                    $rprice = $dualprice['rprice'];
                    $wprice = $dualprice['wprice'];
                    $force_discount_html = '';
                    if($discount_cost != ''){
                        $force_discount = $discount_cost * $wprice /100;
                        $discounted_wprice = $wprice - $force_discount;
                        $force_discount_html = '<del style=" margin-right: 4px;" >'.wc_price($wprice).'</del>'.wc_price($discounted_wprice);
                        $finalhtmlforprice .='<div class="custompricesection">
                                                <div class="custom_price_section" style="width: 13%;float: left;">Dual tex</div>
                                                <div class="pricearea">
                                                    '.$force_discount_html.'
                                                </div>
                                            </div>';
                    }else{
                        $finalhtmlforprice .='<div class="custompricesection"><div class="custom_price_section" style="width: 13%;float: left;">Dual tex</div><div class="pricearea"><del style=" margin-right: 4px; ">'.wc_price($rprice).'</del>'.wc_price($wprice).'</div></div>';
                    }
                }
                $finalhtmlforprice .= $special_item_text;
                return $finalhtmlforprice;
                
            }else{
                if($standardprices){
                    $rprice = $standardprices['rprice'];
                    $wprice = $standardprices['wprice'];
                    if($discount_cost != ''){
                        $force_discount = $discount_cost * $wprice /100;
                        $discounted_wprice = $wprice - $force_discount;

                        $finalhtmlforprice .='<div class="custompricesection" style=" font-size: 1.25em; ">
											         <div class="custom_price_section" style="width: 13%;float: left;"></div>
                                                    <span style="display: block;clear: both;" class="wholesale_price_container">
                                                        <span class="wholesale_price_title" >Wholesale :</span>
                                                        <del style=" margin-right: 4px; ">'.wc_price($wprice).'</del>'.wc_price($discounted_wprice).'
                                                    </span>
											
										    </div>';
                    }else{
                        $finalhtmlforprice .='<div class="custompricesection" style=" font-size: 1.25em; ">
                                                <div class="custom_price_section" style="width: 13%;float: left;">
                                                   <del style=" margin-right: 4px; ">'.wc_price($rprice).'</del></div>
                                                   <span style="display: block;clear: both;" class="wholesale_price_container">
                                                <span class="wholesale_price_title" >Wholesale :</span>
                                                <ins>'.wc_price($wprice).'</ins>
                                                </span>
                                                
                                              </div>';

                    }
                }
                $finalhtmlforprice .= $special_item_text;
                return $finalhtmlforprice;
                
            }
            
        }
        else{
            $Get_ProductMetaText = get_post_meta(get_the_ID(), 'bold_product_texture', true);
            if($totalstock > 0){
                $special_item_text = '<div class="custominfosection">
                                          <div class="first-info"><p class="discounted-title">'.$discount_title.' '.$discount_sub_title.'</p><p>'.$discount_desc.'</p></div>
                                      </div>';
            }
            if($Get_ProductMetaText == "Standard & Dual Tex"){
                if($standardprices){
                    $rprice = $standardprices['rprice'];
                    $wprice = $standardprices['wprice'];
                    $force_discount_html = '';
                    if($discount_cost != ''){
                        $force_discount = $discount_cost * $rprice /100;
                        $discounted_wprice = $rprice - $force_discount;
                        //echo $rprice.'Here';
                        $force_discount_html = '<del style=" margin-right: 4px;" >'.wc_price( $rprice).'</del>'.wc_price($discounted_wprice);
                        $finalhtmlforprice .='<div class="custompricesection">
                                                 <div class="custom_price_section" style="width: 13%;float: left;">Standard tex</div>
                                                 <div class="pricearea">'.$force_discount_html.'</div>
                                            </div>';
                    }else{
                        $finalhtmlforprice .='<div class="custompricesection"><div class="custom_price_section" style="width: 13%;float: left;">Standard tex</div><div class="pricearea">'.wc_price($rprice).'</div></div>';
                    }
                }
                if($dualprice){
                    $rprice = $dualprice['rprice'];
                    $wprice = $dualprice['wprice'];
                    if($discount_cost != ''){
                        $discount_cost = (float)$discount_cost;
                        $rprice = (float)$rprice;
                        $force_discount = $discount_cost * $rprice /100;
                        $discounted_wprice = $rprice - $force_discount;
                        $force_discount_html = '<del style=" margin-right: 4px;" >'.wc_price( $rprice).'</del>'.wc_price($discounted_wprice);
                        $finalhtmlforprice .='<div class="custompricesection">
                                            <div class="custom_price_section" style="width: 13%;float: left;">Dual tex</div>
                                            <div class="pricearea">'.$force_discount_html.'</div></div>';
                    }else{
                        $finalhtmlforprice .='<div class="custompricesection"><div class="custom_price_section" style="width: 13%;float: left;">Dual tex</div><div class="pricearea">'.wc_price($rprice).'</div></div>';
                    }
                }
                
            }
            else{
                $rprice = $standardprices['rprice'];
                $wprice = $standardprices['wprice'];
                if($discount_cost != ''){
                    $force_discount = $discount_cost * $rprice /100;
                    $discounted_wprice = $rprice - $force_discount;
                    $force_discount_html = '<del style=" margin-right: 4px;" >'.wc_price( $rprice).'</del>'.wc_price($discounted_wprice);
                    $finalhtmlforprice .='<div class="custompricesection">
                                            <div class="pricearea">'.$force_discount_html.'</div>
                                          </div>';
                }else{
                    $finalhtmlforprice .='<div class="custompricesection"><div class="pricearea">'.wc_price($rprice).'</div></div>';
                }
            }
            $finalhtmlforprice .= $special_item_text;
            return $finalhtmlforprice;
        }
        
    }
    return  $price ;
}
if(!is_admin()) {
    add_filter( 'woocommerce_get_price_html', 'cw_change_product_price_display',100);
}

function add_shipping_banner(){
    $shuttle_data = get_option( 'shuttle' );
    $banner_shipping_text = $shuttle_data[ 'opt-textarea-header-custom-area-2' ];

    $user_id = get_current_user_id();
    $isWholesaleCustomer = false;
    if( $user_id ){
        $user_meta = get_userdata( $user_id );
        $isWholesaleCustomer = in_array( 'wholesale_customer', $user_meta->roles );
    }
    $cookie_banner = isset( $_COOKIE['bld_banner_shipping_hide'] ) ? $_COOKIE['bld_banner_shipping_hide'] : 0;
    if( !$isWholesaleCustomer and !$cookie_banner ){

        ?>
        <div class="banner_shipping">
            <div class="banner_shipping_close">
                <div class="banner_shipping_closeline banner_shipping_closeline1"></div>
                <div class="banner_shipping_closeline banner_shipping_closeline2"></div>
            </div>
            <div class="banner_shipping_text">
                <?php echo $banner_shipping_text ?>
            </div>
        </div>
        <?php
    }
}
add_action( 'ws_inside_header_end', 'add_shipping_banner', 12 );

function my_body_classes( $classes ) {
    $user_id = get_current_user_id();
    $isWholesaleCustomer = false;
    if( $user_id ){
        $user_meta = get_userdata( $user_id );
        $isWholesaleCustomer = in_array( 'wholesale_customer', $user_meta->roles );
    }
    $cookie_banner = isset( $_COOKIE['bld_banner_shipping_hide'] ) ? $_COOKIE['bld_banner_shipping_hide'] : 0;
    if( !$isWholesaleCustomer and !$cookie_banner ){
        $classes[] = 'with_ship_banner';
    }
    return $classes;
}
add_filter( 'body_class', 'my_body_classes' );


function add_shipping_hint(){
    $shipping_postcode = WC()->customer->get_shipping_postcode();
    if( !$shipping_postcode ){
        ?>
        <p class="shipping_zip_hint">Enter your ZIP code to see shipping options</p>
        <?php
    }
}
add_action( 'woocommerce_after_shipping_calculator', 'add_shipping_hint', 12 );

// save field values
function order_custom_field_save( $order_id ){
    if( ! empty( $_POST[ 'company_po' ] ) ) {
        update_post_meta( $order_id, 'company_po', wc_clean( $_POST[ 'company_po' ] ) );
    }
    //Tech 30-Sep-23    
    if( ! empty( $_POST[ 'bold_customers_outside' ] ) ) {
        $isvalue =  $_POST[ 'bold_customers_outside'];
        if($isvalue == 'own'){
            if(! empty( $_POST[ 'bold_custom_broker' ] ) ){
                update_post_meta( $order_id, 'bold_custom_broker', wc_clean( $_POST[ 'bold_custom_broker' ] ) );
            }
            if(! empty( $_POST[ 'bold_custom_broker_number' ] )){
                update_post_meta( $order_id, 'bold_custom_broker_number', wc_clean( $_POST[ 'bold_custom_broker_number' ] ) );
            }
        }else{
            
        }
        
    }
}
add_action( 'woocommerce_checkout_update_order_meta', 'order_custom_field_save' );
/* Custom Broker*/

add_action( 'woocommerce_admin_order_data_after_billing_address', 'wp_kama_woocommerce_admin_order_data_after_billing_address_action' );

function wp_kama_woocommerce_admin_order_data_after_billing_address_action( $order ){
    
    $order = wc_get_order($order->get_id());
    $user_id = $order->get_user_id();
    if( $user_id ){
        $user_meta = get_userdata( $user_id );
        $isWholesaleCustomer = in_array( 'wholesale_customer', $user_meta->roles );
    }
    
    echo '<p><strong>' . __( 'Custom Broker' ) . ': </strong>' . get_post_meta( $order->get_id(), 'bold_custom_broker', true ) . '</p>';
    echo '<p><strong>' . __( 'Custom Broker Number' ) . ': </strong>' . get_post_meta( $order->get_id(), 'bold_custom_broker_number', true ) . '</p>';
 //   echo '<p><strong>' . __( 'Custom Broker' ) . ':</strong>' . get_meta( '_bold_custom_broker') . '</p>';
//  echo '<p><strong>' . __( 'Custom Broker Number' ) . ':</strong>' . get_meta( '_bold_custom_broker_number') . '</p>';

}



/*End */
add_action( 'woocommerce_admin_order_data_after_order_details', 'custom_woocommerce_admin_order_data_after_order_details' );
function custom_woocommerce_admin_order_data_after_order_details( $order ){
    $order = wc_get_order($order->get_id());
    $user_id = $order->get_user_id();
    $isWholesaleCustomer = false;
    if( $user_id ){
        $user_meta = get_userdata( $user_id );
        $isWholesaleCustomer = in_array( 'wholesale_customer', $user_meta->roles );
    }
    ?>
    <br class="clear" />


    <div class="edit_custom_field"> <!-- use same css class in h4 tag -->
        <?php
        woocommerce_wp_textarea_input( array(
            'id' => 'company_po',
            'label' => 'Company PO#:',
            'value' => $order->get_meta( 'company_po' ),
            'wrapper_class' => 'form-field-wide'
        ) );
        ?>
    </div>
    <div class="edit_custom_field_transaction">
        <a href="#" class="dl_transaction" field_data="<?php echo $order->get_id(); ?>">Delete Transaction ID#</a>
        <span class="readmessage"></span>
    </div>
    <div class="custom_shipping">
        <a href="#" class="add_shipping" field_data="<?php echo $order->get_id(); ?>">Add Shipping</a>
        <div class="shipping_custom_fields" style="display:none">
            <div class="shippinglable_section">
                <label>Shipping Lable#:</label>
                <input type="text" class="shippinglable" />
            </div>
            <div class="shippingcost_section">
                <label>Shipping Cost#:</label>
                <input type="text" class="shippingcost" />
            </div>
            <div class="btn">
                <input type="button" class="addshipping" id_data="<?php echo $order->get_id(); ?>" value="Add"/>
            </div>
            
            <span class="read_message"></span>
        </div>
    </div>
    <?php
    if($isWholesaleCustomer){
        ?>
        <div class="recal_bulksubtotal">
            <a href="#" class="bulk_subtotal" id_data="<?php echo $order->get_id(); ?>">Bulk Discount Subtotal</a>
            <span class="response_message_subtotal"></span>
        </div>
        <div class="bulk_discount">
            <a href="#" class="recal_bulkdiscount">Add Bulk Discount</a>
            <div class="custom_bulk_discount" style="display:none">
                <div class="custom_bulkcost_section">
                    <label>Custom Bulk Discount - %</label>
                    <input type="text" class="custom_cost" />
                </div>
                
                <div class="btn">
                    <input type="button" class="addbulkdiscount" id_data="<?php echo $order->get_id(); ?>" value="Add"/>
                </div>
                <span class="response_message"></span>
            </div>
        </div>
        <?php
    }
    ?>
    <?php
}
/*
*/
add_action( 'woocommerce_process_shop_order_meta', 'custom_woocommerce_process_shop_order_meta' );
function custom_woocommerce_process_shop_order_meta( $order_id ){
    update_post_meta( $order_id, 'company_po', wc_sanitize_textarea( $_POST[ 'company_po' ] ) );
}

//add_filter( 'woocommerce_shipping_calculator_enable_country', '__return_false' );
add_filter( 'woocommerce_shipping_calculator_enable_city', '__return_false' );
//add_filter( 'woocommerce_shipping_calculator_enable_state', '__return_false' );

/*
function wpse_setup_theme() {
    add_theme_support( 'post-thumbnails' );
    add_image_size( 'product-thumb', 480, 480, false );
}
add_action( 'after_setup_theme', 'wpse_setup_theme' );
*/


/*
function plugin_republic_add_cart_item_data( $cart_item_data, $product_id, $variation_id ) {
    //print_r($cart_item_data);
    //$cart_item_data['pr_field'] = sanitize_text_field( $_POST['pr-field'] );
    return $cart_item_data;
}
add_filter( 'woocommerce_add_cart_item_data', 'plugin_republic_add_cart_item_data', 10, 3 );
*/
/*
add_action( 'woocommerce_before_calculate_totals', 'add_custom_price',1 );
function add_custom_price( $cart_object ) {
    $custom_price = 1; // This will be your custome price
    foreach ( $cart_object->cart_contents as $key => $value ) {
        //$value['data']->price = $custom_price;
        // for WooCommerce version 3+ use:
        $value['data']->set_price($custom_price);
    }
}
*/
//update_cart_item_data
/*
function update_cart_item($cart_item){
    $price = 100;

    $product = $cart_item['data'];
    if ( ! $product instanceof WC_Product ) {
        return $cart_item;
    }
    $product_id = $product->get_id();
    $parent_id  = $product->get_parent_id();
    $parent_id  = $parent_id ? $parent_id : $product_id;

    //$deposit_value = apply_filters( 'yith_wcdp_deposit_value', YITH_WCDP_Deposits::get_deposit( $product_id, false, $product->get_price() ), $parent_id, $product_id, $cart_item );

    $deposit_value = $price / 2;
    $deposit_balance = $price;// - $deposit_value;

    $product->set_price( $deposit_value );
    $product->update_meta_data( 'yith_wcdp_deposit', true );

    $cart_item['deposit_value']   = $deposit_value;
    //$cart_item['deposit_balance'] = $deposit_balance;

    //print_r($deposit_value);

    return $cart_item;
}
add_filter( 'woocommerce_add_cart_item', 'update_cart_item', 31, 1 );
*/

//add_filter( 'woocommerce_add_cart_item', 'update_cart_item', 31, 1 );
/*
function getPrice( $product_id ){

    $user_id = get_current_user_id();

    $wholesale_user = false;

    if( $user_id ){
        $user_meta = get_userdata( $user_id );
        $wholesale_user = in_array( 'wholesale_customer', $user_meta->roles );
    }

    if( $wholesale_user){
        $price_str = wc_price( get_post_meta( $product_id, 'wholesale_customer_wholesale_price', true ) );
    }else{
        $product = wc_get_product( $product_id );
        $price_str = wc_price( $product->get_price() );
    }
    $price_str = html_entity_decode( strip_tags( $price_str ) );
    $price = preg_replace('/[^0-9.,]/', '', $price_str );
    return $price;
}

function update_cart_item_data( $cart_item_data, $product_id, $variation_id ){
    //print_r($variation_id );
    if( $variation_id ){
        $product_id = $variation_id;
    }

    $price = getPrice( $product_id );
    $boldDepositType = get_user_meta( get_current_user_id(), 'bold_deposit_type', true );

    switch ($boldDepositType){
        case 'deposit1':
            $deposit_balance = round( $price / 2, 2 );
            $deposit_value = $price - $deposit_balance;

            $cart_item_data['deposit']         = true;
            $cart_item_data['deposit_type']    = 'rate';
            $cart_item_data['deposit_amount']  = 0;
            $cart_item_data['deposit_rate']    = 50;
            $cart_item_data['deposit_value']   = $deposit_value;
            $cart_item_data['deposit_balance'] = $deposit_balance;
        break;

        case 'deposit2':
            $deposit_value = 0;
            $deposit_balance = $price;

            $cart_item_data['deposit']         = true;
            $cart_item_data['deposit_type']    = 'rate';
            $cart_item_data['deposit_amount']  = 0;
            $cart_item_data['deposit_rate']    = 100;
            $cart_item_data['deposit_value']   = $deposit_value;
            $cart_item_data['deposit_balance'] = $deposit_balance;
        break;

        default:
            $cart_item_data = array(
                'deposit' => 0
            );
        break;
    }

    return $cart_item_data;
}

add_filter( 'woocommerce_add_cart_item_data', 'update_cart_item_data', 10, 3 );

function update_cart_item( $cart_item ){
    $product = $cart_item['data'];
    $product_id = $product->get_id();
    $price = getPrice( $product_id );
    $product->set_price( $price );
    return $cart_item;
}

add_filter( 'woocommerce_add_cart_item', 'update_cart_item', 31, 1 );
function subtract_balance_shipping_costs( $cart ){


    $cart_hash          = WC()->cart->get_cart_hash();
    $shipping_hash      = md5( wp_json_encode( WC()->session->get( 'chosen_shipping_methods' ) ) );
    $totals_hash        = md5( $cart_hash . $shipping_hash );

    $grand_totals = WC()->session->get( 'yith_wcdp_grand_totals_' . $totals_hash );



    $boldDepositType = get_user_meta( get_current_user_id(), 'bold_deposit_type', true );
    if( $boldDepositType == 'deposit1' ){

        $balance_shipping = WC()->shipping()->calculate_shipping( $cart->get_shipping_packages() );
        $total_to_subtract = 0;
        $tax_to_subtract = 0;

        foreach ( $balance_shipping as $key => $package ) {
            $chosen_method = wc_get_chosen_shipping_method_for_package( $key, $package );
            if ( empty( $chosen_method ) ) {
                continue;
            }
            $method = $package['rates'][ $chosen_method ];
            $total_to_subtract += $method->get_cost();
            $tax_to_subtract   += array_sum( $method->get_taxes() );
        }
        $shipping_cost = $total_to_subtract + $tax_to_subtract;
        $shipping_half= $shipping_cost / 2;
        $totals = $cart->get_totals();
        $new_total = $totals['subtotal'] + $shipping_half;
        $cart->set_total($new_total);

    }
    if( $boldDepositType == 'deposit2' ) {
        $cart->set_total(0);
    }
}
add_action( 'woocommerce_after_calculate_totals', 'subtract_balance_shipping_costs' , 9, 1 );
*/

function add_term_notes(){
    $user_id = get_current_user_id();
    $isWholesaleUser = false;
    if($user_id){
        $user_meta = get_userdata( $user_id );
        $isWholesaleUser = in_array( 'wholesale_customer', $user_meta->roles );
    }
    if( $isWholesaleUser ){
        echo '<tr><td colspan="2" style="font-weight: 400;">' . get_option( 'dkabz_checkout_terms_note' ) .'</td></tr>';
    }
}
add_action( 'woocommerce_review_order_after_order_total', 'add_term_notes' );

function delete_items_in_cart() {
    if(isset($_POST['remove_cart_item'])) {
        foreach($_POST['remove_cart_item'] as $cart_item_key) {
            WC()->cart->remove_cart_item($cart_item_key);
        }
    }
}
add_action( 'woocommerce_before_calculate_totals', 'delete_items_in_cart' );

/* Gaurav Code - Add Custom line before order total as Shipping Note */
add_action( 'woocommerce_cart_totals_before_order_total', 'wp_kama_woocommerce_cart_totals_after_shipping_action' );
add_action( 'woocommerce_review_order_before_order_total', 'wp_kama_woocommerce_cart_totals_after_shipping_action' );
function wp_kama_woocommerce_cart_totals_after_shipping_action(){
    echo '<tr><td colspan="2" style="font-weight: 400;">We reserve the right to ship with a different carrier.</td></tr>';
}

/* The End */

/* Wholesale Order From Backend Gaurav*/
add_action('woocommerce_new_order_item', 'modify_item_price_on_order_item_add', 1, 3);
function modify_item_price_on_order_item_add($item_id, $item, $order_id) {
    if ( !is_admin() )
        return;

    $itemid = $item_id;
    $type = $item->get_type();
    //echo $type; die(); //coupon
    if($type == 'line_item'){
        $product_id = $item->get_product_id();
        $product = wc_get_product( $product_id );
        if ($product->is_type('variable')) {
            $isItemid = $item->get_variation_id();
        }else{
            $isItemid = $product_id;
        }
        $order = wc_get_order($order_id);
        if(current_user_can('manage_options')){
            if($isItemid){
                $customer_id = $order->get_user_id(); 
                if($customer_id){
                    if (in_array('wholesale_customer', get_userdata($customer_id)->roles)) {
                        $custom_sale_price = get_post_meta($isItemid, 'wholesale_customer_wholesale_price', true);  
                        if($custom_sale_price != ''){
                            $itemTotal = $item->get_quantity();
                            $item->set_subtotal($custom_sale_price);
                            $item->set_total($custom_sale_price * $itemTotal);
                            $item->save();

                        }else{

                        }

                    }else{

                    }

                }
            }

        }
    }
    
    
}
/* The End */
/* -------Add custom position column in product table----------*/
add_filter( 'manage_product_posts_columns', 'set_custom_edit_product_columns' );
 function set_custom_edit_product_columns($columns) {
  
    $columns['position'] = __( 'Position Variations', 'your_text_domain' );
    return $columns;
}
add_filter('manage_edit-product_columns', 'add_custom_product_column');
function add_custom_product_column($columns) {
    $new_columns = array();
    foreach ($columns as $key => $value) {
        $new_columns[$key] = $value;
        if ($key == 'name') { 
            $new_columns['discounted-item'] = __('Discounted', 'your-text-domain');
        }
    }
    return $new_columns;
}


add_filter('manage_edit-product_sortable_columns', 'sortable_custom_product_column');
function sortable_custom_product_column($columns) {
    $columns['discounted-item'] = 'Discounted';
    return $columns;
}

add_action( 'manage_product_posts_custom_column' , 'custom_column', 10, 2 );
function custom_column( $column, $post_id ) {
    switch ( $column ) {
        case 'position' :
            $itemMeta = get_post_meta($post_id, 'position', true);
            if ( is_string( $itemMeta ) )
                echo $itemMeta;
            else
               echo '';
        break;

        case 'discounted-item' :
            $item_meta = get_post_meta($post_id, 'sale_discounted_item', true);
            if($item_meta == 'Discounted'){
                echo 'Discounted';
            }else if($item_meta == 'Sale'){
                echo 'Sale';
            }else{
                echo '<small>-</small>';
            }


    }
}
add_action('admin_head', 'wp_tech_custom_css');
function wp_tech_custom_css() {
    ?>
  <style>
      th#position {
          width: 10% !important;
      }
       input#dl_transaction {
        width: unset !important;
    }
     .show_if_simple label {
        display: inline-block !important;
        margin-right: 6px;
        font-weight: 600;
    }
  </style>
<?php
}
add_action('wp_head', function(){
    ?>
    <!-- 
    <div id="loader-container" class="loader-container">
        <div class="spinner customloader" id="spinner">
        <div class="lds-spinner">
                <div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div>
            </div>
            <div class="loading-percentage" id="loadingPercentage"></div>
        </div>
    </div>
     -->
    <script> 
    <!-- Google tag (gtag.js) -->
    gtag('event', 'manual_event_PURCHASE', { 
         //<event_parameters>
    }); 
    </script>

    <style>
        .mobilecontent {
             display: none;
        }
        .shipping-options .customcontent{ width: 126px; word-wrap: break-word; white-space: normal;}
        .bottom-image {transition: visibility 0s,opacity 0s linear !important;}
        #calc_shipping_country_field {display: block!important;}

        .search-results .products .price{display:none!important;}
        /* .products a.product_type_variable{display:none!important} */
        /* Search result */
        .search-results ul.products{ display: flex; flex-wrap: wrap;}
        .search-results ul.products li.product{ width: 20%; }
        .search-results ul.products li.product a img{ margin-bottom: 0px;}
        .search-results ul.products li.product h2.woocommerce-loop-product__title{ font-size: 22px; line-height: 24px; color: #000; margin: 0px; padding: 0px;}
        .search-results ul.products .price-wrapper.catproduct{ gap: 5px; display: flex; align-items: center; font-size: 14px; color: #000;}
        .search-results ul.products .price-wrapper.catproduct .product-brand{gap: 5px; display: flex; align-items: center;}
        .search-results ul.products li.product a.button.add_to_cart_button{ border: 1px solid #000 !important; text-align: center; text-transform: uppercase; padding: 7px 15px; background-color: #fff !important; color: #000 !important; font-size: 0px !important; line-height: inherit; font-weight: 400 !important; border-radius: 0px !important; text-transform: uppercase; display: inline-block; vertical-align: top; margin: 15px 0px 15px !important; line-height: 14px;}
        .search-results ul.products li.product a.button.add_to_cart_button::before { content: "Quick view"; font-size: 10px;}
        .search-results ul.products li.product a.button.product_type_variable{ border: 1px solid #000 !important; text-align: center; text-transform: uppercase; padding: 7px 15px; background-color: #fff !important; color: #000 !important; font-size: 0px !important; line-height: inherit; font-weight: 400 !important; border-radius: 0px !important; text-transform: uppercase; display: inline-block; vertical-align: top; margin: 15px 0px 15px !important; }
        .search-results ul.products li.product a.button.product_type_variable::before { content: "Quick view"; font-size: 10px; line-height: 14px;}


        .search-results ul.products li.no-margin{ display: none !important;}
        .search-results ul.products li.visible-md-block{ display: none !important;}
        .search-results ul.products li.visible-xs-block{ display: none !important;}
        @media(min-width:0px) and (max-width:575px){
            .search-results ul.products li.product{ width: 50%; text-align: center;}
            .search-results ul.products .price-wrapper.catproduct{ justify-content: center; text-align: center; font-size: 13px;}
            .search-results ul.products li.product h2.woocommerce-loop-product__title{ font-size: 18px; line-height: 22px;}    
        }
        @media(min-width:576px) and (max-width:767px){
            .search-results ul.products li.product{ width: 50%; text-align: center;}
            .search-results ul.products .price-wrapper.catproduct{ justify-content: center; text-align: center;}
            .search-results ul.products li.product h2.woocommerce-loop-product__title{ font-size: 18px; line-height: 22px;}
        }
        @media(min-width:768px) and (max-width:991px){
            .search-results ul.products li.product{ width: 50%; text-align: center;}
            .search-results ul.products .price-wrapper.catproduct{ justify-content: center; text-align: center;}
        }
        .custom_price_section{ width: 13% !important;}
        .shop_table .custompricesection{ display: flex;}
        .shop_table .custom_price_section{ width: 90px !important; margin-right: 10px;}
        .shop_table .custompricesection span.woocommerce-Price-amount.amount bdi{ font-size: 14px !important;}
        /* End */
        
        
        @media screen and (max-width: 600px) {
            .mobilecontent {
                clear: both;
                display: block;
            }
            .desktooltip{
                display: none;
            }
            .mobilecontent .customcontent{
                font-size: 8px;
            }
            .signup-popup .popup-close-btn{
                   right: 30px;
                   font-size: 30px;
            }
        }
    </style>
    <?php
});
/* Sort products in product table by “position” data column */
add_filter( 'parse_query', 'fb_custom_post_sort' );
function fb_custom_post_sort($query) {

    if ( ! is_admin() )
        return $query;

    global $current_screen;
    if ( isset( $current_screen ) && 'product' === $current_screen->post_type ) {
        $query->query_vars['orderby']  = 'meta_value_num';
        $query->query_vars['meta_key'] = 'position';
        $query->query_vars['order']    = 'ASC';
    }
}

/*  Sort products in cart by “position” data column */
function cart_new_cart_updated() {
    $products_in_cart = array();
    foreach ( WC()->cart->cart_contents as $key => $item ) {
        $iscart = $item['product_id'];
        $isposition = $iscart ? get_post_meta($iscart, 'position', true) : '';
        $products_in_cart[ $key ] = $isposition ;
    
    }
    asort( $products_in_cart );
    $cart_contents = array();
    foreach ( $products_in_cart as $cart_key => $price ) {
       $cart_contents[ $cart_key ] = WC()->cart->cart_contents[ $cart_key ];
    }

    WC()->cart->cart_contents = $cart_contents;

}
add_action( 'woocommerce_cart_loaded_from_session', 'cart_new_cart_updated' );

/*  --End--   */

/* -----Strip 21-Oct-23---*/
add_filter('wc_stripe_force_save_payment_method', function($bool, $order, $payment_method){
    if(is_checkout()){
        $bool = true;
    }
return $bool;
}, 10, 3);

add_action('admin_footer', function(){
    ?>
    
    <script>
    
    
    jQuery(document).ready(function(){
        jQuery(document).on('click', '.dl_transaction', function(){
            let myThis = jQuery(this);
            if (confirm("Do you want to delete tansaction ID#")){
               let OrderID = myThis.attr('field_data');
                let ajax_url = "<?php echo admin_url('admin-ajax.php'); ?>";
                jQuery.ajax({
                    type : "post",
                    url : ajax_url,
                    data : {action: "wp_order_meta_function" ,
                        OrderID:OrderID
                    },
                    success: function(data){
                        if(data){
                            jQuery('span.readmessage').html('<p>Transaction ID deleted Sucessfully.</p>');
                            jQuery('span.readmessage').focus();
                        }
                             
                    }
               });
            }
            return false;
        });

        jQuery(document).on('click', '.add_shipping', function(){
            let myThis = jQuery(this);
            let shippingCustomFields = jQuery('.shipping_custom_fields');
            if (shippingCustomFields.css('display') === 'block') {
                shippingCustomFields.css('display', 'none');
            } else {
                shippingCustomFields.css('display', 'block');
                jQuery(".shippinglable").focus();
            }
            return false;
        });

        jQuery(document).on('click', '.addshipping', function(){
            let OrderID = jQuery(this).attr('id_data');
            let shipping_label = jQuery('.shippinglable').val();
            let shipping_cost = jQuery('.shippingcost').val();
            let addButton = jQuery(this);
            if(shipping_label == ''){
                jQuery('span.read_message').text('Please enter shipping label.');
                return false;
            }
            if(shipping_cost == '') {
                jQuery('span.read_message').text('Please enter shipping cost.');
                return false;
            } else {
                let parsedShippingCost = parseInt(shipping_cost, 10);
                if (Number.isInteger(parsedShippingCost)) {
                    
                } else {
                    jQuery('span.read_message').text('Shipping cost must be an integer.');
                    return false;
                }
            }
            addButton.val('Adding....')
            let ajax_url = "<?php echo admin_url('admin-ajax.php'); ?>";
            jQuery.ajax({
                type : "post",
                url : ajax_url,
                data : {action: "wp_order_meta_shipping_function" ,
                    OrderID:OrderID,
                    shipping_cost:shipping_cost,
                    shipping_label:shipping_label
                },
                success: function(data){
                    let response = JSON.parse(data);
                    if(response.status === 'success'){
                        jQuery('span.read_message').html('<p>Shipping Added Sucessfully.</p>');
                        jQuery('span.read_message').focus();
                        addButton.val('Add');
                        jQuery('input.addshipping').val('Add');
                        setTimeout(function(){
                            location.reload();
                        }, 3000);
                    }else{
                        jQuery('span.read_message').html('<p>Shipping Not Added For some reason! Please try again.</p>');
                        jQuery('span.read_message').focus();
                    }
                            
                },
               
            });
            return fasle;
        });

        // --------Bulk Discount Button----------
        jQuery(document).on('click', '.recal_bulkdiscount', function(){
            let myThis = jQuery(this);
            let shippingCustomFields = jQuery('.custom_bulk_discount');
            if (shippingCustomFields.css('display') === 'block') {
                shippingCustomFields.css('display', 'none');
            } else {
                shippingCustomFields.css('display', 'block');
                jQuery(".custom_cost").focus();
            }
            return false;
        });

        // ----------Bulk Discount Calculate------------
        jQuery(document).on('click', '.addbulkdiscount', function(){
            let OrderID = jQuery(this).attr('id_data');
            let bulkdiscount = jQuery('.custom_cost').val();
            let mybutton = jQuery(this);
            if(bulkdiscount == '') {
                bulkdiscount = 'Empty';
            } else {
                let parsedShippingCost = parseInt(bulkdiscount, 10);
                if (Number.isInteger(parsedShippingCost)) {
                    
                } else {
                    jQuery('span.response_message').text('Bulk discount must be an integer.');
                    return false;
                }
            }

            mybutton.val('Adding....')
            if (confirm("Do you want to recalculate bulk Discount!. Make sure before update the order.")) {
                let ajax_url = "<?php echo admin_url('admin-ajax.php'); ?>";
                jQuery.ajax({
                    type : "post",
                    url : ajax_url,
                    data : {action: "wp_order_meta_bulkdiscount_function" ,
                        OrderID:OrderID,
                        bulkdiscount:bulkdiscount
                    },
                    success: function(data){
                        let response = JSON.parse(data);
                        if(response.status === 'success'){
                            mybutton.val('Add');
                            jQuery('span.response_message').html('<p>Bulk Discount Recalculated And Added Sucessfully.</p>');
                            jQuery('span.response_message').focus();
                            setTimeout(function(){
                                location.reload();
                            }, 3000);
                        }else{
                            mybutton.val('Add');
                            jQuery('span.response_message').html('<p>Bulk Discount not eligible for this order.</p>');
                            jQuery('span.response_message').focus();
                        }
                            
                    },
                   
                });
                
            }
            return false;
        });

        // -----Recalculate bulk Subtotal-----------
        jQuery(document).on('click','.bulk_subtotal', function () { 
            let OrderID = jQuery(this).attr('id_data');
            if (confirm("Do you want to recalculate bulk Subtotal.")) {
                jQuery('span.response_message_subtotal').html('<p>Recalculating....</p>');
                let ajax_url = "<?php echo admin_url('admin-ajax.php'); ?>";
                jQuery.ajax({
                    type : "post",
                    url : ajax_url,
                    data : {action: "wp_order_meta_bulksubtotal_function" ,
                        OrderID:OrderID
                    },
                    success: function(data){
                        var responseData = JSON.parse(data);
                        if(responseData.status === 'success'){
                            var subtotalHtml = responseData.subtotal_html;
                            //var totalBeforeDiscount = responseData.total_before_discount;
                            var totalBeforeDiscount = parseFloat(responseData.total_before_discount).toFixed(2);
                            jQuery('span.response_message_subtotal').html('<p> Bulk Discount Subtotal: ' +totalBeforeDiscount + '</p>');
                            jQuery('span.response_message_subtotal').focus();
                            
                        }else{
                            jQuery('span.response_message_subtotal').html('<p>Bulk Discount not eligible for this order.</p>');
                            jQuery('span.response_message_subtotal').focus();
                        }
                        
                                            
                    },
                   
                });
            }
            return false;
         });
         
        // Find the table row with the class "label" containing "Fees:" and hide its parent <tr>
        jQuery('.wc-order-totals .label:contains("Fees:")').closest('tr').hide();

        // Add Discount Button Backend order page
        jQuery(document).on('click','.add-coupon-button', function () { 
            let OrderID = jQuery(this).attr('id-order');
            let ajax_url = "<?php echo admin_url('admin-ajax.php'); ?>";
            let discount_value = prompt("Enter Discount:");
            if (discount_value) {
                if (Number.isInteger(parseInt(discount_value))) {
                    jQuery.ajax({
                        type : "post",
                        url : ajax_url,
                        data : {
                            action: "wp_apply_discount_to_order_fun" ,
                            OrderID:OrderID,
                            discount_value:discount_value
                        },
                        success: function(data){
                            var responseData = JSON.parse(data);
                            if(responseData.status === 'success'){
                                alert(" Discount has been added successfully. ");
                                setTimeout(function(){
                                    location.reload();
                                }, 2000);
                                
                            }else{
                                alert(" Discount not added to this order. ")
                                
                            }
                            
                                                
                        },
                   
                     });
                   
                } else {
                    alert('Only integer values are valid. Please enter a valid integer.');
                }
            } else {
                
            }
            return false;
        });


       
    });
    </script>
    <?php
});
add_action('wp_footer', 'my_admin_footer_js');
function my_admin_footer_js() {
    ?>
    <script>
     //===== Add Items To Cart Button Js=====
    jQuery(document).ready(function() {
        jQuery(document).on('click', '.additem .btn-add-items', function (e) {
            e.preventDefault();
            let dataArray = [];
            let get_container = jQuery('#product-container .product-wrapper');
            get_container.each(function () { 
                let container_this = jQuery(this);
                let product_ID = container_this.attr('data-id');
                container_this.find('.my-stock-input').each(function() {
                    let mythis = jQuery(this);
                    let variation_id = mythis.data('variation-id');
                    let color_name = mythis.closest('.color-wrapper').find('.color-block span').text();
                    let color_code = mythis.closest('.color-wrapper').find('.color-block').css('background-color');
                    let _quantity = mythis.val();
                    if(_quantity != '' && _quantity != 0) {
                        let itemObject = {
                            'product_id': product_ID,
                            'variation_id': variation_id,
                            'item_qty': _quantity,
                            'color_name': color_name,
                            'color_code': color_code
                        }
                        dataArray.push(itemObject);
                    }
                });
            
            });
            if(dataArray.length > 0) {
                let ajax_url = "<?php echo admin_url('admin-ajax.php'); ?>";
               // console.log(dataArray);
                jQuery.ajax({
                    type : "post",
                    url : ajax_url,
                    data : {action: "add_items_to_cart_function" ,
                        dataItem:dataArray
                    },
                    beforeSend: function() {
                        jQuery(".additem .eachitem-cart").text("Processing..");
                    },
                    success: function(data){
                        var responseData = JSON.parse(data);
                        if(responseData.status === 'Yes'){
                            let successNotice = jQuery('.respone_txt');
                            successNotice.attr('style', 'display: block;');
                            jQuery('.iamhere input.my-stock').val(0);
                            jQuery('a.btn-add-items').removeClass('active');
                            jQuery('a.add-to-cart-trigger').removeClass('active');
                            setTimeout(function() {
                                successNotice.hide();
                            }, 7000); 
                        }else if(responseData.status === 'Error'){
                            jQuery('.iamhere input.my-stock').val(0);
                            jQuery('a.btn-add-items').removeClass('active');
                            jQuery('a.add-to-cart-trigger').removeClass('active');
                            jQuery("a.btn-add-items").html('Error for some reason!');
                            setTimeout(function() {
                                jQuery("a.btn-add-items").html('add all selected<br>items to cart');
                            }, 4000);
                        }
                        else{
                            jQuery("a.btn-add-items").html('add all selected<br>items to cart');
                        }
                                       
                    },
                     complete: function() {
                        jQuery("a.btn-add-items").html('add all selected<br>items to cart');
                    },
                   
                });
            }
            
            return false;
        });
        // --------Remove Bulk Discount on Cartpage --------
        jQuery(document).on('click', '.add_remove_discount_action .remove_bulkdiscount', function(e){
             e.preventDefault();
            let ajax_url = "<?php echo admin_url('admin-ajax.php'); ?>";
                jQuery.ajax({
                    type : "post",
                    url : ajax_url,
                    data : {action: "removeCart_bulkdiscount_function"
                    },
                    beforeSend: function() {
                        jQuery('.loader_bulk').addClass('loader_active');
                    },
                    success: function(data){
                        let response = JSON.parse(data);
                        if(response.status === 'remove'){
                            jQuery('button[name="update_cart"]').prop('disabled', false);
                            triggerUpdateCartButtonClick();
                            setTimeout(function() {
                                jQuery('.cart_special_discount_title').addClass('hidden_section');
                                jQuery('.cart_special_discount_table').addClass('hidden_section');
                                jQuery('.add_remove_discount_action').html('<a href="#" class="add_bulkdiscount">Add Bulk Discount</a>');
                                jQuery('.add_remove_discount_action').focus();
                            }, 4000);
                        }else{
                           
                        }
                            
                    },
                    complete: function() {
                        jQuery('.add_remove_discount_action').focus();
                    },
                   
                });
            return false;
        });
        //=========Add Bulk discount on cart page 
        jQuery(document).on('click', '.add_remove_discount_action .add_bulkdiscount', function(e){
             e.preventDefault();
            let ajax_url = "<?php echo admin_url('admin-ajax.php'); ?>";
                jQuery.ajax({
                    type : "post",
                    url : ajax_url,
                    data : {action: "addCart_bulkdiscount_function"
                    },
                    beforeSend: function() {
                        jQuery('.loader_bulk').addClass('loader_active');
                    },
                    success: function(data){
                        let response = JSON.parse(data);
                        if(response.status === 'add'){
                            jQuery('button[name="update_cart"]').prop('disabled', false);
                            triggerUpdateCartButtonClick();
                            //jQuery('a.add_bulkdiscount').css('display', 'none');
                            setTimeout(function() {
                                jQuery('.cart_special_discount_title').removeClass('hidden_section');
                                jQuery('.cart_special_discount_table').removeClass('hidden_section');
                                jQuery('.add_remove_discount_action').html('<a href="#" class="remove_bulkdiscount">Remove Bulk Discount</a>');
                                jQuery('.add_remove_discount_action').focus();
                            }, 4000);
            
                        }else{
                           
                        }
                            
                    },
                    complete: function() {
                        jQuery('.add_remove_discount_action').focus();
                    },
                   
                });
            return false;
        });     



    });
    function triggerUpdateCartButtonClick() {
        jQuery('button[name="update_cart"]').click();
    }


    </script>
    <?php
};
// ===========Add Discount backend order page ========
add_action("wp_ajax_wp_apply_discount_to_order_fun", "wp_apply_discount_to_order_fun");
add_action("wp_ajax_nopriv_wp_apply_discount_to_order_fun", "wp_apply_discount_to_order_fun");

function wp_apply_discount_to_order_fun() {
    if( isset($_POST['OrderID']) && isset($_POST['discount_value'])){
        $Orderid = $_POST['OrderID']; $discount_value = $_POST['discount_value'];
        $finaldiscounttitle = 'Discount';
        $order_ = wc_get_order($Orderid);
        if ($discount_value > 0) {
            $item_fee = new WC_Order_Item_Fee();
            $item_fee->set_name($finaldiscounttitle); 
            $item_fee->set_amount(-$discount_value); 
            $item_fee->set_tax_class(''); 
            $item_fee->set_tax_status('taxable'); 
            $item_fee->set_total(-$discount_value);
            $order_->add_item($item_fee);
            $order_->calculate_totals();
            $order_->save();
            echo json_encode(array('status' => 'success'));
        }else{
            echo json_encode(array('status' => 'error'));
        }

    }
    die();
}

// ===========Remove Bulk Discount from cart function========
add_action("wp_ajax_removeCart_bulkdiscount_function", "removeCart_bulkdiscount_function");
add_action("wp_ajax_nopriv_removeCart_bulkdiscount_function", "removeCart_bulkdiscount_function");

function removeCart_bulkdiscount_function() {
    $setcookie = setcookie('bulkdiscount', 'removed', 0, '/');
    if($setcookie){
        echo json_encode(array('status' => 'remove'));
    }else{
        echo json_encode(array('status' => 'error'));
    }
    die();
}

// =========== Add Bulk Discount in Cart page function========
add_action("wp_ajax_addCart_bulkdiscount_function", "addCart_bulkdiscount_function");
add_action("wp_ajax_nopriv_addCart_bulkdiscount_function", "addCart_bulkdiscount_function");

function addCart_bulkdiscount_function() {
    $setcookie = setcookie('bulkdiscount', 'add', 0, '/');
    if($setcookie){
        echo json_encode(array('status' => 'add'));
    }else{
        echo json_encode(array('status' => 'error'));
    }
    die();
}

// =========Add items to cart function========
add_action("wp_ajax_add_items_to_cart_function", "add_items_to_cart_function");
add_action("wp_ajax_nopriv_add_items_to_cart_function", "add_items_to_cart_function");
function add_items_to_cart_function() {
    global $woocommerce;
    $ItemsData = $_POST['dataItem'];
    if($ItemsData){
        
        foreach($ItemsData as $key => $value){
            $productID = $value['product_id'];
            $variationID = $value['variation_id'];
            $itemQty = $value['item_qty'];
            $finalAddItem = WC()->cart->add_to_cart($productID, $itemQty, $variationID);
            if($finalAddItem){
                $finalmsg = 'Yes';
            }else{
                $finalmsg = 'Error';
            }
        }
    }
    echo json_encode(array('status' => $finalmsg));
    die();
}
// ========End Add items to cart function========

// --------Recalculate Bulk Subtotal function--------
add_action("wp_ajax_wp_order_meta_bulksubtotal_function", "wp_order_meta_bulksubtotal_function");
add_action("wp_ajax_nopriv_wp_order_meta_bulksubtotal_function", "wp_order_meta_bulksubtotal_function");
function wp_order_meta_bulksubtotal_function() {
    $orderId = $_POST['OrderID'];
    $order_ = wc_get_order($orderId);
    $products = $order_->get_items();
    $order_array = array();
    foreach ($products as $product) {
       $product_id = $product['product_id'];
         $subtotal = $product['total'];
     
        $categories = get_the_terms( $product_id, 'product_cat' );
    
        $finalarraytocheck = array();
        foreach ( $categories as $category ) {
            $finalarraytocheck[] = $category->name;
            
        }
        if(in_array('Volumes',$finalarraytocheck)){
            if(isset($order_array['Volumes'])){
                $order_array['Volumes']['total'] += $subtotal;
            }else{
                $order_array['Volumes']['total'] = $subtotal;
            }
        }
        if(in_array('Holds',$finalarraytocheck)){
            if(isset($order_array['Holds'])){
                $order_array['Holds']['total'] += $subtotal;
            }else{
                $order_array['Holds']['total'] = $subtotal;
            }
        }
        if(in_array('Macros',$finalarraytocheck)){
            if(isset($order_array['Macros'])){
                $order_array['Macros']['total'] += $subtotal;
            }else{
                $order_array['Macros']['total'] = $subtotal;
            }
        }
        if(in_array('Training',$finalarraytocheck)){
            if(isset($order_array['Training'])){
                $order_array['Training']['total'] += $subtotal;
            }else{
                $order_array['Training']['total'] = $subtotal;
            }
        }
        
    }
    $total_before_discount = 0;
    $subtotal_html = '';
   
    if($order_array){
        foreach($order_array as $key=>$val){
            $subtotal_html .= '<tr><td>'.$key.'</td><td>'.$val['total'].'</td></tr>';
            $total_before_discount = $total_before_discount + $val['total'];
        }
    }
    $final_array = array();
    if($subtotal_html != '' && $total_before_discount != 0){
        $final_array['total_before_discount'] = $total_before_discount;
        $final_array['subtotal_html'] = $subtotal_html;
        echo json_encode(array('status' => 'success','subtotal_html'=>$subtotal_html,'total_before_discount'=>$total_before_discount));
       
    }else{
        echo json_encode(array('status' => 'error'));
    }
    die();
  
}

//-------Recalculate Bulk Discount backend order
add_action("wp_ajax_wp_order_meta_bulkdiscount_function", "wp_order_meta_bulkdiscount_function");
add_action("wp_ajax_nopriv_wp_order_meta_bulkdiscount_function", "wp_order_meta_bulkdiscount_function");
function wp_order_meta_bulkdiscount_function() {
    $orderId = $_POST['OrderID'];
    $CustomBulkdiscount = $_POST['bulkdiscount'];
    $order_ = wc_get_order($orderId);
    $products = $order_->get_items();
    $order_array = array();
   

    foreach ($products as $product) {
        $product_id = $product['product_id'];
        
        $subtotal = $product['total'];
        $categories = get_the_terms( $product_id, 'product_cat' );
    
        $finalarraytocheck = array();
        foreach ( $categories as $category ) {
            $finalarraytocheck[] = $category->name;
            
        }
        if(in_array('Volumes',$finalarraytocheck)){
            if(isset($order_array['Volumes'])){
                $order_array['Volumes']['total'] += $subtotal;
            }else{
                $order_array['Volumes']['total'] = $subtotal;
            }
        }
        if(in_array('Holds',$finalarraytocheck)){
            if(isset($order_array['Holds'])){
                $order_array['Holds']['total'] += $subtotal;
            }else{
                $order_array['Holds']['total'] = $subtotal;
            }
        }
        if(in_array('Macros',$finalarraytocheck)){
            if(isset($order_array['Macros'])){
                $order_array['Macros']['total'] += $subtotal;
            }else{
                $order_array['Macros']['total'] = $subtotal;
            }
        }
        if(in_array('Training',$finalarraytocheck)){
            if(isset($order_array['Training'])){
                $order_array['Training']['total'] += $subtotal;
            }else{
                $order_array['Training']['total'] = $subtotal;
            }
        }
        
    }
    $total_before_discount = 0;
    if($order_array){
        foreach($order_array as $key=>$val){
            $total_before_discount = $total_before_discount + $val['total'];
        }
    }


    $finalpercetagediscounted = 0;

    if ($total_before_discount != 0) {
        if ($total_before_discount >= 15000) {
            $finalpercetagediscounted = 5;
            $finaldiscounttitle = 'Bold Discount: 15k -5% off Only applies to holds, macros, volumes & training products after any other discounts are applied';
        } elseif ($total_before_discount >= 10000 && $total_before_discount < 15000) {
            $finalpercetagediscounted = 4;
            $finaldiscounttitle = 'Bold Discount: 10k -4% off Only applies to holds, macros, volumes & training products after any other discounts are applied';
        } elseif ($total_before_discount >= 7500 && $total_before_discount < 10000) {
            $finalpercetagediscounted = 3;
            $finaldiscounttitle = 'Bold Discount: 7.5k -3% off Only applies to holds, macros, volumes & training products after any other discounts are applied';
        } elseif ($total_before_discount >= 5000 && $total_before_discount < 7500) {
            $finalpercetagediscounted = 2;
            $finaldiscounttitle = 'Bold Discount: 5k -2% off Only applies to holds, macros, volumes & training products after any other discounts are applied';
        } elseif ($total_before_discount >= 2500 && $total_before_discount < 5000) {
            $finalpercetagediscounted = 1;
            $finaldiscounttitle = 'Bold Discount: 2.5k -1% off Only applies to holds, macros, volumes & training products after any other discounts are applied';
        }
    }

    if ($finalpercetagediscounted != 0) { 
        $discountedValue = $total_before_discount * $finalpercetagediscounted / 100;
        $finalvaluetodis = $discountedValue;
        if(!empty($CustomBulkdiscount) && $CustomBulkdiscount != 'Empty'){
            $discountedValue = $total_before_discount * $CustomBulkdiscount / 100;
            $finalvaluetodis = $discountedValue;
            $finaldiscounttitle = 'Bold Discount: '.$CustomBulkdiscount.'% off';
    
        }
       // $fees = $order_->get_fees();
        // $search_string = 'Bold Discount: applies holds, macros, volumes';
        // foreach ($fees as $fee_id => $fee) {
        //     $fee_name = $fee->get_name();
        //     if (strpos($fee_name, $search_string) !== false) {
        //         $order_->remove_item($fee_id);
        //         //break;
        //     }
        // }
    }else{
        if(!empty($CustomBulkdiscount) && $CustomBulkdiscount != 'Empty'){
            $discountedValue = $total_before_discount * $CustomBulkdiscount / 100;
            $finalvaluetodis = $discountedValue;
            $finaldiscounttitle = 'Bold Discount: '.$CustomBulkdiscount.'% off';
    
        }

    }
    if ($finalvaluetodis > 0) {
        $item_fee = new WC_Order_Item_Fee();
        $item_fee->set_name($finaldiscounttitle); 
        $item_fee->set_amount(-$finalvaluetodis); 
        $item_fee->set_tax_class(''); 
        $item_fee->set_tax_status('taxable'); 
        $item_fee->set_total(-$finalvaluetodis);
        $order_->add_item($item_fee);
        $order_->calculate_totals();
        $order_->save();
        echo json_encode(array('status' => 'success'));
    }else{
        echo json_encode(array('status' => 'error'));
    }
    /*
    if($finalpercetagediscounted == 0){
        echo json_encode(array('status' => 'error'));
    }
    */
    die();
}


// -----Custom Add shipping in backend order---------- 
add_action("wp_ajax_wp_order_meta_shipping_function", "wp_order_meta_shipping_function");
add_action("wp_ajax_nopriv_wp_order_meta_shipping_function", "wp_order_meta_shipping_function");
function wp_order_meta_shipping_function() {
    $orderId = $_POST['OrderID'];
    $shipping_cost = $_POST['shipping_cost'];
    $shipping_label = $_POST['shipping_label'];
    $order = wc_get_order($orderId);
    if ($order) {
        $shipping_item = new WC_Order_Item_Shipping();
        $shipping_item->set_method_title($shipping_label); 
        $shipping_item->set_method_id('custom_shipping_method');

       $shipping_item->set_total($shipping_cost);
       $order->add_item($shipping_item);

        $order->calculate_totals();
        $order->save();
        echo json_encode(array('status' => 'success'));
        
        
    } else {
        echo json_encode(array('status' => 'error'));
    }
    die();
}


add_action("wp_ajax_wp_order_meta_function", "wp_order_meta_function");
add_action("wp_ajax_nopriv_wp_order_meta_function", "wp_order_meta_function");
function wp_order_meta_function() {
    $orderId = $_POST['OrderID'];
    if($orderId){
        $update = update_post_meta( $orderId, '_transaction_id', '' );
        echo $update;
    }
    die();
}
/* -----End -------- */

/* ------Search item formate -------*/
add_action('woocommerce_after_shop_loop_item_title' , 'gouravtech_action_woocommerce_shop_page');

function gouravtech_action_woocommerce_shop_page(){
    global $WOOCS;
    global $product;
    if(is_search()){
        $isproductID = $product->get_id();
        $url = get_permalink( $isproductID );
        $user_id = get_current_user_id(); 
        $_product = wc_get_product( get_the_ID() );
        $itemcat = get_the_terms($product_id,'product_cat');
        $itemsize = get_post_meta( $isproductID, 'bold_product_size', true);
        if( $user_id ){
            $user_meta = get_userdata( $user_id );
            $wholesale_user = in_array( 'wholesale_customer', $user_meta->roles );
        }
        $isitembrand = '';
        foreach ( $itemcat as $cat ) {
            $cat_id = $cat->term_id;
            $isbrand = get_term_meta( $cat_id , 'bold_product_brand', true );
            if( $isbrand == "Yes" ){
                $isitembrand = $cat->name;
            }
        }
        if($_product){
            if ($_product->is_type('variable')) {
                $variations = $_product->get_children();
                foreach ($variations as $variation_id) {
                    $variation = wc_get_product($variation_id);
                    if($variation){
                        if($wholesale_user){
                            $w_price =  get_post_meta( $variation_id, 'wholesale_customer_wholesale_price', true );
                            break;
                        }else{
                            $w_price = $variation->get_regular_price();
                            break;
                        }
                    }
                }
            }else{
                if($wholesale_user){
                    $w_price =  get_post_meta( $isproductID, 'wholesale_customer_wholesale_price', true );
                }else{
                    $w_price = $_product->get_regular_price();
                }
            }
        }
        $isfinalprice = wc_price($w_price);
        if( $isitembrand ){
           echo '<div class="price-wrapper catproduct">
                    <span class="product-brand"><strong>'.$isitembrand.'</strong> • </span>
                    <span class="product-size">'.$itemsize.' • </span>
                    <span class="product-price">'.$isfinalprice.'</span>
                </div>';
        }
    }
}
// ----- GTech Add Column in Order Table ------//
add_filter( 'manage_edit-shop_order_columns', 'custom_shop_order_column', 20 );
function custom_shop_order_column($columns)
{
    $gym_columns = array();

    foreach( $columns as $key => $column){
        $gym_columns[$key] = $column;
        if( $key ==  'order_number' ){
            $gym_columns['custom-details'] = __('Customer', 'theme_domain');
            $gym_columns['business-column'] = __( 'Business','theme_domain');
        }
    }
    return $gym_columns;
}

add_action( 'manage_shop_order_posts_custom_column' , 'custom_orders_list_column_content', 20, 2 );
function custom_orders_list_column_content( $column, $order_id )
{
    $order = wc_get_order( $order_id );
    switch ( $column )
    {
        case 'business-column' :
            $isval_gym = $order->get_billing_company() ? $order->get_billing_company() : $order->get_shipping_company();
            if(!empty($isval_gym))
                echo $isval_gym;
            else
                echo '<small>—</small>';

        break;

        case 'custom-details' :
            $customer_id = $order->get_user_id();
            if ( $customer_id ) {
                $user_info = get_userdata( $customer_id );
                
                $customer_email = $user_info->user_email;
                $customer_name = $user_info->display_name;

                echo '<small>'. esc_html( $customer_name ) .'<br>'.esc_html( $customer_email ).'</small>';
                
                
            } else {
                echo '<small>—</small>';
            }
        break;

    }
}





add_action('woocommerce_before_calculate_totals', 'tax_exempt_based_on_shipping_address', 10);

function tax_exempt_based_on_shipping_address($cart) {
    if (is_admin() && !defined('DOING_AJAX')) {
        return;
    }

    $exempt_country = 'US';

    $exempt_state = 'CA';

    $shipping_address = WC()->customer->get_shipping();

   
    if ($shipping_address['country'] === $exempt_country && $shipping_address['state'] === $exempt_state) {
        WC()->customer->set_is_vat_exempt(false);
    } else {
        WC()->customer->set_is_vat_exempt(true);
    }


    // Mtch 03-May-2024
    if ( empty( $cart->get_cart() ) ) {
        return;
    }
    global $wpdb;
    $user_id = get_current_user_id();
    $isWholesaleUser = false;
    if($user_id){
        $user_meta = get_userdata( $user_id );
        $isWholesaleUser = in_array( 'wholesale_customer', $user_meta->roles );
    }
    foreach ( $cart->get_cart() as $cart_item_key => $cart_item ) {
        $product_id = $cart_item['product_id']; 
        $product = wc_get_product($product_id);
        if ( $product->is_type('variable') ) {
            $variation_id = $cart_item['variation_id'];
            $variation = wc_get_product($variation_id);
        } else {
            $variation = $product;
            $variation_id = $product_id;
        }
        
        $quantity = $cart_item['quantity'];
        $_itemtotal = $cart_item['line_total'];

        // Get product stock data
        $stock_sale_current = get_post_meta( $product_id, 'stock_sale_current', true ) === 'on';
        $stock_sale_future = get_post_meta( $product_id, 'stock_sale_future', true ) === 'on';
        $stock_sale_mto = get_post_meta( $product_id, 'stock_sale_mto', true ) === 'on';


        // Get discount data
        $retail_discount_cost = get_post_meta($product_id, 'discount_retail_cost', true);
        $wholesale_discount_cost = get_post_meta($product_id, 'discount_wholesale_cost', true);
       

        if($isWholesaleUser){
            $force_final_discount = intval($wholesale_discount_cost);
            $price =  get_post_meta( $variation_id, 'wholesale_customer_wholesale_price', true );
        }else{
            $force_final_discount = intval($retail_discount_cost);
            $price = $variation->get_regular_price();
        }

        // ---Check sale option checked 
        if ( $stock_sale_current || $stock_sale_future || $stock_sale_mto ) {


           $finalproductQTY = array();
           $finalproductQTY['current'] = 0;
           $finalproductQTY['future'] = 0;
            $final_product_qty = 0;
            if($variation_id){
                $sql_inbound = "SELECT wi.product_id, wm.stock_quantity as inbound_stock FROM wp_atum_inventories wi
                                LEFT JOIN wp_atum_inventory_meta wm ON wi.id = wm.inventory_id
                                WHERE wi.product_id IN (" . $variation_id . ") and wi.priority = 1";
    
                $meta_values = $wpdb->get_results(
                    $sql_inbound, ARRAY_A 
                );  
                foreach( $meta_values as $itm ){
                   $finalproductQTY['future'] = $itm[ 'inbound_stock' ] * 1;
                }
    
                $meta_values = $wpdb->get_results(
                    "select product_id, stock_quantity from wp_wc_product_meta_lookup where product_id in (" . $variation_id . ")", 
                    ARRAY_A
                );
                foreach( $meta_values as $itm ){
                   $finalproductQTY['current'] = $itm[ 'stock_quantity' ] * 1;
                }
                
            }
           
            $backendstock = 0;
    
            $totalbackendvalue = $finalproductQTY['current'] + $finalproductQTY['future'];

            $newsetprice = $price;
            if($stock_sale_mto == 'on' && $stock_sale_current == 'on' && $stock_sale_future == 'on'){
                $finalprice = $price * $quantity; //100
                $discounted_price = ($finalprice * $force_final_discount) / 100; //10
                $newsetprice = $finalprice - $discounted_price; //90
                $newsetprice = $newsetprice/$quantity; //90

            }
            elseif($stock_sale_mto == 'on' && $stock_sale_current == 'on' && $stock_sale_future == ''){

                if($quantity <= $finalproductQTY['current']){

                    $finalprice = $price * $quantity; 
                    $discounted_price = ($finalprice * $force_final_discount) / 100;
                    $newsetprice = $finalprice - $discounted_price;
                    $newsetprice = $newsetprice/$quantity;
                }
                else{
                    $additionalqty = $quantity - $finalproductQTY['current'];
                    if($additionalqty <= $finalproductQTY['future'] ){
                        $finalprice = $price * $finalproductQTY['current'];
                        $discounted_price = ($finalprice * $force_final_discount / 100);
                        $newsetpricebefore = $finalprice - $discounted_price;
                        $againpricesimple = $additionalqty * $price;
                        $newsetprice = $againpricesimple + $newsetpricebefore;
                        $newsetprice = $newsetprice/$quantity;
                    }
                    else{
                        $mtoqty = $quantity - $totalbackendvalue;
                        $otherdiscountedqty = $finalproductQTY['current'] + $mtoqty;
                        $finalprice = $price * $otherdiscountedqty;
                        $discounted_price = ($finalprice * $force_final_discount / 100);
                        $newsetpricebeforec = $finalprice - $discounted_price;

                        $newfvalue = $finalproductQTY['future'] *$price; 
                        $newsetprice = $newfvalue + $newsetpricebeforec;
                        $newsetprice = $newsetprice/$quantity;


                    }

                }
            }
            elseif($stock_sale_mto == 'on' && $stock_sale_current == '' && $stock_sale_future == ''){
                if($totalbackendvalue >= $quantity){
                    $newsetprice = $price;
                }
                else{
                    $discountedqty = $quantity - $totalbackendvalue;//2
                    $newwithourdiscountedprice = $totalbackendvalue * $price;//500
                    $finalprice = $price * $discountedqty; //200
                    $discounted_price = ($finalprice * $force_final_discount / 100); // 20
                    $newsetpricebefore = $finalprice - $discounted_price; // 180
                    $newsetprice = $newwithourdiscountedprice + $newsetpricebefore; //400.9
                    $newsetprice = $newsetprice/$quantity; //98
                }
            }
            elseif($stock_sale_mto == 'on' && $stock_sale_current == '' && $stock_sale_future == 'on'){

                if($quantity <= $finalproductQTY['current']){
                    $newsetprice = $price;
                   
                }
                else{
                    $additionalqty = $quantity - $finalproductQTY['current']; //3
                    $finalprice = $price * $additionalqty; //300
                    $discounted_price = ($finalprice * $force_final_discount / 100); // 30
                    $newsetpricebefore = $finalprice - $discounted_price; // 270
                    $againpricesimple = $finalproductQTY['current'] * $price; //100
                    $newsetprice = $againpricesimple + $newsetpricebefore; //370
                    $newsetprice = $newsetprice/$quantity; //
                }

               /* if($finalproductQTY['current'] >= 0){
                    $additionalqty = $quantity - $finalproductQTY['current']; //3
                    $finalprice = $price * $additionalqty; //300
                    $discounted_price = ($finalprice * $force_final_discount / 100); // 30
                    $newsetpricebefore = $finalprice - $discounted_price; // 270
                    $againpricesimple = $finalproductQTY['current'] * $price; //100
                    $newsetprice = $againpricesimple + $newsetpricebefore; //370
                    $newsetprice = $newsetprice/$quantity; //

                }else{
                    $finalprice = $price * $quantity; //100
                    $discounted_price = ($finalprice * $force_final_discount) / 100; //10
                    $newsetprice = $finalprice - $discounted_price; //90
                    $newsetprice = $newsetprice/$quantity; //90

                }*/
               /* if($quantity <= $finalproductQTY['current']){
                    $newsetprice = $price;
                   
                }
                else{
                    $additionalqty = $quantity - $finalproductQTY['future'];// 3
                    if($additionalqty <= $finalproductQTY['current'] ){

                        echo 'here';
                        $finalprice = $price * $finalproductQTY['future']; //200
                        $discounted_price = ($finalprice * $force_final_discount / 100); // 21.1
                        $newsetpricebefore = $finalprice - $discounted_price; // 189.9
                        $againpricesimple = $additionalqty * $price;
                        $newsetprice = $againpricesimple + $newsetpricebefore; //400.9
                        $newsetprice = $newsetprice/$quantity; //98. 
                    }
                    else{
                        $mtoqty = $quantity - $totalbackendvalue;
                        $otherdiscountedqty = $finalproductQTY['future'] + $mtoqty;


                        $finalprice = $price * $otherdiscountedqty; //200
                        $discounted_price = ($finalprice * $force_final_discount / 100); // 21.1
                        $newsetpricebeforec = $finalprice - $discounted_price; // 189.9

                        $newfvalue = $finalproductQTY['current'] * $price; 
                        $newsetprice = $newfvalue + $newsetpricebeforec; //400.9

                        $newsetprice = $newsetprice/$quantity; //98
                    }


                }*/






            }
            elseif($stock_sale_mto == '' && $stock_sale_current == '' && $stock_sale_future == 'on'){
                if($finalproductQTY['current'] >= $quantity){
                    $newsetprice = $price;
                }
                elseif($quantity == $finalproductQTY['future']){
                    $finalprice = $price * $quantity; //100
                    $discounted_price = ($finalprice * $force_final_discount) / 100; //10
                    $newsetprice = $finalprice - $discounted_price; //90
                    $newsetprice = $newsetprice/$quantity; //90
                }
                elseif($quantity > $finalproductQTY['future']){
                    $checkhowmuchqty = $quantity - $finalproductQTY['future']; //1
                    $newwithourdiscountedprice = $checkhowmuchqty * $price;//211
                    $finalprice = $price * $finalproductQTY['future']; //211
                    $discounted_price = ($finalprice * $force_final_discount / 100); // 21.1
                    $newsetpricebefore = $finalprice - $discounted_price; // 189.9
                    $newsetprice = $newwithourdiscountedprice + $newsetpricebefore; //400.9
                    $newsetprice = $newsetprice/$quantity; //98
        
                    
                }
                else{
                    $newsetprice = $price;
                }
            }
            elseif($stock_sale_mto == '' && $stock_sale_current == 'on' && $stock_sale_future == ''){
               // echo 'Yes';
                if($quantity <= $finalproductQTY['current']){
                    $finalprice = $price * $quantity; //100
                    $discounted_price = ($finalprice * $force_final_discount) / 100; //10
                    $newsetprice = $finalprice - $discounted_price; //90
                    $newsetprice = $newsetprice/$quantity; //90
                }
                elseif($quantity > $finalproductQTY['current']){
                    $checkhowmuchqty = $quantity - $finalproductQTY['current']; //1
                    $newwithourdiscountedprice = $checkhowmuchqty * $price;//211
                    $finalprice = $price * $finalproductQTY['current']; //211
                    $discounted_price = ($finalprice * $force_final_discount / 100); // 21.1
                    $newsetpricebefore = $finalprice - $discounted_price; // 189.9
                    $newsetprice = $newwithourdiscountedprice + $newsetpricebefore; //400.9
                    $newsetprice = $newsetprice/$quantity; //98

                    //echo $newsetprice. '<br>';
        
                    
                }
                else{
                    $newsetprice = $price;
                }
            }
            elseif($stock_sale_mto == '' && $stock_sale_current == 'on' && $stock_sale_future == 'on'){
                if($quantity == $totalbackendvalue){
                    $finalprice = $price * $quantity; //100
                    $discounted_price = ($finalprice * $force_final_discount) / 100; //10
                    $newsetprice = $finalprice - $discounted_price; //90
                    $newsetprice = $newsetprice/$quantity; //90
                }
                elseif($quantity > $totalbackendvalue){
                    $checkhowmuchqty = $quantity - $totalbackendvalue; //1
                    $newwithourdiscountedprice = $checkhowmuchqty * $price;//211
                    $finalprice = $price * $totalbackendvalue; //211
                    $discounted_price = ($finalprice * $force_final_discount / 100); // 21.1
                    $newsetpricebefore = $finalprice - $discounted_price; // 189.9
                    $newsetprice = $newwithourdiscountedprice + $newsetpricebefore; //400.9
                    $newsetprice = $newsetprice/$quantity; //98
                    
                }
                else{
                    $newsetprice = $price;
                }
            }
            elseif($stock_sale_mto == '' && $stock_sale_current == '' && $stock_sale_future == ''){
                $newsetprice = $price;
            }
            else{
                $newsetprice = $price;
            }
            
            $cart_item['data']->set_price( $newsetprice );
           
        }
       
    }
}





//---------- Negtive Fees Value Visible In Order Summary Backend---------------//
add_action('woocommerce_admin_order_totals_after_tax', 'gtech_custom_admin_order_totals_after_tax', 10, 1);
function gtech_custom_admin_order_totals_after_tax($order_id) {
    //$target_order_id = 186231; 
    if ($order_id) {
        $order = wc_get_order($order_id);
        $fee_items = $order->get_fees();

        $Fees_Cost = 0;
        foreach ($fee_items as $item_id => $item) {
            $label_Name = $item->get_name(); 
            if (preg_match('/^.*?(\d+(\.\d+)?[kK]) -\d+% off/', $label_Name, $matches)) {
                $extracted_label = $matches[0];
                
            }else{
                $extracted_label = $label_Name;
            }
            if ($item->get_total() < 0) {
                $Fees_Cost = $Fees_Cost + $item->get_total() + $item->get_total_tax();
                ?>
                <tr>
                    <td class="label"><?php echo $extracted_label ?>:</td>
                    <td width="1%"></td>
                    <td class="custom-total"><?php echo wc_price($item->get_total()); ?></td>
                </tr>
            <?php
            }else{
                
                ?>
                <tr>
                    <td class="label"><?php echo $label_Name ?>:</td>
                    <td width="1%"></td>
                    <td class="custom-total"><?php echo wc_price($item->get_total()); ?></td>
                </tr>
            <?php
                }
                
        }
        
        
    }
}

//========== Formated Fee section in Invoice/packing========
add_filter('wf_pklist_alter_total_fee', 'wt_pklist_new_formated_fee', 10, 5);
function wt_pklist_new_formated_fee($fee_total_amount_formated, $template_type, $fee_total_amount, $user_currency, $order){
    $order_id = $order->get_id();
    $fee_items = $order->get_fees();
    $Fees_Cost = 0; 
    $total_val1 = ''; 
    $total_val2 = '';
    foreach ($fee_items as $item_id => $item) {
        $label_Name = $item->get_name();
        $matches = 'Bold Discount';
        if (preg_match("/\b{$matches}\b/", $label_Name)) {
            $extracted_label = $matches[0];
            $Fees_Cost = $item->get_total() + $item->get_total_tax();
            $total_val1 .= $Fees_Cost.'$ via '.$label_Name.'<br>';
            $fee_rows1 = '<tr class="wfte_payment_summary_table_row wfte_product_table_bold_discount">
                                <td colspan="2" class="wfte_product_table_discount_fee_label wfte_text_right">Bold Discount</td>
                                <td class="wfte_right_column wfte_text_left">'.$total_val1.'</td>
                            </tr>';
        }else{
            $Fees_Cost = $item->get_total() + $item->get_total_tax();
            $total_val2 .= $Fees_Cost.'$ via '.$label_Name.'<br>';
            $fee_rows2 = '<tr class="wfte_payment_summary_table_row wfte_product_table_fee">
                                <td colspan="2" class="wfte_product_table_fee_label wfte_text_right">Fee</td>
                                <td class="wfte_right_column wfte_text_left">'.$total_val2.'</td>
                            </tr>';
        }
            
            
        
        
        
        
    }
    return $fee_rows1 . $fee_rows2;
    //$fee_total_amount_formated = '.';
    //return $fee_total_amount_formated;
}
// 

// ******* Unset Cookies when Order Comeplete ********
add_action('woocommerce_thankyou', 'wp_test_1_function');
function wp_test_1_function($order_id){
	$order = wc_get_order( $order_id );
    $order->update_status( 'wc-custom-status' ); 
	
    if (isset($_COOKIE['bulkdiscount'])) {
        unset($_COOKIE['bulkdiscount']); 
        setcookie('bulkdiscount', '', 0, '/');
    } else {
    
    }
}
//! Disable Enter key in checkout
add_action( 'woocommerce_before_checkout_form', 'boldclimbing_disable_enter_key_woo_checkout' );
function boldclimbing_disable_enter_key_woo_checkout() {
   wc_enqueue_js( "
      $('form.checkout').on('keypress',function(e) {
         if (e.which == 13) {
            return false;
         }
      });
   " );
}

// **** Add Custom Order status *****
add_action( 'init', 'register_custom_order_status' );
function register_custom_order_status() {
    register_post_status( 'wc-custom-status', array(
        'label'                     => _x( 'Pending', 'Order status', 'woocommerce' ),
        'public'                    => true,
        'exclude_from_search'       => false,
        'show_in_admin_all_list'    => true,
        'show_in_admin_status_list' => true,
        'label_count'               => _n_noop( 'Pending <span class="count">(%s)</span>', 'Pending <span class="count">(%s)</span>', 'woocommerce' ),
    ) );
}

add_filter( 'wc_order_statuses', 'bold_wc_renaming_order_status' );
function bold_wc_renaming_order_status( $order_statuses ) {
    foreach ( $order_statuses as $key => $status ) {
        if ( 'wc-on-hold' === $key ) 
            $order_statuses['wc-on-hold'] = _x( 'Processing Order', 'Order status', 'woocommerce' );
    }
	 $order_statuses['wc-custom-status'] = _x( 'Pending', 'Order status', 'woocommerce' );
    return $order_statuses;
}
add_filter( 'wc_order_is_editable', 'bold_custom_order_status_editable', 9999, 2 );
function bold_custom_order_status_editable( $allow_edit, $order ) {
    if ( $order->get_status() === 'custom-status' ) {
        $allow_edit = true;
    }
    return $allow_edit;
}
// ***** End ******

// =========== Custom Status Email trigger Function ===========
add_filter( 'woocommerce_email_recipient_customer_on_hold_order', 'stop_on_hold_order_notification_for_specified_payment', 10, 2 );
function stop_on_hold_order_notification_for_specified_payment( $recipient, $order ) {
	$oldstatus =  get_post_meta( $order->get_id(), '_old_status', true );
	if( $order->has_status('on-hold')  && $oldstatus == 'pending' ) {
		 $recipient = '';
		 update_post_meta( $order->get_id(), '_old_status', 'on-hold' );
	 }
   return $recipient;
}

add_action( 'woocommerce_new_order', 'create_invoice_for_wc_order',  1, 2  );
function create_invoice_for_wc_order( $order_id, $order ) {
    update_post_meta( $order_id, '_old_status', 'pending' );
}


add_action( 'woocommerce_order_status_changed', 'trigger_on_hold_email_admin', 10, 4 );
function trigger_on_hold_email_admin( $order_id, $status_from, $status_to, $order ) {
    $mailer = WC()->mailer()->get_emails();
    if ( $status_to === 'on-hold' && is_admin() ) {
        $mailer['WC_Email_Customer_On_Hold_Order']->trigger( $order_id );
        update_post_meta( $order_id, '_old_status', 'on-hold' );
    }
}

add_action( 'woocommerce_thankyou', 'bold_custom_change_order_status' );
function bold_custom_change_order_status( $order_id ) {
    $order = wc_get_order( $order_id );
    $order->update_status( 'wc-custom-status' ); 

    $email = $order->get_billing_email();
    $mailer = WC()->mailer();
    $subject = __("Thanks for your order!", 'theme_name');
    $content = get_custom_email_html( $order, $subject, $mailer );
    $headers = "Content-Type: text/html\r\n";
    $mailer->send( $email, $subject, $content, $headers );

}

function get_custom_email_html( $order, $heading = false, $mailer ) {
	$template = 'emails/bold-custom-email.php';
	return wc_get_template_html( $template, array(
		'order'         => $order,
		'email_heading' => $heading,
		'sent_to_admin' => false,
		'plain_text'    => false,
		'email'         => $mailer
	) );

}
// ==== End ======

// ========= Bulk Action Custom Order Status =======
add_filter('bulk_actions-edit-shop_order', 'bold_climbing_custom_status_bulk_action');
function bold_climbing_custom_status_bulk_action($bulk_actions) {
	$bulk_actions['mark_custom-status'] = 'Change status to Pending';
    return $bulk_actions;
}
add_filter( 'bulk_actions-edit-shop_order', 'bold_bulk_actions_order_status', 20, 1 );
function bold_bulk_actions_order_status( $actions ) {
    $actions['mark_on-hold']    = __( ' Change status to Processing Order', 'woocommerce' );
    return $actions;
}
foreach( array( 'post', 'shop_order' ) as $hook )
    add_filter( "views_edit-shop_order", 'bold_order_status_top_changed' );

function bold_order_status_top_changed( $views ){
    if( isset( $views['wc-on-hold'] ) )
        $views['wc-on-hold'] = str_replace( 'On hold', __( 'Processing Order', 'woocommerce'), $views['wc-on-hold'] );

     return $views;
}


add_filter('handle_bulk_actions-edit-shop_order', 'bold_handle_custom_status_bulk_action', 10, 3);
function bold_handle_custom_status_bulk_action($redirect_to, $doaction, $post_ids) {
    if ($doaction !== 'mark_custom-status') {
        return $redirect_to;
    }

    foreach ($post_ids as $post_id) {
        $order = wc_get_order($post_id);
        $order->update_status('custom-status');
    }

    $redirect_to = add_query_arg('bulk_action=marked_custom-status', count($post_ids), $redirect_to);
    return $redirect_to;
}
// ======= End ========

// ====== Custom checkbox for variation====
// Add checkbox
add_action( 'woocommerce_variation_options', 'bold_action_woocommerce_variation_options', 10, 3);
function bold_action_woocommerce_variation_options( $loop, $variation_data, $variation ) {
    $is_checked = get_post_meta( $variation->ID, '_backorders_allow', true );

    if ( $is_checked == 'yes' ) {
        $is_checked = 'checked';
    } else {
        $is_checked = '';     
    }
   

    ?>
    <label class="tips" data-tip="<?php esc_attr_e( 'Allow backorders', 'woocommerce' ); ?>">
        <?php esc_html_e( 'Backorders', 'woocommerce' ); ?>
        <input type="checkbox" class="checkbox variable_checkbox" name="_backorders_allow[<?php echo esc_attr( $loop ); ?>]"<?php echo $is_checked; ?>/>
    </label>
    <?php
}
function action_woocommerce_save_product_variation( $variation_id, $i ) {
    if ( ! empty( $_POST['_backorders_allow'] ) && ! empty( $_POST['_backorders_allow'][$i] ) ) {
        update_post_meta( $variation_id, '_backorders_allow', 'yes' );
    } else {
        update_post_meta( $variation_id, '_backorders_allow', 'no' ); 
    }       
       
}
add_action( 'woocommerce_save_product_variation', 'action_woocommerce_save_product_variation', 10, 2 );
/* ENd */

// ---- Bold Cart Item Export----
add_action('wp_ajax_export_cart_items_function_callback', 'export_cart_items_function_callback');
add_action('wp_ajax_nopriv_export_cart_items_function_callback', 'export_cart_items_function_callback');
function export_cart_items_function_callback() {
    $file_header_array =array();
    $file_header_array['productid'] = 'ProductID#';
    $file_header_array['variationid'] = 'VariationID#';
    $file_header_array['quantity'] = 'Quantity';
    $file_header_array['productname'] = 'Proiduct Name';
        
    $newheaderarray = array();
    foreach( $file_header_array as $field ){
        $newheaderarray[] = $field;
    }

    //SCV Header
    $csv_data = array (
        $newheaderarray
    );
    $cart = WC()->cart->get_cart();
    $itemArray = array();
    
    foreach($cart as $cart_item_key => $cart_item) {
        $product_id = $cart_item['product_id']; 
        $variation_id = $cart_item['variation_id']; 
        $quantity = $cart_item['quantity']; 
        $product_name = $cart_item['data']->get_name(); 
        
        $itemArray[] = array(
            'parent_product_id' => $product_id,
            'variation_id' => $variation_id,
            'quantity' => $quantity,
            'product_name' => $product_name
        );
    }
    if($itemArray){
        foreach($itemArray as $value_item){
            $new_item = array();
            foreach($file_header_array as $key => $value){
                switch ($key){
                    case 'productid':
                        $new_item[] = $value_item['parent_product_id'];
                    break;
                    case 'variationid':
                         $new_item[] = $value_item['variation_id'];
                    break;
                    case 'quantity':
                         $new_item[] = $value_item['quantity'];
                    break;
                    case 'productname':
                         $new_item[] = $value_item['product_name'];
                    break;

                }
            }
            $csv_data[] = $new_item;
        }
    }
    unlink("/www/bold.test-domain-wp.com/cart-item-export/BoldOrder.csv");
    $filename = 'BoldOrder.csv';
    $fp = fopen('/www/bold.test-domain-wp.com/cart-item-export/'.$filename, 'w');
    foreach ($csv_data as $fields) {
        fputcsv($fp, $fields, ",");
    }

    fclose($fp);
    $out[ 'file_link' ] = 'https://boldclimbing.com/cart-item-export/'.$filename;
    $out[ 'file_name' ] = $filename;
    wp_send_json( $out );
    die();
}


/* csv field in cart page */
add_action('wp_ajax_csv_import_action', 'csv_import_action');
add_action('wp_ajax_nopriv_csv_import_action', 'csv_import_action');

function csv_import_action() {
    if (isset($_FILES['csv_file'])) {
        $file = $_FILES['csv_file']['tmp_name'];

        if (($handle = fopen($file, "r")) !== false) {
            while (($data = fgetcsv($handle, 1000, ",")) !== false) {
                
                $product_id = isset($data[0]) ? intval($data[0]) : 0;
                $variation_id = isset($data[1]) ? intval($data[1]) : 0;
                $quantity = isset($data[2]) ? intval($data[2]) : 1; 

               
                if ($product_id > 0 && $quantity > 0) {
                    if ($variation_id > 0) {
                        WC()->cart->add_to_cart($product_id, $quantity, $variation_id);
                    } else {
                        WC()->cart->add_to_cart($product_id, $quantity);
                    }
                }
            }
            fclose($handle);
        }
    }
    wp_die();
}


// 
add_action( 'init', 'custom_product_shortcodes');

function custom_product_shortcodes(){
   add_shortcode('custom-products', 'custom_product_function');
}

function custom_product_function() {
   
	
	$args = array(
		'category' => array( 'static-air' ), // Category slug
		'limit' => -1, // Limit the number of products returned
		'orderby' => 'date', // Order by date
		'order' => 'DESC', // Order in descending order
	);

	$query = new WC_Product_Query( $args );
	$products = $query->get_products();
	$finalhtml = '<ul>';
	// Loop through the products
	foreach ( $products as $product ) {
		 $name = $product->get_name(); // Output product name
		 $product_id = $product->get_id(); // Get product ID
    	 $edit_url = admin_url( "post.php?post=$product_id&action=edit" );
		 $finalhtml .= '<li><a href="'.$edit_url.'">'.$name.'</a></li>';
	}
	$finalhtml .= '</ul>';
  	
    return $finalhtml;
}

//----- Add Button into the backend order page
add_action('woocommerce_order_item_add_action_buttons', 'add_custom_coupon_button', 10, 1);

function add_custom_coupon_button($order) {
    echo '<button type="button" class="button add-coupon-button" id-order="'.$order->get_id().'">Add Discount</button>';
}
//---- End

// %  give a warning to customer
/*
add_action('woocommerce_before_cart_table', 'custom_notice_before_cart_table');
function custom_notice_before_cart_table() {
    $cart = WC()->cart;
    if (empty($cart->get_cart())) {
        return;
    }
    global $wpdb;
    $user_id = get_current_user_id();
    $isWholesaleUser = false;
    if ($user_id) {
        $user_meta = get_userdata($user_id);
        $isWholesaleUser = in_array('wholesale_customer', $user_meta->roles);
    }
    
    $_itemtotal = 0;
    $total_qty = 0;
    $current_stock_total = 0;
    $future_stock_total = 0;
    $mto_stock_total = 0;

    foreach ($cart->get_cart() as $cart_item_key => $cart_item) {
        $product_id = $cart_item['product_id']; 
        $product = wc_get_product($product_id);
        if ($product->is_type('variable')) {
            $variation_id = $cart_item['variation_id'];
            $variation = wc_get_product($variation_id);
        } else {
            $variation = $product;
            $variation_id = $product_id;
        }

        $quantity = $cart_item['quantity'];
        $total_qty += $quantity;
        $_itemtotal += $cart_item['line_total'];
        
        $current_stock = get_option('percentage_of_current_product') ? get_option('percentage_of_current_product') : 0;
        $future_stock = get_option('percentage_of_future_product') ? get_option('percentage_of_future_product') : 0;
        
        if ($current_stock != 0 || $future_stock != 0) {
            $sql_inbound = $wpdb->prepare(
                "SELECT wm.stock_quantity as inbound_stock 
                FROM wp_atum_inventories wi
                LEFT JOIN wp_atum_inventory_meta wm ON wi.id = wm.inventory_id
                WHERE wi.product_id = %d AND wi.priority = 1",
                $variation_id
            );

            $future_stock_item = $wpdb->get_var($sql_inbound);
            $future_stock_item = $future_stock_item ? $future_stock_item : 0;

            $current_stock_item = $wpdb->get_var(
                $wpdb->prepare(
                    "SELECT stock_quantity FROM wp_wc_product_meta_lookup WHERE product_id = %d",
                    $variation_id
                )
            );
            $current_stock_item = $current_stock_item ? $current_stock_item : 0;

            if ($quantity <= $current_stock_item) {
                $current_stock_total += $quantity;
            } else {
                $current_stock_total += $current_stock_item;
                $remaining_qty = $quantity - $current_stock_item;

                if ($remaining_qty <= $future_stock_item) {
                    $future_stock_total += $remaining_qty;
                } else {
                    $future_stock_total += $future_stock_item;
                    $mto_stock_total += ($remaining_qty - $future_stock_item);
                }
            }
        }
    }

    $total_stock = $current_stock_total + $future_stock_total + $mto_stock_total;
    $current_condition = ($current_stock_total / $total_stock) * 100;
    $current_future_condition = (($current_stock_total + $future_stock_total) * 100) / $total_stock;
    $return_val = 0;
    if ($current_stock != 0 || $future_stock != 0) {
        if ($current_condition > $current_stock && $current_condition <= 99.99) {
            wc_print_notice('It looks like most of your order is from current stock, but a few items you selected are coming from future stock or are MTO (Made to order). If you need all your items to come from current stock, please replace these items.', 'notice');
            $return_val = 1;
        }

        if ($current_future_condition > $future_stock && $current_future_condition <= 99.99) {
            if($return_val == 0){
                wc_print_notice('It looks like most of your order is from current or future stock, but a few items you selected are MTO (made to order). If you need all your items to come from current or future stock, please replace these items.', 'notice');
            }
        }
    }
}
*/

