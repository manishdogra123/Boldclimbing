<?php
include_once 'helper.inc.php';


// To initialize your new shipping method you have to keep it in function
function local_shipping_init()
{
    class Proxy_Shipping_Method extends WC_Shipping_Method
    {

        public function __construct($instance_id = 0)
        {
            $this->id = 'proxy_shipping';
            $this->instance_id = absint($instance_id);
            $this->method_title = __('Proxy', 'text-domain');
            $this->method_description = __('Proxy Shipping Method', 'text-domain');
            $this->title = __('Proxy Shipping', 'text-domain');
            $this->supports = array(
                'shipping-zones',
                'instance-settings',
                'instance-settings-modal',
            );

            // then you have to call this method to initiate your settings
            $this->init();
        }


        public function init()
        {
            $this->init_form_fields();
        
            $this->init_instance_settings();

            $this->enabled = $this->get_option('enabled');
            $this->title = __('Proxy Shipping', 'text-domain');

           
            add_action('woocommerce_update_options_shipping_' . $this->id, array($this, 'process_admin_options'));
        }

        public function init_instance_settings()
        {
            $this->instance_form_fields = array(
                'enabled' => array(
                    'title' => __('Enable/Disable'),
                    'type' => 'checkbox',
                    'label' => __('Enable this shipping method'),
                    'default' => 'yes',
                ),
                'title' => array(
                    'title' => __('Method Title'),
                    'type' => 'text',
                    'description' => __('This controls the title which the user sees during checkout.'),
                    'default' => __('Proxy Shipping'),
                    'desc_tip' => true
                ),
                'tax_status' => array(
                    'title' => __('Tax status', 'woocommerce'),
                    'type' => 'select',
                    'class' => 'wc-enhanced-select',
                    'default' => 'taxable',
                    'options' => array(
                        'taxable' => __('Taxable', 'woocommerce'),
                        'none' => _x('None', 'Tax status', 'woocommerce'),
                    ),
                ),
                'cost' => array(
                    'title' => __('Cost', 'woocommerce'),
                    'type' => 'text',
                    'placeholder' => '0',
                    'description' => __('Optional cost for pickup.', 'woocommerce'),
                    'default' => '',
                    'desc_tip' => true,
                ),
            );
        }

        public function calculate_shipping($package = array())
        {
            $this->add_rate(array(
                'id' => $this->id, 
                'label' => $this->title,
                'cost' => 0,
            ));
        }
    }

    class Aragon_Shipping_Method extends WC_Shipping_Method
    {

        public function __construct($instance_id = 0)
        {
            $this->id = 'aragon_shipping';
            $this->instance_id = absint($instance_id);
            $this->method_title = __('Aragon', 'text-domain');
            $this->method_description = __('Aragon Shipping Method', 'text-domain');
            $this->title = __('Aragon Shipping', 'text-domain');
            $this->supports = array(
                'shipping-zones',
                'instance-settings',
                'instance-settings-modal',
            );

           
            $this->init();
        }


        public function init()
        {
            
            $this->init_form_fields();
            $this->init_instance_settings();
            $this->enabled = $this->get_option('enabled');
            $this->title = __('Aragon Shipping', 'text-domain');

            add_action('woocommerce_update_options_shipping_' . $this->id, array($this, 'process_admin_options'));
        }

        public function init_instance_settings()
        {
            
            $this->instance_form_fields = array(
                'enabled' => array(
                    'title' => __('Enable/Disable'),
                    'type' => 'checkbox',
                    'label' => __('Enable this shipping method'),
                    'default' => 'yes',
                ),
                'title' => array(
                    'title' => __('Method Title'),
                    'type' => 'text',
                    'description' => __('This controls the title which the user sees during checkout.'),
                    'default' => __('Aragon Shipping'),
                    'desc_tip' => true
                ),
                'tax_status' => array(
                    'title' => __('Tax status', 'woocommerce'),
                    'type' => 'select',
                    'class' => 'wc-enhanced-select',
                    'default' => 'taxable',
                    'options' => array(
                        'taxable' => __('Taxable', 'woocommerce'),
                        'none' => _x('None', 'Tax status', 'woocommerce'),
                    ),
                ),
                'cost' => array(
                    'title' => __('Cost', 'woocommerce'),
                    'type' => 'text',
                    'placeholder' => '0',
                    'description' => __('Optional cost for pickup.', 'woocommerce'),
                    'default' => '',
                    'desc_tip' => true,
                ),
            );
        }

        public function calculate_shipping($package = array())
        {
            $this->add_rate(array(
                'id' => $this->id,
                'label' => $this->title,
                'cost' => 0
            ));
        }
    }
	
	/* Gaurav Custom shipping */ 
	class Quote_Required_Shipping_Method extends WC_Shipping_Method
    {

        public function __construct($instance_id = 0)
        {
            $this->id = 'quote_required';
            $this->instance_id = absint($instance_id);
            $this->method_title = __('Quote Required', 'text-domain');
            $this->method_description = __('Quote Required Method', 'text-domain');
            $this->title = __('Quote Required', 'text-domain');
            $this->supports = array(
                'shipping-zones',
                'instance-settings',
                'instance-settings-modal',
            );

            $this->init();
        }


        public function init()
        {
            $this->init_form_fields();
            $this->init_instance_settings();

           
            $this->enabled = $this->get_option('enabled');
            $this->title = __('Quote Required', 'text-domain');

            add_action('woocommerce_update_options_shipping_' . $this->id, array($this, 'process_admin_options'));
        }

        public function init_instance_settings()
        {
            $this->instance_form_fields = array(
                'enabled' => array(
                    'title' => __('Enable/Disable'),
                    'type' => 'checkbox',
                    'label' => __('Enable this shipping method'),
                    'default' => 'yes',
                ),
                'title' => array(
                    'title' => __('Method Title'),
                    'type' => 'text',
                    'description' => __('This controls the title which the user sees during checkout.'),
                    'default' => __('Quote Required'),
                    'desc_tip' => true
                ),
                'tax_status' => array(
                    'title' => __('Tax status', 'woocommerce'),
                    'type' => 'select',
                    'class' => 'wc-enhanced-select',
                    'default' => 'taxable',
                    'options' => array(
                        'taxable' => __('Taxable', 'woocommerce'),
                        'none' => _x('None', 'Tax status', 'woocommerce'),
                    ),
                ),
                'cost' => array(
                    'title' => __('Cost', 'woocommerce'),
                    'type' => 'text',
                    'placeholder' => '0',
                    'description' => __('Optional cost for pickup.', 'woocommerce'),
                    'default' => '',
                    'desc_tip' => true,
                ),
            );
        }

        public function calculate_shipping($package = array())
        {
            $this->add_rate(array(
                'id' => $this->id, 
                'label' => $this->title,
                'cost' => 0
            ));
        }
    }
    /* Gtech Custom shipping MTO Stock */ 
	class MTO_stcok_Shipping_Method extends WC_Shipping_Method
    {

        public function __construct($instance_id = 0)
        {
            $this->id = 'mto_stock';
            $this->instance_id = absint($instance_id);
            $this->method_title = __('MTO Stock', 'text-domain');
            $this->method_description = __('MTO Stock Method', 'text-domain');
            $this->title = __('MTO Stock', 'text-domain');
            $this->supports = array(
                'shipping-zones',
                'instance-settings',
                'instance-settings-modal',
            );
            $this->init();
        }


        public function init()
        {
            $this->init_form_fields();
            $this->init_instance_settings();

            $this->enabled = $this->get_option('enabled');
            $this->title = __('MTO Stock', 'text-domain');
            add_action('woocommerce_update_options_shipping_' . $this->id, array($this, 'process_admin_options'));
        }

        public function init_instance_settings()
        {
            $this->instance_form_fields = array(
                'enabled' => array(
                    'title' => __('Enable/Disable'),
                    'type' => 'checkbox',
                    'label' => __('Enable this shipping method'),
                    'default' => 'yes',
                ),
                'title' => array(
                    'title' => __('Method Title'),
                    'type' => 'text',
                    'description' => __('This controls the title which the user sees during checkout.'),
                    'default' => __('MTO Stock'),
                    'desc_tip' => true
                ),
                'tax_status' => array(
                    'title' => __('Tax status', 'woocommerce'),
                    'type' => 'select',
                    'class' => 'wc-enhanced-select',
                    'default' => 'taxable',
                    'options' => array(
                        'taxable' => __('Taxable', 'woocommerce'),
                        'none' => _x('None', 'Tax status', 'woocommerce'),
                    ),
                ),
                'cost' => array(
                    'title' => __('Cost', 'woocommerce'),
                    'type' => 'text',
                    'placeholder' => '0',
                    'description' => __('Optional cost for pickup.', 'woocommerce'),
                    'default' => '',
                    'desc_tip' => true,
                ),
            );
        }

        public function calculate_shipping($package = array())
        {
            $this->add_rate(array(
                'id' => $this->id, 
                'label' => $this->title,
                'cost' => 0
            ));
        }
    }
	
	/* Gtech Custom shipping Future Stock */ 
	class Future_stcok_Shipping_Method extends WC_Shipping_Method
    {

        public function __construct($instance_id = 0)
        {
            $this->id = 'future_stock';
            $this->instance_id = absint($instance_id);
            $this->method_title = __('Future Stock', 'text-domain');
            $this->method_description = __('Future Stock Method', 'text-domain');
            $this->title = __('Future Stock', 'text-domain');
            $this->supports = array(
                'shipping-zones',
                'instance-settings',
                'instance-settings-modal',
            );
            $this->init();
        }


        public function init()
        {
            $this->init_form_fields();
            $this->init_instance_settings();

            $this->enabled = $this->get_option('enabled');
            $this->title = __('Future Stock', 'text-domain');
            add_action('woocommerce_update_options_shipping_' . $this->id, array($this, 'process_admin_options'));
        }

        public function init_instance_settings()
        {
            $this->instance_form_fields = array(
                'enabled' => array(
                    'title' => __('Enable/Disable'),
                    'type' => 'checkbox',
                    'label' => __('Enable this shipping method'),
                    'default' => 'yes',
                ),
                'title' => array(
                    'title' => __('Method Title'),
                    'type' => 'text',
                    'description' => __('This controls the title which the user sees during checkout.'),
                    'default' => __('Future Stock'),
                    'desc_tip' => true
                ),
                'tax_status' => array(
                    'title' => __('Tax status', 'woocommerce'),
                    'type' => 'select',
                    'class' => 'wc-enhanced-select',
                    'default' => 'taxable',
                    'options' => array(
                        'taxable' => __('Taxable', 'woocommerce'),
                        'none' => _x('None', 'Tax status', 'woocommerce'),
                    ),
                ),
                'cost' => array(
                    'title' => __('Cost', 'woocommerce'),
                    'type' => 'text',
                    'placeholder' => '0',
                    'description' => __('Optional cost for pickup.', 'woocommerce'),
                    'default' => '',
                    'desc_tip' => true,
                ),
            );
        }

        public function calculate_shipping($package = array())
        {
            $this->add_rate(array(
                'id' => $this->id, 
                'label' => $this->title,
                'cost' => 0
            ));
        }
    }
	
	/* Gtech Custom shipping Current Stock */ 
	class Current_stcok_Shipping_Method extends WC_Shipping_Method
    {

        public function __construct($instance_id = 0)
        {
            $this->id = 'current_stock';
            $this->instance_id = absint($instance_id);
            $this->method_title = __('Current Stock', 'text-domain');
            $this->method_description = __('Current Stock Method', 'text-domain');
            $this->title = __('Current Stock', 'text-domain');
            $this->supports = array(
                'shipping-zones',
                'instance-settings',
                'instance-settings-modal',
            );
            $this->init();
        }


        public function init()
        {
            $this->init_form_fields();
            $this->init_instance_settings();

            $this->enabled = $this->get_option('enabled');
            $this->title = __('Current Stock', 'text-domain');
            add_action('woocommerce_update_options_shipping_' . $this->id, array($this, 'process_admin_options'));
        }

        public function init_instance_settings()
        {
            $this->instance_form_fields = array(
                'enabled' => array(
                    'title' => __('Enable/Disable'),
                    'type' => 'checkbox',
                    'label' => __('Enable this shipping method'),
                    'default' => 'yes',
                ),
                'title' => array(
                    'title' => __('Method Title'),
                    'type' => 'text',
                    'description' => __('This controls the title which the user sees during checkout.'),
                    'default' => __('Current Stock'),
                    'desc_tip' => true
                ),
                'tax_status' => array(
                    'title' => __('Tax status', 'woocommerce'),
                    'type' => 'select',
                    'class' => 'wc-enhanced-select',
                    'default' => 'taxable',
                    'options' => array(
                        'taxable' => __('Taxable', 'woocommerce'),
                        'none' => _x('None', 'Tax status', 'woocommerce'),
                    ),
                ),
                'cost' => array(
                    'title' => __('Cost', 'woocommerce'),
                    'type' => 'text',
                    'placeholder' => '0',
                    'description' => __('Optional cost for pickup.', 'woocommerce'),
                    'default' => '',
                    'desc_tip' => true,
                ),
            );
        }

        public function calculate_shipping($package = array())
        {
            $this->add_rate(array(
                'id' => $this->id, 
                'label' => $this->title,
                'cost' => 0
            ));
        }
    }
	
	/* Gtech Custom shipping Bold Warehouse */ 
	class bold_warehouse_Shipping_Method extends WC_Shipping_Method
    {

        public function __construct($instance_id = 0)
        {
            $this->id = 'bold_warehouse';
            $this->instance_id = absint($instance_id);
            $this->method_title = __('Bold Warehouse', 'text-domain');
            $this->method_description = __('Bold Warehouse Method', 'text-domain');
            $this->title = __('Bold Warehouse', 'text-domain');
            $this->supports = array(
                'shipping-zones',
                'instance-settings',
                'instance-settings-modal',
            );
            $this->init();
        }


        public function init()
        {
            $this->init_form_fields();
            $this->init_instance_settings();

            $this->enabled = $this->get_option('enabled');
            $this->title = __('Bold Warehouse', 'text-domain');
            add_action('woocommerce_update_options_shipping_' . $this->id, array($this, 'process_admin_options'));
        }

        public function init_instance_settings()
        {
            $this->instance_form_fields = array(
                'enabled' => array(
                    'title' => __('Enable/Disable'),
                    'type' => 'checkbox',
                    'label' => __('Enable this shipping method'),
                    'default' => 'yes',
                ),
                'title' => array(
                    'title' => __('Method Title'),
                    'type' => 'text',
                    'description' => __('This controls the title which the user sees during checkout.'),
                    'default' => __('Bold Warehouse'),
                    'desc_tip' => true
                ),
                'tax_status' => array(
                    'title' => __('Tax status', 'woocommerce'),
                    'type' => 'select',
                    'class' => 'wc-enhanced-select',
                    'default' => 'taxable',
                    'options' => array(
                        'taxable' => __('Taxable', 'woocommerce'),
                        'none' => _x('None', 'Tax status', 'woocommerce'),
                    ),
                ),
                'cost' => array(
                    'title' => __('Cost', 'woocommerce'),
                    'type' => 'text',
                    'placeholder' => '0',
                    'description' => __('Optional cost for pickup.', 'woocommerce'),
                    'default' => '',
                    'desc_tip' => true,
                ),
            );
        }

        public function calculate_shipping($package = array())
        {
            $this->add_rate(array(
                'id' => $this->id, 
                'label' => $this->title,
                'cost' => 0
            ));
        }
    }
	
	/* Gtech Custom shipping CompX */ 
	class CompX_Shipping_Method extends WC_Shipping_Method
    {

        public function __construct($instance_id = 0)
        {
            $this->id = 'CompX';
            $this->instance_id = absint($instance_id);
            $this->method_title = __('CompX', 'text-domain');
            $this->method_description = __('CompX Method', 'text-domain');
            $this->title = __('Bold Warehouse', 'text-domain');
            $this->supports = array(
                'shipping-zones',
                'instance-settings',
                'instance-settings-modal',
            );
            $this->init();
        }


        public function init()
        {
            $this->init_form_fields();
            $this->init_instance_settings();

            $this->enabled = $this->get_option('enabled');
            $this->title = __('CompX', 'text-domain');
            add_action('woocommerce_update_options_shipping_' . $this->id, array($this, 'process_admin_options'));
        }

        public function init_instance_settings()
        {
            $this->instance_form_fields = array(
                'enabled' => array(
                    'title' => __('Enable/Disable'),
                    'type' => 'checkbox',
                    'label' => __('Enable this shipping method'),
                    'default' => 'yes',
                ),
                'title' => array(
                    'title' => __('Method Title'),
                    'type' => 'text',
                    'description' => __('This controls the title which the user sees during checkout.'),
                    'default' => __('CompX'),
                    'desc_tip' => true
                ),
                'tax_status' => array(
                    'title' => __('Tax status', 'woocommerce'),
                    'type' => 'select',
                    'class' => 'wc-enhanced-select',
                    'default' => 'taxable',
                    'options' => array(
                        'taxable' => __('Taxable', 'woocommerce'),
                        'none' => _x('None', 'Tax status', 'woocommerce'),
                    ),
                ),
                'cost' => array(
                    'title' => __('Cost', 'woocommerce'),
                    'type' => 'text',
                    'placeholder' => '0',
                    'description' => __('Optional cost for pickup.', 'woocommerce'),
                    'default' => '',
                    'desc_tip' => true,
                ),
            );
        }

        public function calculate_shipping($package = array())
        {
            $this->add_rate(array(
                'id' => $this->id, 
                'label' => $this->title,
                'cost' => 0
            ));
        }
    }
    class Volx_Required_Shipping_Method extends WC_Shipping_Method
    {

        public function __construct($instance_id = 0)
        {
            $this->id = 'volx_shipping';
            $this->instance_id = absint($instance_id);
            $this->method_title = __('Volx', 'text-domain');
            $this->method_description = __('Volx Method', 'text-domain');
            $this->title = __('Volx Shipping', 'text-domain');
            $this->supports = array(
                'shipping-zones',
                'instance-settings',
                'instance-settings-modal',
            );
            $this->init();
        }


        public function init()
        {
            $this->init_form_fields();
            
            $this->init_instance_settings();
            $this->enabled = $this->get_option('enabled');
            $this->title = __('Volx Shipping', 'text-domain');

          
            add_action('woocommerce_update_options_shipping_' . $this->id, array($this, 'process_admin_options'));
        }

        public function init_instance_settings()
        {

            $this->instance_form_fields = array(
                'enabled' => array(
                    'title' => __('Enable/Disable'),
                    'type' => 'checkbox',
                    'label' => __('Enable this shipping method'),
                    'default' => 'yes',
                ),
                'title' => array(
                    'title' => __('Method Title'),
                    'type' => 'text',
                    'description' => __('This controls the title which the user sees during checkout.'),
                    'default' => __('Volx Shipping'),
                    'desc_tip' => true
                ),
                'tax_status' => array(
                    'title' => __('Tax status', 'woocommerce'),
                    'type' => 'select',
                    'class' => 'wc-enhanced-select',
                    'default' => 'taxable',
                    'options' => array(
                        'taxable' => __('Taxable', 'woocommerce'),
                        'none' => _x('None', 'Tax status', 'woocommerce'),
                    ),
                ),
                'cost' => array(
                    'title' => __('Cost', 'woocommerce'),
                    'type' => 'text',
                    'placeholder' => '0',
                    'description' => __('Optional cost for pickup.', 'woocommerce'),
                    'default' => '',
                    'desc_tip' => true,
                ),
            );
        }

        public function calculate_shipping($package = array())
        {
            $this->add_rate(array(
                'id' => $this->id, 
                'label' => $this->title,
                'cost' => 0
            ));
        }
    }

    
    class Kastline_Required_Shipping_Method extends WC_Shipping_Method
    {

        public function __construct($instance_id = 0)
        {
            $this->id = 'kastline_shipping';
            $this->instance_id = absint($instance_id);
            $this->method_title = __('Volx2', 'text-domain');
            $this->method_description = __('volx2 Method', 'text-domain');
            $this->title = __('Volx2', 'text-domain');
            $this->supports = array(
                'shipping-zones',
                'instance-settings',
                'instance-settings-modal',
            );
            $this->init();
        }


        public function init()
        {
            
            $this->init_form_fields();
           
            $this->init_instance_settings();

            
            $this->enabled = $this->get_option('enabled');
            $this->title = __('Volx2', 'text-domain');

            
            add_action('woocommerce_update_options_shipping_' . $this->id, array($this, 'process_admin_options'));
        }

        public function init_instance_settings()
        {
          
            $this->instance_form_fields = array(
                'enabled' => array(
                    'title' => __('Enable/Disable'),
                    'type' => 'checkbox',
                    'label' => __('Enable this shipping method'),
                    'default' => 'yes',
                ),
                'title' => array(
                    'title' => __('Method Title'),
                    'type' => 'text',
                    'description' => __('This controls the title which the user sees during checkout.'),
                    'default' => __('volx2'),
                    'desc_tip' => true
                ),
                'tax_status' => array(
                    'title' => __('Tax status', 'woocommerce'),
                    'type' => 'select',
                    'class' => 'wc-enhanced-select',
                    'default' => 'taxable',
                    'options' => array(
                        'taxable' => __('Taxable', 'woocommerce'),
                        'none' => _x('None', 'Tax status', 'woocommerce'),
                    ),
                ),
                'cost' => array(
                    'title' => __('Cost', 'woocommerce'),
                    'type' => 'text',
                    'placeholder' => '0',
                    'description' => __('Optional cost for pickup.', 'woocommerce'),
                    'default' => '',
                    'desc_tip' => true,
                ),
            );
        }

        public function calculate_shipping($package = array())
        {
            $this->add_rate(array(
                'id' => $this->id, 
                'label' => $this->title,
                'cost' => 0
            ));
        }
    }
    // ---Kastline_pu
    class Kastline_PU_Required_Shipping_Method extends WC_Shipping_Method
    {

        public function __construct($instance_id = 0)
        {
            $this->id = 'kastline_pu';
            $this->instance_id = absint($instance_id);
            $this->method_title = __('Kastline-PU', 'text-domain');
            $this->method_description = __('Kastline-PU Shipping Method', 'text-domain');
            $this->title = __('Kastline-PU', 'text-domain');
            $this->supports = array(
                'shipping-zones',
                'instance-settings',
                'instance-settings-modal',
            );
            $this->init();
        }


        public function init()
        {
            
            $this->init_form_fields();
           
            $this->init_instance_settings();

            
            $this->enabled = $this->get_option('enabled');
            $this->title = __('Kastline-PU', 'text-domain');

            
            add_action('woocommerce_update_options_shipping_' . $this->id, array($this, 'process_admin_options'));
        }

        public function init_instance_settings()
        {
          
            $this->instance_form_fields = array(
                'enabled' => array(
                    'title' => __('Enable/Disable'),
                    'type' => 'checkbox',
                    'label' => __('Enable this shipping method'),
                    'default' => 'yes',
                ),
                'title' => array(
                    'title' => __('Method Title'),
                    'type' => 'text',
                    'description' => __('This controls the title which the user sees during checkout.'),
                    'default' => __('Kastline-PU'),
                    'desc_tip' => true
                ),
                'tax_status' => array(
                    'title' => __('Tax status', 'woocommerce'),
                    'type' => 'select',
                    'class' => 'wc-enhanced-select',
                    'default' => 'taxable',
                    'options' => array(
                        'taxable' => __('Taxable', 'woocommerce'),
                        'none' => _x('None', 'Tax status', 'woocommerce'),
                    ),
                ),
                'cost' => array(
                    'title' => __('Cost', 'woocommerce'),
                    'type' => 'text',
                    'placeholder' => '0',
                    'description' => __('Optional cost for pickup.', 'woocommerce'),
                    'default' => '',
                    'desc_tip' => true,
                ),
            );
        }

        public function calculate_shipping($package = array())
        {
            $this->add_rate(array(
                'id' => $this->id, 
                'label' => $this->title,
                'cost' => 0
            ));
        }
    }
	
	/* The end */
}

add_action('woocommerce_shipping_init', 'local_shipping_init'); 

function add_local_shipping($methods)
{
    $methods['proxy_shipping'] = 'Proxy_Shipping_Method';
    $methods['aragon_shipping'] = 'Aragon_Shipping_Method';
	$methods['quote_required'] = 'Quote_Required_Shipping_Method';
    
    $methods['mto_stock'] = 'MTO_stcok_Shipping_Method';
	$methods['future_stock'] = 'Future_stcok_Shipping_Method';
	$methods['current_stock'] = 'Current_stcok_Shipping_Method';
	$methods['bold_warehouse'] = 'bold_warehouse_Shipping_Method';
	$methods['CompX'] = 'CompX_Shipping_Method';
    $methods['volx_shipping'] = 'Volx_Required_Shipping_Method';
	$methods['kastline_shipping'] = 'Kastline_Required_Shipping_Method';
	$methods['kastline_pu'] = 'Kastline_PU_Required_Shipping_Method';
    return $methods;
}

add_filter('woocommerce_shipping_methods', 'add_local_shipping');

class BoldShipping{
    private $packs;

    private $_BoldHelper;

    private $_user_id       = 0;
    private $_isWholesale   = false;

    public $cartManufacturerCaption;
    public $cartShippingCaption;

    private $_limit_to_free_noretail = 0;
    private $_limit_to_free_retail = 0;
    private $_local_rate = 0;
    private $_flat_rate_fix = 0;
    private $_flat_rate_weight = 0;

    private $_ups_rate_fix = 1;
    private $_usps_rate_fix = 1;

    private $_shippingClasses = [];
    public $flag_separate;


    private $packages=[];
    public $shippingCaptions;

    public function __construct( $flagInit = false ){

        if ( isset ( $_COOKIE[ 'bold_shipping_option' ] ) and $_COOKIE[ 'bold_shipping_option' ] == 'ship-separate' ){
            $this->flag_separate = true;
        }else{
            $this->flag_separate = false;
        }

        $this->_flat_rate_fix           = get_option( 'dkabz_flat_rate_fix' ) * 1;
        $this->_flat_rate_weight        = get_option( 'dkabz_flat_rate_weight' ) * 1;
        $this->_local_rate              = get_option( 'dkabz_local_rate' ) * 1;
        $this->_ups_rate_fix            = get_option( 'dkabz_ups_rate_fix' );
        $this->_usps_rate_fix           = get_option( 'dkabz_usps_rate_fix' );


        if( $flagInit ){
            global $wpdb;
            $this->_wpdb = $wpdb;
            $this->getShippingClasses();

            $this->_BoldHelper = new BoldHelper;

            $this->shippingCaptions = array(
                "mainStock" => array(
                    "caption"       => get_option( 'dkabz_shipping_main_caption' ),
                    "description"   => get_option( 'dkabz_shipping_main_description' ),
                ),
                "proxyaragon" => array(
                    "caption"       => get_option( 'dkabz_shipping_proxyaragon_caption' ),
                    "description"   => get_option( 'dkabz_shipping_proxyaragon_description' ),
                ),
                "aragon" => array(
                    "caption"       => get_option( 'dkabz_shipping_aragon_caption' ),
                    "description"   => get_option( 'dkabz_shipping_aragon_description' ),
                ),
                "composite" => array(
                    "caption"       => get_option( 'dkabz_shipping_compozite_caption' ),
                    "description"   => get_option( 'dkabz_shipping_compozite_description' ),
                ),
                "staticair" => array(
                    "caption"       => get_option( 'dkabz_shipping_staticair_caption' ),
                    "description"   => get_option( 'dkabz_shipping_staticair_description' ),
                ),
                "stock"    => array(
                    "caption"       => get_option( 'dkabz_shipping_stock_caption' ),
                    "description"   => get_option( 'dkabz_shipping_stock_desc' ),
                ),
                "inbound"    => array(
                    "caption"       => get_option( 'dkabz_shipping_inbound_caption' ),
                    "description"   => get_option( 'dkabz_shipping_inbound_desc' ),
                ),
                "mto"    => array(
                    "caption"       => get_option( 'dkabz_shipping_mto_caption' ),
                    "description"   => get_option( 'dkabz_shipping_mto_desc' ),
                ),
            
                "volx"    => array(
                    "caption"       => get_option( 'dkabz_shipping_volx_caption' ),
                    "description"   => get_option( 'dkabz_shipping_volx_description' ),
                ),
                
                "kastline"    => array(
                    "caption"       => get_option( 'dkabz_shipping_kastline_caption' ),
                    "description"   => get_option( 'dkabz_shipping_kastline_description' ),
                ),
            );

            //Separate cart by types, date delivery
            $this->setUserData();
            $this->_destination = array(
                'country'    => WC()->customer->get_shipping_country(),
                'state'      => WC()->customer->get_shipping_state(),
                'postcode'   => WC()->customer->get_shipping_postcode(),
                'city'       => WC()->customer->get_shipping_city(),
                'address'    => WC()->customer->get_shipping_address(),
                'address_2'  => WC()->customer->get_shipping_address_2()
            );

            $this->_limit_to_free_retail  = get_option( 'dkabz_limit_retail_free' ) * 1;
            $this->_limit_to_free_noretail    = get_option( 'dkabz_limit_noretail_free' ) * 1;

            $this->getCartContents();

        }

        add_filter( 'woocommerce_package_rates', [$this, 'custom_shipping_costs'], 20, 999 );
    }

    public function custom_shipping_costs( $rates, $package ) {
        $new_cost = 0;
        $tax_rate = 0;

        $new_shipping = [];
        $new_shipping[$package['ship_via'][0]] += $package['contents_cost'];

        foreach( $rates as $rate_key => $rate ){
            if( $rate->method_id == 'aragon_shipping'){                
                $percent = get_option('aragon_percent_shipping_price', true);
                $new_cost =  isset($new_shipping['aragon_shipping']) ? $new_shipping['aragon_shipping'] * ($percent / 100) : 0;
                $rates[$rate_key]->cost = $new_cost;

                $taxes = array();
                foreach ($rates[$rate_key]->taxes as $key => $tax){
                    if( $rates[$rate_key]->taxes[$key] > 0 )
                        $taxes[$key] = $new_cost * $tax_rate;
                }
                $rates[$rate_key]->taxes = $taxes;

            } elseif( $rate->method_id == 'proxy_shipping' ) {
                $percent = get_option('proxy_percent_shipping_price', true);
                $new_cost =  isset($new_shipping['proxy_shipping']) ? $new_shipping['proxy_shipping'] * ($percent / 100) : 0;
                $rates[$rate_key]->cost = $new_cost;

                $taxes = array();
                foreach ($rates[$rate_key]->taxes as $key => $tax){
                    if( $rates[$rate_key]->taxes[$key] > 0 )
                        $taxes[$key] = $new_cost * $tax_rate;
                }
                $rates[$rate_key]->taxes = $taxes;
            }
            // ====volx_shipping====
            elseif( $rate->method_id == 'volx_shipping' ) {
                $percent = get_option('volx_percent_shipping_price', true);
                $new_cost =  isset($new_shipping['volx_shipping']) ? $new_shipping['volx_shipping'] * ($percent / 100) : 0;
                $rates[$rate_key]->cost = $new_cost;

                $taxes = array();
                foreach ($rates[$rate_key]->taxes as $key => $tax){
                    if( $rates[$rate_key]->taxes[$key] > 0 )
                        $taxes[$key] = $new_cost * $tax_rate;
                }
                $rates[$rate_key]->taxes = $taxes;
            }
           
            // ====kastline_pu====
            elseif( $rate->method_id == 'kastline_pu' ) {
                
                $percent = get_option('dkabz_kastline_pu_fix', true);
                $flat_rate = get_option('dkabz_kasline_pu_flat', true);
                $new_cost =  isset($new_shipping['kastline_pu']) ? $new_shipping['kastline_pu'] * ($percent / 100) : 0;
                $rates[$rate_key]->cost = $new_cost + $flat_rate;

                $taxes = array();
                foreach ($rates[$rate_key]->taxes as $key => $tax){
                    if( $rates[$rate_key]->taxes[$key] > 0 )
                        $taxes[$key] = $new_cost * $tax_rate;
                }
                $rates[$rate_key]->taxes = $taxes;
            }
        }

        return $rates;
    }

    private function getShipVia( $used_types ){
        if( isset( $used_types[ 'pallet' ] ) ){
            return [ 'local_pickup', 'rlc', 'alg_wc_shipping', 'quote_required','free_shipping', 'kastline_shipping'];
        }
        if( isset( $used_types[ 'retail' ] ) and ( count( $used_types ) == 1 ) ){
            return [ 'local_pickup', 'wf_shipping_usps', 'wf_shipping_ups', 'quote_required', 'kastline_shipping' ] ;
        }

        return [ 'local_pickup', 'wf_shipping_ups', 'rlc', 'alg_wc_shipping', 'quote_required', 'kastline_shipping' ] ;

    }

    public function setPackage( $ship_via, $ship_types, $ship_name /*, $use_formula = false */){

        $packages = [];
        global $woocommerce;
        $stock_types = [ 'stock', 'inbound', 'mto' ];

        $need_check = false;
        if( $ship_via === true ){
            $need_check = true;
        }
        $user_id = get_current_user_id();

        $wholesale_user = false;

        if( $user_id ){
            $user_meta = get_userdata( $user_id );
            $wholesale_user = in_array( 'wholesale_customer', $user_meta->roles );
        }
        if( $this->flag_separate ){

            foreach( $stock_types as $stock_type ){
                $items = [];
                $used_types = [];

                foreach( $ship_types as $ship_type ){

                    if( isset( $this->packs[ $ship_type ][ $stock_type ] ) and $this->packs[ $ship_type ][ $stock_type ] ){
                        if( $this->packs[ $ship_type ][ $stock_type ] ){
                            $used_types[ $ship_type ] = 1;
                            $items = array_merge( $items, $this->packs[ $ship_type ][ $stock_type ] );
                        }
                    }
                } 
                $userId = $this->_user_id;
                $isWholesaleUser = false;
                if($userId){
                    $user_meta = get_userdata( $userId );
                    $isWholesaleUser = in_array( 'wholesale_customer', $user_meta->roles );
                }
                if( $items ){
                    if( $need_check ){
                        $ship_via = $this->getShipVia( $used_types );
                    }
                   
                    if($isWholesaleUser){
                        if(empty($ship_via)){
                            $ship_via = [ "quote_required" ];
                        }
                    }
                    $cost = array_sum( wp_list_pluck( $items, 'line_subtotal' ) );
                    $pack_name = $ship_name[ $stock_type ][ 'caption' ] . '<span class="pack_subtitle">' . $ship_name[ $stock_type ][ 'description' ] . '</span>';

                    $force_free_shipping = false;
                    $coupons = WC()->cart->get_applied_coupons();
                    if( $coupons ){
                        foreach( $coupons as $coupon_code ){
                            $c = new WC_Coupon($coupon_code);
                            if( get_post_meta( $c->id, 'free_shipping', true) == 'yes' ){
                                $force_free_shipping = true;
                            }
                        }
                        if( $force_free_shipping ){
                            if($isWholesaleUser){
                                $ship_via = [ "quote_required" ];
                            }else{
                                $ship_via = [ "free_shipping" ];
                            }
                        }
                    }  
                    // ---
					/* Gaurav - 28 Aug 2023 */
					$weightCount = 0;
                    $finalamount = 0;
					foreach($items as $value){
						$product_id = $value['product_id'];
						$variation_id = $value['variation_id'];
						$qty = $value['quantity'];
						if($variation_id){
							$variationdata = wc_get_product($variation_id);
							$newwieght = $variationdata->get_weight();
                            if($newwieght==''){
                                $newwieght = 0;
                            }
							$finalweight = $newwieght*$qty;
							$weightCount = $weightCount+$finalweight;
                            if($isWholesaleUser){
                                $isprice = get_post_meta($variation_id, 'wholesale_customer_wholesale_price', true) ? get_post_meta($variation_id, 'wholesale_customer_wholesale_price', true) : $variationdata->get_regular_price();
                                
                            }
                            else{
                                $isprice = $variationdata->get_regular_price();
                            }
                            $newpricewithqty = $isprice*$qty;
                            $finalamount = $finalamount + $newpricewithqty;
						}
						else{
							$productdata = wc_get_product($product_id);
							$newwieght = $productdata->get_weight();
                            if($newwieght==''){
                                $newwieght = 0;
                            }
							$finalweight = $newwieght*$qty;
							$weightCount = $weightCount+$finalweight ;

                            if($isWholesaleUser){
                                $isprice = get_post_meta($product_id, 'wholesale_customer_wholesale_price', true) ? get_post_meta($product_id, 'wholesale_customer_wholesale_price', true) : $productdata->get_regular_price();
                            }
                            else{
                                $isprice = $productdata->get_regular_price();
                            }
                            $newpricewithqty = $isprice*$qty;
                            $finalamount = $finalamount + $newpricewithqty;
						}
					}
					$this->_destination['weight'] = $weightCount;
					
					/* The End */
                    $this->packages[] = array(
                        'contents'          => $items,
                        'contents_cost'     => $cost,
                        'name'              => $pack_name,
                        'ship_via'          => $ship_via,
                        'applied_coupons'   => WC()->cart->get_applied_coupons(),
                        'destination'       => $this->_destination,
                        'user'              => array(
                        'ID'                => $this->_user_id,
                        ),
                        'totalamount'=> $finalamount,
                    );

                }
            }

        }else{
            $items = [];
            $used_types = [];
            foreach( $ship_types as $ship_type ){
                if( isset( $this->packs[ $ship_type ][ 'def' ] ) and $this->packs[ $ship_type ][ 'def' ] ){
                    if( $this->packs[ $ship_type ][ 'def' ] ){
                        $items = array_merge( $items, $this->packs[ $ship_type ][ 'def' ] );
                        $used_types[ $ship_type ] = 1;
                    }
                }
            }
            // Check Current User
            $userId = $this->_user_id;
            $isWholesaleUser = false;
            if($userId){
                $user_meta = get_userdata( $userId );
                $isWholesaleUser = in_array( 'wholesale_customer', $user_meta->roles );
            }

            if ( $need_check ){
                $ship_via = $this->getShipVia( $used_types );
            }
           
            if($isWholesaleUser){
                if(empty($ship_via)){
                    $ship_via = [ "quote_required" ];
                }
            }

            if( $items ){

                $cost = array_sum( wp_list_pluck( $items, 'line_subtotal' ) );

                $pack_name = $ship_name[ 'all' ][ 'caption' ] . '<span class="pack_subtitle">' . $ship_name[ 'all' ][ 'description' ] . '</span>';

                $force_free_shipping = false;
                $coupons = WC()->cart->get_applied_coupons();
                if( $coupons ){
                    foreach( $coupons as $coupon_code ){
                        $c = new WC_Coupon($coupon_code);
                        if( get_post_meta( $c->id, 'free_shipping', true) == 'yes' ){
                            $force_free_shipping = true;
                        }
                    }
                    if( $force_free_shipping ){
                        if($isWholesaleUser){
                            $ship_via = [ "quote_required" ];
                        }else{
                            $ship_via = [ "free_shipping" ];
                        }
                    }
                }
                
				
				/* Gaurav - 28 Aug 2023 */
				$weightCount = 0;
                $finalamount = 0;
				foreach($items as $value){
					$product_id = $value['product_id'];
					$variation_id = $value['variation_id'];
					$qty = $value['quantity'];
					if($variation_id){
						$variationdata = wc_get_product($variation_id);
						$newwieght = $variationdata->get_weight();
                        if($newwieght==''){
                        	$newwieght = 0;
                        }

						$finalweight = $newwieght*$qty;
						$weightCount = $weightCount+$finalweight;

                        if($isWholesaleUser){
                            $isprice = get_post_meta($variation_id, 'wholesale_customer_wholesale_price', true) ? get_post_meta($variation_id, 'wholesale_customer_wholesale_price', true) : $variationdata->get_regular_price();
                        }
                        else{
                            $isprice = $variationdata->get_regular_price();
                        }
                        $newpricewithqty = $isprice*$qty;
                        $finalamount = $finalamount + $newpricewithqty;
					}
					else{
						$productdata = wc_get_product($product_id);
						$newwieght = $productdata->get_weight();
                        if($newwieght==''){
                        	$newwieght = 0;
                        }
						$finalweight = $newwieght*$qty;
						$weightCount = $weightCount+$finalweight;

                        if($isWholesaleUser){
							$isprice = get_post_meta($product_id, 'wholesale_customer_wholesale_price', true) ? get_post_meta($product_id, 'wholesale_customer_wholesale_price', true) : $productdata->get_regular_price();
                           
                        }
                        else{
                           $isprice = $productdata->get_regular_price();
                           
                        }
                        $newpricewithqty = $isprice * $qty;
                        $finalamount = $finalamount + $newpricewithqty;
					}
				}
				$this->_destination['weight'] = $weightCount;
				
				/* The End */
                $this->packages[] = array(
                    'contents'          => $items,
                    'contents_cost'     => $cost,
                    'name'              => $pack_name,
                    'ship_via'          => $ship_via,
                    'applied_coupons'   => WC()->cart->get_applied_coupons(),
                    'origin'=>'LA',
                    'destination'       => $this->_destination,
                    'user'              => array(
                    'ID'            => $this->_user_id,
                    ),
                    'totalamount'=> $finalamount,
                );
            }
        }
    }

    private function getCartContents(){
        $quantity_data = [];
        if ( $this->flag_separate ){
            $cartContent = [];
            $cartIds = [];
            foreach ( WC()->cart->get_cart() as $cart_item_key => $cart_item ) {
                $cartIds [] = $cart_item[ 'data' ]->get_id();
            }
            $quantity_data = $this->_BoldHelper->getVariantsQuantity( $cartIds );
        }

        foreach ( WC()->cart->get_cart() as $item_key => $cart_item ) {

            $shipping_class = $cart_item[ 'data' ]->shipping_class_id;
            $product_id = $cart_item[ 'product_id' ];

            if( !$shipping_class ){
                $shipping_class = $this->calculateShippingClass(
                    Array(
                        'weight'    => $cart_item[ 'data' ]->get_weight(),
                        'length'    => $cart_item[ 'data' ]->get_length(),
                        'width'     => $cart_item[ 'data' ]->get_width(),
                        'height'    => $cart_item[ 'data' ]->get_height(),
                    )
                );
                $_product = wc_get_product( $cart_item[ 'product_id' ]);
                $_product->set_shipping_class_id( $shipping_class );
                $_product->save();
            }

            $meta = get_post_meta( $product_id );

            //Is product "Pallete"
            $is_pallet = ( $meta[ 'bold_product_quote_pallet' ][ 0 ] == "Pallet" ? true : false );

            //Is product "Quote"
            $is_quote = ( $meta[ 'bold_product_quote_pallet' ][ 0 ] == "Quote" ? true : false );

            //Is product Proxy or Aragon
            $is_proxyaragon = ( ( $meta[ 'bold_product_manufacturer' ][ 0 ] == "Proxy" ) ? true : false );

            $is_aragon = ( ( $meta[ 'bold_product_manufacturer' ][ 0 ] == "Aragon" ) ? true : false );

            //Is product Composite-X
            $is_composite = ( ( $meta[ 'bold_product_manufacturer' ][ 0 ] == "Composite-X" ) ? true : false );

            //Is product Volx
            $is_Volx = ( ( $meta[ 'bold_product_manufacturer' ][ 0 ] == "Volx" ) ? true : false );

            //Is product Kastline
            $is_kastline = ( ( $meta[ 'bold_product_manufacturer' ][ 0 ] == "Kastline" ) ? true : false );

            //Is product kastline_pu
            $is_kastline_pu = ( ( $meta[ 'bold_product_manufacturer' ][ 0 ] == "Kastline-PU" ) ? true : false );


            //Pack "Quote"
            if( $is_quote ){
                $packs[ 'quote' ]['items'][ $item_key ] = $cart_item;
                continue;
            }

            //Pack "Pallet"
            if( $is_pallet ){
                $packs[ 'pallet' ]['items'][ $item_key ] = $cart_item;
                continue;
            }

            //Pack "Proxy or Aragon"
            if( $is_proxyaragon ){
                $packs[ 'proxyaragon' ]['items'][ $item_key ] = $cart_item;
                continue;
            }

            //Pack "Proxy or Aragon"
            if( $is_aragon ){
                $packs[ 'aragon' ]['items'][ $item_key ] = $cart_item;
                continue;
            }

            //Pack "Composite-X"
            if( $is_composite ){
                $packs[ 'composite' ]['items'][ $item_key ] = $cart_item;
                continue;
            }
            //Pack "volx"
            if( $is_Volx ){
                $packs[ 'volx' ]['items'][ $item_key ] = $cart_item;
                continue;
            }
            //Pack "is_kastline"
            if( $is_kastline ){
                $packs[ 'Kastline' ]['items'][ $item_key ] = $cart_item;
                continue;
            }

            //Pack "is_kastline_pu"
            if( $is_kastline_pu ){
                $packs[ 'Kastline-PU' ]['items'][ $item_key ] = $cart_item;
                continue;
            }

            $categories = get_the_terms ( $product_id, 'product_cat' );
            $is_retail = false;
            foreach( $categories as $category ){
                $category_id = $category->term_id;
                if( get_term_meta( $category_id,'bold_product_retail_items', true ) == "Yes" ){
                    $is_retail = true;
                }
            }
            if( $is_retail ){
                $packs[ 'retail' ]['items'][ $item_key ] = $cart_item;
                continue;
            }

            $packs[ 'noretail' ]['items'][ $item_key ] = $cart_item;
        }

        if( isset( $packs[ 'retail' ]['items'] ) ){
            $cost_retail    = array_sum( wp_list_pluck( $packs[ 'retail' ]['items'], 'line_total' ) );
        }else{
            $cost_retail = 0;
        }

        $cost_noretail  = WC()->cart->cart_contents_total - $cost_retail;

        //Separate by stock
        if( $this->flag_separate ){

            foreach( $packs as $key_pack=>$pack ){
                foreach( $pack[ 'items' ] as $key_cart => $cart_item ){

                    $cartProductId = $cart_item[ 'data' ]->get_id();
                    $quantity_left = $cart_item[ 'quantity' ];
                    $new_cart_item = $cart_item;
                    $quantity_item = $quantity_data[ $cartProductId ];

                    if( $quantity_item[ 'manage_stock' ] == "yes" ){
                        if( $quantity_item[ 'stock' ] ){
                            $quant = ( $quantity_left <= $quantity_item[ 'stock' ] ) ? $quantity_left : $quantity_item[ 'stock' ];
                            $new_cart_item[ 'quantity' ] = $quant;
                            $packs[ $key_pack ][ 'stock' ][ $key_cart ] = $new_cart_item;
                            $quantity_left -= $quant;
                        }
                        if( $quantity_left and $quantity_item[ 'inbound' ] ){
                            $quant = ( $quantity_left <= $quantity_item[ 'inbound' ] ) ? $quantity_left : $quantity_item[ 'inbound' ];
                            $new_cart_item[ 'quantity' ] = $quant;
                            $packs[ $key_pack ][ 'inbound' ][ $key_cart ] = $new_cart_item;
                            $quantity_left -= $quant;
                        }
                        if( $quantity_left ){
                            $new_cart_item[ 'quantity' ] = $quantity_left;
                            $packs[ $key_pack ][ 'mto' ][ $key_cart ] = $new_cart_item;
                        }
                    }else{
                        $packs[ $key_pack ][ 'mto' ][ $key_cart ] = $new_cart_item;
                    }
                }
            }
        }else{
            foreach( $packs as $key_pack => $pack ){
                $packs[ $key_pack ][ 'def' ] = $pack[ 'items' ];
            }
        }
        $this->packs = $packs;

        $bold_titles = array(
            "all"       => $this->shippingCaptions[ 'mainStock' ],
            "stock"     => $this->shippingCaptions[ 'stock' ],
            "inbound"   => $this->shippingCaptions[ 'inbound' ],
            "mto"       => $this->shippingCaptions[ 'mto' ]
        );
        $proxyaragon_titles = array(
            "all"       => $this->shippingCaptions[ 'proxyaragon' ],
            "stock"     => $this->shippingCaptions[ 'proxyaragon' ],
            "inbound"   => $this->shippingCaptions[ 'proxyaragon' ],
            "mto"       => $this->shippingCaptions[ 'proxyaragon' ]
        );
        $aragon_titles = array(
            "all"       => $this->shippingCaptions[ 'aragon' ],
            "stock"     => $this->shippingCaptions[ 'aragon' ],
            "inbound"   => $this->shippingCaptions[ 'aragon' ],
            "mto"       => $this->shippingCaptions[ 'aragon' ]
        );
		$quote_titless = array(
            "all"       => $this->shippingCaptions[ 'quote' ],
            "stock"     => $this->shippingCaptions[ 'quote' ],
            "inbound"   => $this->shippingCaptions[ 'quote' ],
            "mto"       => $this->shippingCaptions[ 'quote' ]
        );
        $composite_titles = array(
            "all"       => $this->shippingCaptions[ 'composite' ],
            "stock"     => $this->shippingCaptions[ 'composite' ],
            "inbound"   => $this->shippingCaptions[ 'composite' ],
            "mto"       => $this->shippingCaptions[ 'composite' ]
        );
        $quote_titles = array(
            "all"       => $this->shippingCaptions[ 'staticair' ],
            "stock"     => $this->shippingCaptions[ 'staticair' ],
            "inbound"   => $this->shippingCaptions[ 'staticair' ],
            "mto"       => $this->shippingCaptions[ 'staticair' ]
        );
        
        $Volx_titles = array(
            "all"       => $this->shippingCaptions[ 'volx' ],
            "stock"     => $this->shippingCaptions[ 'volx' ],
            "inbound"   => $this->shippingCaptions[ 'volx' ],
            "mto"       => $this->shippingCaptions[ 'volx' ]
        );
        

        $quote_titles_test = array(
            "all"       => array('caption'=>'Quote Required','description'=>'These items require a specialized quote. We will contact you directly with the shipping costs for these items.'),
            "stock"     => array('caption'=>'Quote Required','description'=>'These items require a specialized quote. We will contact you directly with the shipping costs for these items.'),
            "inbound"   => array('caption'=>'Quote Required','description'=>'These items require a specialized quote. We will contact you directly with the shipping costs for these items.'),
            "mto"       => array('caption'=>'Quote Required','description'=>'These items require a specialized quote. We will contact you directly with the shipping costs for these items.'),
        );        

        $kastline_pu_titles = array(
            "all"       => array('caption'=>'From Kastline-PU','description'=>'These items require a specialized Kastline-PU. We will contact you directly with the shipping costs for these items.'),
            "stock"     => array('caption'=>'From Kastline-PU','description'=>'These items require a specialized Kastline-PU. We will contact you directly with the shipping costs for these items.'),
            "inbound"   => array('caption'=>'From Kastline-PU','description'=>'These items require a specialized Kastline-PU. We will contact you directly with the shipping costs for these items.'),
            "mto"       => array('caption'=>'From Kastline-PU','description'=>'These items require a specialized Kastline-PU. We will contact you directly with the shipping costs for these items.'),
        );


        //$packages = [];
        if( !$this->_isWholesale ){

            if( $cost_noretail > $this->_limit_to_free_noretail ){
                //All products for free shipping
                $this->setPackage(
                    [ 'free_shipping' ],
                    [ 'retail', 'noretail', 'pallet', 'Kastline' ],
                    $bold_titles

                );
                $this->setPackage(
                    [ 'free_shipping' ],
                    [ 'proxyaragon' ],
                    $proxyaragon_titles
                );
                $this->setPackage(
                    [ 'free_shipping' ],
                    [ 'aragon' ],
                    $aragon_titles
                );
                $this->setPackage(
                    [ 'free_shipping' ],
                    [ 'composite' ],
                    $composite_titles
                );
                $this->setPackage(
                    [ 'free_shipping' ],
                    [ 'quote_titles' ],
                    $quote_titles
                );
                 //== volx ====
                 $this->setPackage(
                    [ 'free_shipping' ],
                    [ 'volx' ],
                    $Volx_titles
                );
                
				$this->setPackage(
					[ 'quote_required' ],
					[ 'quote' ],
					$quote_titles_test

           		 );

				$this->setPackage(
					[ 'free_shipping' ],
					[ 'Kastline-PU' ],
					$kastline_pu_titles

           		 );
            }else{
                //If Retail > 100
                if( $cost_retail > $this->_limit_to_free_retail ){
                    $this->setPackage(
                        [ 'free_shipping', 'quote_required' ],
                        [ 'retail' ],
                        $bold_titles
                    );
                
                    $this->setPackage(
                        true,  
                        [ 'noretail', 'pallet', 'Kastline' ],
                        $bold_titles
                    );

                    $this->setPackage(
                        [ 'proxy_shipping' ],
                        [ 'proxyaragon' ],
                        $proxyaragon_titles
                    );
                    $this->setPackage(
                        [ 'aragon_shipping' ],
                        [ 'aragon' ],
                        $aragon_titles
                    );
                    $this->setPackage(
                        [ 'flat_rate' ],
                        [ 'composite' ],
                        $composite_titles
                    );
                    $this->setPackage(
                        [ 'free_shipping' ],
                        [ 'quote_titles' ],
                        $quote_titles
                    );
                    
                    $this->setPackage(
                        [ 'free_shipping' ],
                        [ 'volx' ],
                        $Volx_titles
                    );


					$this->setPackage(
                        [ 'quote_required' ],
                        [ 'quote' ],
                        $quote_titles_test
                    );

                    $this->setPackage(
                        [ 'free_shipping' ],
                        [ 'Kastline-PU' ],
                        $kastline_pu_titles
    
                    );

                }else{
                    $this->setPackage(
                        true, 
                        [ 'retail', 'noretail', 'pallet', 'Kastline' ],
                        $bold_titles
                    
                    );
                    $this->setPackage(
                        [ 'proxy_shipping' ],
                        [ 'proxyaragon' ],
                        $proxyaragon_titles
                    );
                    $this->setPackage(
                        [ 'aragon_shipping' ],
                        [ 'aragon' ],
                        $aragon_titles
                    );
                    $this->setPackage(
                        [ 'flat_rate' ],
                        [ 'composite' ],
                        $composite_titles
                    );
                    $this->setPackage(
                        [ 'free_shipping' ],
                        [ 'quote_titles' ],
                        $quote_titles
                    );
                    
                    $this->setPackage(
                        [ 'volx_shipping' ],
                        [ 'volx' ],
                        $Volx_titles
                    );
                   
					
					$this->setPackage(
                        [ 'quote_required' ],
                        [ 'quote' ],
                        $quote_titles_test
                    
           		    );

					$this->setPackage(
                        [ 'kastline_pu' ],
                        [ 'Kastline-PU' ],
                        $kastline_pu_titles
    
                    );
                }
            }

        }else{
            $this->setPackage(
                true,
                [ 'retail', 'noretail', 'pallet', 'Kastline'],
                $bold_titles
            
            );
            $this->setPackage(
                [ 'proxy_shipping' ],
                [ 'proxyaragon' ],
                $proxyaragon_titles
            );
            $this->setPackage(
                [ 'aragon_shipping' ],
                [ 'aragon' ],
                $aragon_titles
            );
            $this->setPackage(
                [ 'flat_rate' ],
                [ 'composite' ],
                $composite_titles
            );
            $this->setPackage(
                [ 'free_shipping' ],
                [ 'quote_titles' ],
                $quote_titles
            
            );
            $this->setPackage(
                [ 'volx_shipping' ],
                [ 'volx' ],
                $Volx_titles
            );
			$this->setPackage(
                [ 'quote_required' ],
                [ 'quote' ],
                $quote_titles_test
           	);
            $this->setPackage(
                [ 'kastline_pu' ],
                [ 'Kastline-PU' ],
                $kastline_pu_titles
            );
        }
    }
    public function getPackages(){
        return $this->packages;
    }

    public function getMethods( $rates, $package ){
        foreach( $rates as $key=>$rate ){

            $method_name_arr = explode( ":", $key );
            $method_name = $method_name_arr[ 0 ];

            switch ( $method_name ){
                case 'local_pickup':        

                    $cost = 0;
                    foreach( $package[ 'contents' ] as $item ){
                        $cost += $item[ 'data' ]->get_price() * $item[ 'quantity' ];
                    }

                    $rate->cost = $cost * $this->_local_rate;
                    break;

                case 'flat_rate':       
                    $weight = 0;
                    foreach( $package[ 'contents' ] as $item ){
                        $weight += (float) $item[ 'data' ]->get_weight() * (float)$item[ 'quantity' ];
                    }
                    $rate->cost = $this->_flat_rate_fix + $this->_flat_rate_weight * $weight;

                break;

               
            }
        }

        return $rates;
    }


    private function setUserData(){
        $this->_user_id = get_current_user_id();

        if( $this->_user_id ){
            $user_meta = get_userdata( $this->_user_id );
            $this->_isWholesale = in_array( 'wholesale_customer', $user_meta->roles );
        }
    }

    private function getShippingClasses(){
        $sql = "SELECT wt.term_id, wt.name, wt.slug FROM wp_term_taxonomy wtt 
        LEFT JOIN wp_terms wt ON wtt.term_id = wt.term_id
        WHERE wtt.taxonomy = 'product_shipping_class'";
        $results = $this->_wpdb->get_results(
            $sql,
            ARRAY_A
        );
        $shipping_classes = [];
        foreach( $results as $row ){
            $shipping_classes[ $row[ 'name' ] ] = $row[ 'term_id' ];

        }
        $this->_shippingClasses = $shipping_classes;

    }
    private function calculateShippingClass( $data ){

        $total = 0;
        if( $data[ 'length' ] and $data[ 'width' ] and $data[ 'height' ] ){
            $total = $data[ 'length' ] * $data[ 'width' ] * $data[ 'height' ];
            $total = $total / 1728;
        }

        $density = 0;
        if( $total and $data[ 'weight' ] ){
            $density = $data[ 'weight' ] / $total;
        }

        if ( $density >= 50 )
            $estimatedclass = 50;
        else if ( $density >= 35 && $density < 50 )
            $estimatedclass = 55;
        else if ( $density >= 30 && $density < 35 )
            $estimatedclass = 60;
        else if ( $density >= 22.5 && $density < 30 )
            $estimatedclass = 65;
        else if ( $density >= 15 && $density < 22.5 )
            $estimatedclass = 70;
        else if ( $density >= 13.5 && $density < 15 )
            $estimatedclass = 77.5;
        else if ( $density >= 12 && $density < 13.5 )
            $estimatedclass = 85;
        else if ( $density >= 10.5 && $density < 12 )
            $estimatedclass = 92.5;
        else if ( $density >= 9 && $density < 10.5 )
            $estimatedclass = 100;
        else if ( $density >= 8 && $density < 9 )
            $estimatedclass = 110;
        else if ( $density >= 7 && $density < 8 )
            $estimatedclass = 125;
        else if ( $density >= 6 && $density < 7 )
            $estimatedclass = 150;
        else if ( $density >= 5 && $density < 6 )
            $estimatedclass = 175;
        else if ( $density >= 4 && $density < 5 )
            $estimatedclass = 200;
        else if ( $density >= 3 && $density < 4 )
            $estimatedclass = 250;
        else if ( $density >= 2 && $density < 3 )
            $estimatedclass = 300;
        else if ( $density >= 1 && $density < 2 )
            $estimatedclass = 400;
        else if ( $density < 1 )
            $estimatedclass = 500;

        $estimatedclass_str = number_format( $estimatedclass, 1, ".", "" );
        
        return $this->_shippingClasses[ $estimatedclass_str ];
    }
}

?>