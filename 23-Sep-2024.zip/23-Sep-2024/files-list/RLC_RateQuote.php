<?php

/**
 * Class RLC_rateQuote
 */
class RLC_RateQuote
{
    /**
     * @var string - endpoint URL
     */
    private $endpoints = array(
        'production' => 'http://api.rlcarriers.com/1.0.3/RateQuoteService.asmx',
        'sandbox' => 'http://api.rlcarriers.com/sandbox/RateQuoteService.asmx'
    );


    private $kt_overDimArray = array();

    private $debug = false;

    public $id;

    public $quote_number;

    public $net_charge;

    public $accessorials;

    public $service_days;

    public $method;

    public $weight;

    public $items;

    public $charges;

    public $is_hazmat;

    public function __construct($id = null)
    {

        if ( $id )
        {
            $quote = $this->getQuote($id);

            $charges_factory = new RLC_RateQuote_Charge();

            $this->id = $quote->id;

            $this->shipment_id = $quote->shipment_id;

            $this->quote_number = $quote->quote_number;

            $this->net_charge = $quote->net_charge;

            $this->accessorials = json_decode($quote->accessorials);

            $this->service_days = $quote->service_days;

            $this->method = $quote->method;

            $this->weight = $quote->weight;

            $this->items = json_decode($quote->items, true);

            $this->charges = $charges_factory->getChargesFromQuote($this->id);

            $this->is_hazmat = $this->is_hazmat();

        }

        $this->debug = wc_rlc_isDebugModeEnabled();

	    $this->endpoints  = apply_filters( 'woocommerce_shipping_rlc_rate_quote_endpoints', $this->endpoints );

        $this->endpoint = wc_rlc_is_sandbox_mode_enabled()? $this->endpoints['sandbox'] : $this->endpoints['production'];
        $this->soap_client_options = array('trace' => 1);
		
		
        //add_action( 'admin_notices',array( $this, 'wc_rlc_error_notice' ) );


        try {
            $this->soap_client = new SoapClient($this->endpoint . "?wsdl", $this->soap_client_options);
        } catch (Exception $e) {
			//$this->wc_rlc_error_notice('RLC API: Failed to initialize RLC API endpoint.');
			add_action( 'admin_notices', 'wc_rlc_error_connect_notice' );
            wc_rlc_logMessage($e->getMessage(), 'error');
			
        }

    }

    public function is_hazmat() {

        foreach ( $this->charges as $key => $charge ) {

            if ( $charge['type'] == 'HAZM' )
                return true;

        }

        return false;
    }

    /**
     * @param $shipment_id
     * @param $title
     * @param $quote_number
     * @param $net_charge
     * @param $method
     * @param $service_days
     * @param $weight
     * @param array $accessorials
     * @param array $items
     * @param null $origin_term_id
     * @return null|int
     */
    public function store($shipment_id, $title, $quote_number, $net_charge, $method, $service_days, $weight, $accessorials = array(), $items = array(), $origin_term_id = null )
    {
        global $wpdb;

        try {
            if ( intval($origin_term_id) )
            {
                //Get origin slug
	            $origin_meta_key = get_term($origin_term_id, 'origin')->slug . '_stock';
	            foreach ( $items as $item ) {
	                $id = intval($item['variation_id'])?$item['variation_id']:$item['product_id'];
		            $origin_meta = get_post_meta($id, $origin_meta_key, true);
		            $new_origin_stock = ((int)$origin_meta) - $item['quantity'];
		            if ($new_origin_stock < 0)
			            $new_origin_stock = 0;

		            update_post_meta($id, $origin_meta_key, $new_origin_stock);

	            }
                //update MO stock meta for origin
            }

            $data = array(
                'shipment_id' => $shipment_id,
                'origin_term_id' => $origin_term_id,
                'title' => $title,
                'items' => json_encode($items),
                'quote_number' => $quote_number,
                'net_charge' => wc_rlc_dollarsToDecimal($net_charge),
                'method' => $method,
                'service_days' => $service_days,
                'accessorials' => json_encode($accessorials),
                'weight'  => $weight,
                'created_at' => date('Y-m-d H:i:s')
            );

            $wpdb->insert($wpdb->prefix . 'woocommerce_shipping_rlc_quotes', $data);

            if ( $wpdb->last_error )
                wc_rlc_logMessage( 'Error inserting into woocommerce_shipping_rlc_quotes: ' . $wpdb->last_error );
        } catch (Exception $e) {
			
            wc_rlc_logMessage($e->getMessage(), 'error' );
        }


        return intval($wpdb->insert_id)?$wpdb->insert_id:null;
    }

    public function getSavedQuote($id)
    {
        $quote = false;

        try {

            global $wpdb;

            $result = $wpdb->get_results($wpdb->prepare(
                "
            SELECT * FROM " . $wpdb->prefix . "woocommerce_shipping_rlc_quotes
             WHERE id = %d
            ",
                $id
            ));

            if ($result[0]) $quote = $result[0];
        } catch (Exception $e) {
			
			wc_rlc_logMessage($e->getMessage(), 'error' );
           
        }

        return $quote;
    }

    public function getServiceLevels($request)
    {
        $data = $this->doRateQuoteCall($request);
        if (!is_null($data)) {
            return array(
                'levels'  => $data->Result->ServiceLevels->ServiceLevel,
                'charges' => $data->Result->Charges->Charge
            );
        } else { return array(); }
    }

    public function doRateQuoteCall($request)
    {
        //create $data variable will be used to return SOAP result
        $data = null;

        $clientOptions = array(
            'exceptions' => true,
            'trace' => 1,
            'cache_wsdl' => WSDL_CACHE_NONE,
            'features' => SOAP_SINGLE_ELEMENT_ARRAYS,
            'location' => $this->endpoint);



        //The creation of the client object. We pass it a reference to the WSDL.
        $requestXML =
        '<GetRateQuote xmlns="http://www.rlcarriers.com/">
            <APIKey>' . $request['apikey'] . '</APIKey>
            <request>
                <CustomerData>' . $request['customerData'] . '</CustomerData>
                <QuoteType>' . $request['type'] . '</QuoteType>
                <CODAmount>' . $request['cod'] . '</CODAmount>
                <Origin>
                        <City>' . $request['originCity'] . '</City>
                        <StateOrProvince>' . $request['originState'] . '</StateOrProvince>
                        <ZipOrPostalCode>' . $request['originZip'] . '</ZipOrPostalCode>
                        <CountryCode>' . $request['originCountry'] . '</CountryCode>
                </Origin>
                <Destination>
                        <City>' . $request['destinationCity'] . '</City>
                        <StateOrProvince>' . $request['destinationState'] . '</StateOrProvince>
                        <ZipOrPostalCode>' . $request['destinationZip'] . '</ZipOrPostalCode>
                        <CountryCode>' . $request['destinationCountry'] . '</CountryCode>
                </Destination>
                <Items>';

        if (array_key_exists('items', $request) && sizeof($request['items'])) {
            $weight_unit = get_option('woocommerce_weight_unit');
            $dimension_unit = get_option('woocommerce_dimension_unit');

            foreach ($request['items'] as $key => $item) {

                if ( $item['is_hazmat'] ) $this->is_hazmat = true;
                
                // convert weight to pounds
                $itemWeightPounds = $item['weight'];
                switch ($weight_unit) {
                    case "oz":
                        $itemWeightPounds = floatval($item['weight']) * 0.0625;
                        break;
                    case "kg":
                        $itemWeightPounds = floatval($item['weight']) * 2.20462;
                        break;
                    case "g":
                        $itemWeightPounds = floatval($item['weight']) * 0.00220462;
                        break;
                    default:
                        $itemWeightPounds = $item['weight'];
                }
                // convert dimensions to inches
                $itemWidthInches = $item['width'];
                $itemLengthInches = $item['length'];
                $itemHeightInches = $item['height'];
                switch($dimension_unit){
                    case 'm':
                        $itemWidthInches = floatval($item['width']) * 39.3701;
                        $itemLengthInches = floatval($item['length']) * 39.3701;
                        $itemHeightInches = floatval($item['height']) * 39.3701;
                        break;
                    case 'cm':
                        $itemWidthInches = floatval($item['width']) * 0.393701;
                        $itemLengthInches = floatval($item['length']) * 0.393701;
                        $itemHeightInches = floatval($item['height']) * 0.393701;
                        break;
                    case 'mm':
                        $itemWidthInches = floatval($item['width']) * 0.0393701;
                        $itemLengthInches = floatval($item['length']) * 0.0393701;
                        $itemHeightInches = floatval($item['height']) * 0.0393701;
                        break;
                    case 'yd':
                        $itemWidthInches = floatval($item['width']) * 36;
                        $itemLengthInches = floatval($item['length']) * 36;
                        $itemHeightInches = floatval($item['height']) * 36;
                        break;
                    default:
                        $itemWidthInches = $item['width'];
                        $itemLengthInches = $item['length'];
                        $itemHeightInches = $item['height'];
                }
                if ($itemWidthInches > 96 || $itemLengthInches > 96 ) {
                    $maxInches = max($itemWidthInches,$itemLengthInches);
                    if (in_array($maxInches,$this->$kt_overDimArray))
                        $this->$kt_overDimArray[$maxInches] = $item['quantity'];
                        else
                            $this->$kt_overDimArray[$maxInches] = $item['quantity'];
                }
                        
                $requestXML .= '
                <Item>
                    <Class>' . $item['class'] . '</Class>
                    <Weight>' . floatval($item['weight']) . '</Weight>';
                $requestXML .= intval($itemWidthInches)?'
                    <Width>'.$itemWidthInches.'</Width>':'';
                $requestXML .= intval($itemHeightInches)?'
                    <Height>'.$itemHeightInches.'</Height>':'';
                $requestXML .= intval($itemLengthInches)?'
                    <Length>'.$itemLengthInches.'</Length>':'';
                $requestXML .= '
                </Item>';
                //Old Code
                // $requestXML .= '
                // <Item>
                //     <Class>' . $item['class'] . '</Class>
                //     <Weight>' . floatval($item['weight'])*$item['quantity'] . '</Weight>';
                // $requestXML .= intval($itemWidthInches)?'
                //     <Width>'.$itemWidthInches.'</Width>':'';
                // $requestXML .= intval($itemHeightInches)?'
                //     <Height>'.$itemHeightInches.'</Height>':'';
                // $requestXML .= intval($itemLengthInches)?'
                //     <Length>'.$itemLengthInches.'</Length>':'';
                // $requestXML .= '
                // </Item>';
            }
        }
        
        
        $requestXML .= '
            </Items>
            <DeclaredValue>' . $request['value'] . '</DeclaredValue>';

	    $requestXML .= '<Accessorials>';
	    if ($this->$kt_overDimArray){
	       $requestXML .= '<RQAccessorial>OverDimension</RQAccessorial>';
	    }
        if ( $this->is_hazmat || sizeof($request['accessorials']) ){

            if ( $this->is_hazmat ) {
                $requestXML .= '<RQAccessorial>Hazmat</RQAccessorial>';
            }
            if ( ! empty( $request['accessorials'] ) ) {
                foreach ( $request['accessorials'] as $accessorial ) {
                    $requestXML .= '<RQAccessorial>' . $accessorial . '</RQAccessorial>';
                }
            }
            


        }

	    $requestXML .= '</Accessorials>';

	    
	    if ( $this->$kt_overDimArray != 0 ) {
	        $requestXML .= '<OverDimensionList>';
	   
	    foreach ($this->$kt_overDimArray as $key => $numItems){
	            $requestXML .= '<OverDimension>';
	            $requestXML .= '<Pieces>' . $numItems . '</Pieces>';
	            $requestXML .= '<Inches>' . $key . '</Inches>';
	            $requestXML .= '</OverDimension>';
	        }
	        
	        $requestXML .= '</OverDimensionList>';
	    }


        if (array_key_exists('pallets', $request) && sizeof($request['pallets']) ) {
            $requestXML .= '<Pallets>';
            foreach ($request['pallets'] as $pallet) {
                $requestXML .= '<Pallet>' .
                    '<Code>' . $pallet['Code'] . '</Code>' .
                    '<Weight>' . $pallet['Weight'] . '</Weight>' .
                    '<Quantity>' . $pallet['Quantity'] . '</Quantity>' .
                '</Pallet>';
            }
            $requestXML .= '</Pallets>';
        }

        $requestXML .= '</request>';
        $requestXML .= '</GetRateQuote>';


        if (wc_rlc_isDebugModeEnabled()) {
            $xml = new SimpleXMLElement( $requestXML );
            wc_add_notice( 'R+L REQUEST: <pre>' . htmlentities( $xml->asXML() ) . '</pre>' );
            wc_rlc_logMessage( 'R+L REQUEST: ' . $xml->asXML());
        }

        try {
            $requestObj = new SoapVar($requestXML, XSD_ANYXML);
            $client = new SoapClient($this->endpoint . "?wsdl", $clientOptions);

            //Run the Command / Retrieve the result.
            $result = $client->GetRateQuote($requestObj);
			//echo '<pre>'; print_r($result); echo '</pre>';
            //service_id is a counter that also identifies which service level an accrued total is for, since services are processed in the same order on each iteration of this loop
            $service_id = 0;

            //newnetTotal is an array containing accrued totals for each servicelevel.
            //$service_id is the index of this array representing the servicelevel currently being calculated in the foreach loop
            $newnetTotal = array(0, 0, 0, 0);

            if ($result->GetRateQuoteResult->WasSuccess) {

                $service_levels = $result->GetRateQuoteResult->Result->ServiceLevels->ServiceLevel;;

                //this loop runs for each unique product and accrues the total netcharge for each service level in the $newnetTotal array
                foreach ($service_levels as $service) {
                    if (is_object($service)) {
                        $net = str_replace('$', '', $service->NetCharge); //remove dollar sign from net charge string that is returned by RateQuote API and store in new $net string
                        $net = str_replace(',', '', $net); //remove comma(s)

                        //multiply net cost per pallet by quantity and save in $newnet float
                        $newnet = (floatval($net));
                        $newnetTotal[$service_id] += $newnet;

                        //convert newnetTotal to to string with dollar sign
                        $totalNetCharge = "$" . strval($newnetTotal[$service_id]);

                        //Replace unit rate returned from RateQuote API with totalNetCharge
                        $service->NetCharge = $totalNetCharge;
                        $service_id += 1;
                    }
                }

                //Pull the data out into a variable
                $data = $result->GetRateQuoteResult;
            } elseif ($this->debug) {
                // Because of course a class object named string is actually an array
                foreach($result->GetRateQuoteResult->Messages->string as $message) {
					//$this->wc_rlc_error_notice('RLC API: Failed to retrieve R+L Carriers rate quote. ');
					add_action( 'admin_notices', 'wc_rlc_error_rq_notice' );					
                    wc_rlc_logMessage( 'RLC API: Failed to retrieve rate quote' . $message, 'error');
	                wc_add_notice('API Error Message: ' . $message);
                }
            }
        } catch (Exception $e) {
			
            wc_add_notice('Failed to retrieve R+L Carriers rate quote. Please contact the site administrator.');
            wc_rlc_logMessage($e->getMessage(), 'error');
        }

        return $data;
    }

    public function logSOAPresult($outcome, $req, $response, $messages)
    {
        //$outcome is either "FAIL" or "SUCCESS" passed as a literal
        //XML request is also passed and logged, regardless of success or failure

        $logfilename = 'rlc_SOAP_log.txt';
        $datetime = new DateTime();
        $timedatestamp = $datetime->format('Y-m-d H:i:s');
        //create string to write to log
        $log_entry = "------------------------------------------------------------------------------------------------------\n";
        if (is_array($messages) > 0) {
            foreach ($messages as $message) {
                $log_entry .= $outcome . " -- " . $timedatestamp . "\n -Request: " . $req . " -Response: " . $response . " -Message: " . $message . " \n";
            }
        } else {
            $log_entry .= $outcome . " -- " . $timedatestamp . "\n -Request: " . $req . " -Response: " . $response . " \n";
        }
        $log_entry .= "------------------------------------------------------------------------------------------------------\n\n";
        //write string to log file
        file_put_contents($logfilename, $log_entry, FILE_APPEND);

    }

    public function getRateQuote($request)
    {
        $data = $this->doRateQuoteCall($request);
        return $data;
    }

    public function getPalletTypeByPoints($request)
    {
        $palletTypeByPointsRequest = array(
            'APIKey' => $request['apikey'],
            'MyRLCID' => '',
            'originCity' => $request['originCity'],
            'originZip' => $request['originZip'],
            'destinationCity' => $request['destinationCity'],
            'destinationZip' => $request['destinationZip'],
        );


        $clientOptions = array(
            'trace' => 1,
        );


        try {
            $client = new SoapClient($this->endpoint . "?wsdl", $clientOptions);

            //Run the Command / Retrieve the result.
            $result = $client->GetPalletTypeByPoints($palletTypeByPointsRequest);

        } catch (Exception $e) {
			
			 wc_rlc_logMessage($e->getMessage(), 'error');
           
        }


        return ($result->GetPalletTypeByPoints->WasSuccess) ? $result->GetPalletTypesByPoints->PalletTypes : array();
    }

    public function getPalletTypes($request)
    {

        $getPalletTypes = array(
            'APIKey' => $request['apikey'],
        );


        $clientOptions = array(
            'trace' => 1,
        );


        try {
            $client = new SoapClient($this->endpoint . "?wsdl", $clientOptions);

            //Run the Command / Retrieve the result.
            $result = $client->GetPalletTypes($getPalletTypes);

        } catch (Exception $e) {
			
            wc_rlc_logMessage($e->getMessage(), 'warning');
        }


        return ($result->GetPalletTypesResult->WasSuccess) ? $result->GetPalletTypesResult->Result->PalletType : array();

    }

    public function getQuote($id){
        global $wpdb;

        $quote = $wpdb->get_results( $wpdb->prepare(
            "
                   SELECT * FROM " . $wpdb->prefix . "woocommerce_shipping_rlc_quotes
                   WHERE `id` = %d
                   ORDER BY `id` DESC
                   ",
            $id
        ));

        if (! sizeof($quote) )
            return null;

        $quote = $quote[0];

        return $quote;
    }



    public function getNetCharge($charges = null)
    {
        if (is_null($charges))
            $charges = $this->charges;

        return strlen($charges[sizeof($charges)-1]['Amount'])?$charges[sizeof($charges)-1]['Amount']:'&mdash;';
    }

    public function deleteQuote($id = 0){
        global $wpdb;

        if ( !intval($id) )
            $id = $this->id;

        return $wpdb->query('DELETE FROM `' . $wpdb->prefix . 'woocommerce_shipping_rlc_quotes` WHERE `id` = ' . $id);
    }

    public function getShipmentFromQuote($quote_id = null)
    {
        global $wpdb;

        if (is_null($quote_id) )
            $quote_id = $this->id;

        $wpdb->query('SELECT `id` FROM `' . $wpdb->prefix . 'woocommerce_shipping_rlc_shipments` WHERE `order_id` = ' . $this->getOrderFromQuote($quote_id) . ' AND ' . '`quotes` LIKE "%'.$quote_id.'%"');

        return sizeof($wpdb->last_result)?$wpdb->last_result[0]->id:0;
    }

    public function getOrderFromQuote($quote_id)
    {
        global $wpdb;

        $wpdb->query('SELECT `order_id` FROM `' . $wpdb->prefix . 'woocommerce_shipping_rlc_quotes` WHERE `id` = ' . $quote_id);

        return sizeof($wpdb->last_result)?$wpdb->last_result[0]->order_id:0;
    }

}