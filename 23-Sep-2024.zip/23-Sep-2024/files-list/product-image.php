<?php
/**
 * Single Product Image
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/single-product/product-image.php.
 *
 * HOWEVER, on occasion WooCommerce will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see     https://docs.woocommerce.com/document/template-structure/
 * @package WooCommerce\Templates
 * @version 7.8.0
 */

 defined( 'ABSPATH' ) || exit;

 // Note: `wc_get_gallery_image_html` was added in WC 3.3.2 and did not exist prior. This check protects against theme overrides being used on older versions of WC.
 if ( ! function_exists( 'wc_get_gallery_image_html' ) ) {
 	return;
 }

 global $product;
 global $wpdb;

 //echo '<img src="https://bold.test-domain-wp.com/wp-content/uploads/2021/11/1-grey.jpg" />';
 //echo '<img src="https://bold.test-domain-wp.com/wp-content/uploads/2021/11/1-grey.jpg" />';



 $columns           = apply_filters( 'woocommerce_product_thumbnails_columns', 4 );
 $post_thumbnail_id = $product->get_image_id();
 $wrapper_classes   = apply_filters(
 	'woocommerce_single_product_image_gallery_classes',
 	array(
 		'woocommerce-product-gallery',
 		'woocommerce-product-gallery--' . ( $post_thumbnail_id ? 'with-images' : 'without-images' ),
 		'woocommerce-product-gallery--columns-' . absint( $columns ),
 		'images',
 	)
 );

$user_id = get_current_user_id();
$isWholesaleUser = false;
if($user_id){
    $user_meta = get_userdata( $user_id );
    $isWholesaleUser = in_array( 'wholesale_customer', $user_meta->roles );
}

// Mtech Check product stock--
$variant_ids = array();
if ($product && $product->is_type('variable')) {
    $variations = $product->get_children();
    foreach ($variations as $variation_id) {
        $variant_ids[] = $variation_id;
    }
}
if($variant_ids){
    $totalstock = 0;
    $variants_str = implode( ",", $variant_ids );
    $sql_inbound = "SELECT wi.product_id, wm.stock_quantity as inbound_stock FROM wp_atum_inventories wi
                        LEFT JOIN wp_atum_inventory_meta wm ON wi.id = wm.inventory_id
                        WHERE wi.product_id IN (" . $variants_str . ") and wi.priority = 1";

        $meta_values = $wpdb->get_results(
            $sql_inbound, ARRAY_A 
        );  
        foreach( $meta_values as $itm ){
            $totalstock += $itm[ 'inbound_stock' ] * 1;
        }

        $meta_values = $wpdb->get_results(
            "select product_id, stock_quantity from wp_wc_product_meta_lookup where product_id in (" . $variants_str . ")", 
            ARRAY_A
        );
        foreach( $meta_values as $itm ){
            $totalstock += $itm[ 'stock_quantity' ] * 1;
        }
    
}
/* End  */

 // Badges---
 $attachment_ids = $product->get_gallery_attachment_ids();

if($post_thumbnail_id){
    $productID = $product->get_id();
    $new_tag = '';
    $full_tag = '';
    $badgeshtml = '';
    $terms = wp_get_post_terms($productID, 'product_tag' );
    $termsArray = array();
    if ( count( $terms ) > 0 ) {
        foreach( $terms as $term ) {
            $term_name = $term->name;
            $termsArray[] = $term_name;
        }
    }else{
        
    }

    $ExistingCat = ['holds', 'macros', 'volumes', 'accessories'];
    $terms = wp_get_post_terms( $productID, 'product_cat' );
    foreach ( $terms as $term ) {
        $categories[] = $term->slug;
    }


    if($termsArray){
        if(in_array('New', $termsArray)){
            $new_tag = '<span class="acoplw-badge-icon acoplw-bsone acoplwRightAlign acoplwPosBtm acoplw-full-line-10-off-copy-custom" style="opacity:1;width:94px;font-size:14px;line-height:30px;font-weight: 600;height:30px;transform:rotateX(0deg) rotateY(0deg) rotateZ(0deg);border-radius: 3px 3px 3px 3px;bottom:0px;top:auto;background:rgba(253, 207, 0, 1);"><span class="acoplw-blockText" style="color:rgba(0, 0, 0, 1);">New !</span></span>';
        }
        if(in_array('Full', $termsArray)){
            $full_tag = '<span class="acoplw-badge-icon acoplw-bsfive acoplwLeftAlign acoplwPosTop acoplw-full-line-custom " style="opacity:1;width:125px;font-size:12px;line-height:23px;font-weight: 600;transform:rotateX(0deg) rotateY(0deg) rotateZ(0deg);top:0px;bottom:auto;height:125px;"><span class="acoplw-blockOne" style=""></span><span class="acoplw-blockTwo"></span><span class="acoplw-blockText" style="color:rgba(0, 0, 0, 1);background:rgba(253, 207, 0, 1);width:176.25px;top:32.5px;left:-38.75px;right:auto;">Full Line</span></span>';
        }
        if(in_array('Full2.5', $termsArray)){
            $full_tag = '<span class="acoplw-badge-icon acoplw-bsfive acoplwLeftAlign acoplwPosTop acoplw-full-line-custom " style="opacity:1;width:125px;font-size:12px;line-height:23px;font-weight: 600;transform:rotateX(0deg) rotateY(0deg) rotateZ(0deg);top:0px;bottom:auto;height:125px;"><span class="acoplw-blockOne" style=""></span><span class="acoplw-blockTwo"></span><span class="acoplw-blockText" style="color:rgba(0, 0, 0, 1);background:rgba(253, 207, 0, 1);width:176.25px;top:32.5px;left:-38.75px;right:auto;">Full Line 2.5% Off</span></span>';
        }
    }

     // Discounted Badges
    $sale_discount_item = get_post_meta($productID, 'sale_discounted_item', true);
    $discount_cost = 0;
    if($isWholesaleUser){
        $discount_cost = get_post_meta($productID, 'discount_wholesale_cost', true);
    }else{
        $discount_cost = get_post_meta($productID, 'discount_retail_cost', true);

    }
    if($sale_discount_item == 'Discounted'){
        
        $new_tag = '<span class="acoplw-badge-icon acoplw-bsthree acoplwRightAlign acoplwPosTop acoplw-woo-badge-2-custom" style="opacity:1;width:155px;font-size:px;line-height:px;font-weight: 400;transform:rotateX(0deg) rotateY(0deg) rotateZ(0deg);border-radius: 3px 3px 3px 3px;top:0px;bottom:auto;background:rgba(208, 2, 27, 1); z-index: 2;"><span class="acoplw-blockText" style="color:rgba(255, 255, 255, 1);">'.$discount_cost.'% discount</span></span>';
        $full_tag = '';
    }else{
        if($sale_discount_item == 'Sale'){
            $new_tag = '<span class="acoplw-badge-icon acoplw-bsfour acoplwRightAlign acoplwPosTop acoplw-woo-badge-custom" style="opacity:1;width:155px;font-size:px;line-height:32px;font-weight: 400;transform:rotateX(0deg) rotateY(0deg) rotateZ(0deg);border-radius: 0px 3px 3px 0px;top:0px;bottom:auto;background:rgba(208, 2, 27, 1); z-index: 2;"><span class="acoplw-blockText" style="color:rgba(255, 255, 255, 1);">Stock SALE '.$discount_cost.'% off!</span></span>';
            $full_tag = '';
        }
    }

    // Stock Sale Option

    $stock_sale_current = get_post_meta( $productID, 'stock_sale_current', true ) === 'on';
    $stock_sale_future = get_post_meta( $productID, 'stock_sale_future', true ) === 'on';
    $stock_sale_mto = get_post_meta( $productID, 'stock_sale_mto', true ) === 'on'; 
    $discount_cost = '';
    if ( $stock_sale_current || $stock_sale_future || $stock_sale_mto ) {
       
        if (in_array('accessories', $categories)) {
            if($sale_discount_item == 'Discounted'){
                $new_tag = '<span class="acoplw-badge-icon acoplw-bsfour acoplwRightAlign acoplwPosTop acoplw-j-custom" style="opacity:1;width:155px;font-size:px;line-height:px;font-weight: 400;transform:rotateX(0deg) rotateY(0deg) rotateZ(0deg);border-radius: 0px 3px 3px 0px;top:0px;bottom:auto;background:rgba(208, 2, 27, 1); z-index: 2;"><span class="acoplw-blockText stock-sale" style="color:rgba(255, 255, 255, 1);">'.$discount_cost.'% discount</span></span>';
                $full_tag = '';
            }else{
                if($sale_discount_item == 'Sale'){
                    $new_tag = '<span class="acoplw-badge-icon acoplw-bsfour acoplwRightAlign acoplwPosTop acoplw-j-custom" style="opacity:1;width:155px;font-size:px;line-height:px;font-weight: 400;transform:rotateX(0deg) rotateY(0deg) rotateZ(0deg);border-radius: 0px 3px 3px 0px;top:0px;bottom:auto;background:rgba(208, 2, 27, 1); z-index: 2;"><span class="acoplw-blockText stock-sale" style="color:rgba(255, 255, 255, 1);">Stock SALE '.$discount_cost.'% off!</span></span>';
                    $full_tag = '';
                }
           }
           
            
        }else{
            if($totalstock > 0){
                if($sale_discount_item == 'Discounted'){
                    $new_tag = '<span class="acoplw-badge-icon acoplw-bsfour acoplwRightAlign acoplwPosTop acoplw-j-custom" style="opacity:1;width:155px;font-size:px;line-height:px;font-weight: 400;transform:rotateX(0deg) rotateY(0deg) rotateZ(0deg);border-radius: 0px 3px 3px 0px;top:0px;bottom:auto;background:rgba(208, 2, 27, 1); z-index: 2;"><span class="acoplw-blockText stock-sale" style="color:rgba(255, 255, 255, 1);">'.$discount_cost.'% discount</span></span>';
                    $full_tag = '';
                }else{
                    if($sale_discount_item == 'Sale'){
                        $new_tag = '<span class="acoplw-badge-icon acoplw-bsfour acoplwRightAlign acoplwPosTop acoplw-j-custom" style="opacity:1;width:155px;font-size:px;line-height:px;font-weight: 400;transform:rotateX(0deg) rotateY(0deg) rotateZ(0deg);border-radius: 0px 3px 3px 0px;top:0px;bottom:auto;background:rgba(208, 2, 27, 1); z-index: 2;"><span class="acoplw-blockText stock-sale" style="color:rgba(255, 255, 255, 1);">Stock SALE '.$discount_cost.'% off!</span></span>';
                        $full_tag = '';
                    }
               }
            }else{
                $new_tag = '';
                $full_tag = '';
            }

        }

    }

    if($new_tag ||  $full_tag ){
        $badgeshtml = '<span class="custombadges">'.$new_tag.''.$full_tag.'</span>';
    }

    
}


 ?>

 <?php

     $view = get_post_meta( get_the_ID(), 'bold_product_view_gallery', true );

     $featured_image = wp_get_attachment_image_src( get_post_thumbnail_id( get_the_ID() ), 'full' );

     if( $view ){

         $view_count = count($view);
         $count = 1;

         if ( $post_thumbnail_id ) {
             $collapse = 'collapse';
         }else{
             $collapse = '';
         }
         foreach( $view as $image ){
             echo '<img src="'.$image.'" style="position:absolute;opacity:0;"/>';
         }

         echo '<img src="https://img.youtube.com/vi/JzZc0GJ5vkc/0.jpg" style="position:absolute;opacity:0;"/>';

         //echo '<iframe width="900" height="600" src="https://www.youtube.com/embed/JzZc0GJ5vkc" title="Bouldering. BLOCS Climbing Gym Edmonton, AB" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>';

         //echo '<img class="rotate-icon collapse pull-right" src="' . wp_get_attachment_image_src(41114,'full')[0] . '" alt="rotate-icon" />';
         echo '<div class="wrapper_threesixty"><div id="threesixty" href="#" data-images="';

           foreach( $view as $image ){

               if( $count < $view_count ){
                   echo $image . ', ';
               }elseif( $count == $view_count ){
                   echo $image;
               }

               $count++;

           }

         echo '"></div>
             <div class="threesixty_arrows">
                 <div class="threesixty_arrow_caption">Drag<br/>to spin</div>
                 <div class="threesixty_arrow"></div>
             </div>
         </div>';
     }

 ?>

 <div class="<?php echo esc_attr( implode( ' ', array_map( 'sanitize_html_class', $wrapper_classes ) ) ); ?>" data-columns="<?php echo esc_attr( $columns ); ?>" style="opacity: 0; transition: opacity .25s ease-in-out;">
    <?php echo $badgeshtml; ?>
    <figure class="woocommerce-product-gallery__wrapper">
    
    
 <?php

if ( $post_thumbnail_id ) {
 			$html = wc_get_gallery_image_html( $post_thumbnail_id, true );
        } else {
            $html  = '<div class="woocommerce-product-gallery__image--placeholder">';
            $html .= sprintf( '<img src="%s" alt="%s" class="wp-post-image" />', esc_url( wc_placeholder_img_src( 'woocommerce_single' ) ), esc_html__( 'Awaiting product image', 'woocommerce' ) );
            //$html .= '<img src="https://img.youtube.com/vi/JzZc0GJ5vkc/0.jpg" style="position:absolute;opacity:0;"/>';
 			$html .= '</div>';
 		}

 		echo apply_filters( 'woocommerce_single_product_image_thumbnail_html', $html, $post_thumbnail_id ); // phpcs:disable WordPress.XSS.EscapeOutput.OutputNotEscaped

 		do_action( 'woocommerce_product_thumbnails' );

 		?>
 	</figure>



 </div>

 <?php if( $view ){ ?>

   <button class="text-under-view" style="background:#fccf07;">Click for 360 degree views</button>
   <span class="text-under-view-gallery collapse">Click for gallery views</span>
    
 <?php

 } 
 ?>
 <script>
    jQuery(document).ready(function(){
        let badgeshtml = jQuery('.custombadges').html();
        console.log(badgeshtml);
        jQuery('.custombadges').html('');
        setTimeout(function() {
            jQuery( '.woocommerce-product-gallery .flex-viewport' ).prepend( badgeshtml );
        }, 1000);
       // jQuery( '.single-product .flex-viewport' ).append( badgeshtml );
    });
 </script>
 <style>
    .woocommerce-product-gallery .acoplw-full-line-custom{
        z-index: 99 !important;
    }
 </style>
