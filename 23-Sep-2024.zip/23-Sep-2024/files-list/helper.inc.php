<?php

/**
 * Help functions for products
 */
class BoldHelper
{
    private $_wpdb;
    private $_cats          = [];
    private $_all_brends;
    private $_all_colors    = [];
    public $defaultImage    = '';
    public $site_url        = '';
    private $_root          = '';
    public $isWholesaleUser = false;
    private $_captions      = [];
    private $_shipping_info = [];
    private $_isBranded     = false;
    private $_WOOCS;



    function __construct()
    {
        global $wpdb;
        global $WOOCS;

        $this->_wpdb    = $wpdb;
        $this->_WOOCS   = $WOOCS;

        $this->_all_brends      = $this->getAllBrands();
        $this->_all_colors      = $this->getAllColors();
        $this->_captions        = $this->getColorCaptions();
        $this->_shipping_info   = $this->getShippingInfoText();

        $this->defaultImage     = wp_get_attachment_url(34169);
        $this->site_url         = get_site_url();
        $this->_root            = $_SERVER['DOCUMENT_ROOT'];
        $this->getUserRoles();
    }

    public function incraseViews($product_id, $count_views)
    {
        update_post_meta($product_id, 'post_views', ($count_views + 1));
    }

    public function getLastDateInbound($items)
    {

        $date = '';

        if ($items) {

            foreach ($items as $key => $item) {

                $product_id = $item['data']->get_id();
                $count_left = $item['quantity'];


                $sql = "SELECT waoim.meta_value as product_id, sum(waoiq.meta_value) as quantity, DATE_FORMAT(wpm.meta_value,'%Y-%m-%d') as date FROM wp_atum_order_itemmeta waoim
                INNER JOIN wp_atum_order_itemmeta waoiq ON ( waoim.order_item_id = waoiq.order_item_id and waoiq.meta_key = '_qty')
                LEFT JOIN wp_atum_order_items waois ON waoim.order_item_id = waois.order_item_id
                LEFT JOIN wp_posts wp ON wp.ID = waois.order_id
                LEFT JOIN wp_postmeta wpm on ( wpm.post_id = wp.ID and wpm.meta_key='_delivery_date')
                WHERE waoim.meta_key='_variation_id' and waoim.meta_value = '" . $product_id . "'
                and wp.post_statdus = 'atum_new'
                group by product_id, date ORDER BY date ASC";

                $results = $this->_wpdb->get_results(
                    $sql,
                    ARRAY_A
                );
                $date_item = '';
                foreach ($results as $row) {
                    if ($count_left > 0) {
                        $count_left -= $row['quantity'];
                        $date_item = $row['date'];
                    }
                }
                if ($date_item > $date) {
                    $date = $date_item;
                }
            }
        }
        return $date;
        /**/
    }

    public function getUserRoles()
    {
        $user_id = get_current_user_id();
        if ($user_id) {
            $user_meta = get_userdata($user_id);
            $this->isWholesaleUser = in_array('wholesale_customer', $user_meta->roles);
        }
    }

    public function getShippingInfoText()
    {
        $shipping_info = [];
        $sql = "SELECT wtm.term_id, wtm.meta_value FROM wp_termmeta wtm
        INNER JOIN wp_terms wt  ON ( wt.term_id=wtm.term_id and wtm.meta_key='bold_shipping_info')";
        $results = $this->_wpdb->get_results(
            $sql,
            ARRAY_A
        );

        foreach ($results as $row) {
            //echo $row['meta_value'];
            $shipping_info[$row['term_id']] = $row['meta_value'];
        }
        return $shipping_info;
    }

    public function getColorCaptions()
    {
        $captions = [];
        $sql = "SELECT wtm.term_id, wtm.meta_value FROM wp_termmeta wtm
        INNER JOIN wp_terms wt  ON ( wt.term_id=wtm.term_id and wtm.meta_key='bold_standart_caption')";
        $results = $this->_wpdb->get_results(
            $sql,
            ARRAY_A
        );
        foreach ($results as $row) {
            //echo $row['meta_value'];
            $captions[$row['term_id']]['standart'] = $row['meta_value'];
        }

        $sql = "SELECT wtm.term_id, wtm.meta_value FROM wp_termmeta wtm
        INNER JOIN wp_terms wt  ON ( wt.term_id=wtm.term_id and wtm.meta_key='bold_dual_caption')";
        $results = $this->_wpdb->get_results(
            $sql,
            ARRAY_A
        );
        foreach ($results as $row) {
            $captions[$row['term_id']]['dual'] = $row['meta_value'];
        }

        $sql = "SELECT wtm.term_id, wtm.meta_value FROM wp_termmeta wtm
        INNER JOIN wp_terms wt  ON ( wt.term_id=wtm.term_id and wtm.meta_key='bold_colortable_info')";
        $results = $this->_wpdb->get_results(
            $sql,
            ARRAY_A
        );
        foreach ($results as $row) {
            $captions[$row['term_id']]['colortable'] = $row['meta_value'];
        }


        return $captions;
    }

    public function getAllBrands()
    {
        $array_cat = [];
        $terms = get_terms('product_cat');
        foreach ($terms as $item) {
            $brand = get_term_meta($item->term_id, 'bold_product_brand', true);
            if ($brand == "Yes") {
                $array_cat[$item->term_id] = $item->name;
            }
        }
        return $array_cat;
    }

    public function contrast_color($hex)
    {
        $hex = trim($hex, ' #');

        $size = strlen($hex);
        if ($size == 3) {
            $parts = str_split($hex, 1);
            $hex = '';
            foreach ($parts as $row) {
                $hex .= $row . $row;
            }
        }

        $dec = hexdec($hex);
        $rgb = array(
            0xFF & ($dec >> 0x10),
            0xFF & ($dec >> 0x8),
            0xFF & $dec
        );

        $contrast = (round($rgb[0] * 299) + round($rgb[1] * 587) + round($rgb[2] * 114)) / 1000;
        return ($contrast >= 125) ? 'color-name-dark' : 'color-name';
    }



    public function getMinMaxPrices($categories_ids)
    {
        if ($this->isWholesaleUser) {
            $price_key = 'wholesale_customer_wholesale_price';
        } else {
            $price_key = '_regular_price';
        }

        /*
        $sql = "SELECT min(variation_meta.meta_value*1) as min, max(variation_meta.meta_value*1) as max FROM wp_posts variation
            LEFT JOIN wp_postmeta variation_meta ON (variation_meta.post_id=variation.ID and variation.post_status='publish' and variation_meta.meta_key='".$price_key."')
            INNER JOIN wp_posts product ON (variation.post_parent=product.ID)
            INNER JOIN wp_term_relationships ON (product.ID = wp_term_relationships.object_id) 
            WHERE (
            variation_meta.meta_value is NOT null and variation_meta.meta_value>0 and
            wp_term_relationships.term_taxonomy_id IN (".$categories_ids.") AND variation.post_type='product_variation' and product.post_status='publish' and product.post_type='product')";
        */

        $sql = "select min(min_val) as min, max(max_val) as max from (
            SELECT min(post_meta.meta_value*1) as min_val, max(post_meta.meta_value*1) as max_val FROM wp_posts post
            LEFT JOIN wp_postmeta post_meta ON post_meta.post_id=post.id
            LEFT JOIN wp_term_relationships wr ON (post.ID = wr.object_id)             
            where 
            post.post_status='publish' and 
            post_meta.meta_key='_regular_price' and
            wr.term_taxonomy_id IN (" . $categories_ids . ")
            
            union
            
            SELECT min(variation_meta.meta_value*1) as min_val, max(variation_meta.meta_value*1) as max_val FROM wp_posts post
            LEFT JOIN wp_posts variation ON variation.post_parent=post.ID            
            LEFT JOIN wp_postmeta variation_meta ON variation_meta.post_id=variation.id
            LEFT JOIN wp_term_relationships wr ON (post.ID = wr.object_id) 
            where 
            post.post_status='publish' and variation.post_status='publish' and             
            variation_meta.meta_key='_regular_price' and
            wr.term_taxonomy_id IN (" . $categories_ids . ")
            ) AS results";

        $results = $this->_wpdb->get_row(
            $sql,
            ARRAY_A
        );
        // Old Code---
        //$out[ 'min' ] = $this->_WOOCS->woocs_exchange_value( floor( $results[ 'min' ] ) );
        // $out[ 'max' ] = $this->_WOOCS->woocs_exchange_value( ceil( $results[ 'max' ] ) );

        //New24-May
        $out['min'] =  floor($results['min']);
        $out['max'] =  ceil($results['max']);

        //print_r($results);

        /*
        echo "SELECT min(variation_meta.meta_value*1) as min, max(variation_meta.meta_value*1) as max FROM wp_posts variation
        LEFT JOIN wp_postmeta variation_meta ON (variation_meta.post_id=variation.ID and variation.post_status='publish' and variation_meta.meta_key='".$price_key."')
        INNER JOIN wp_posts product ON (variation.post_parent=product.ID)
        INNER JOIN wp_term_relationships ON (product.ID = wp_term_relationships.object_id) 
        WHERE (
        variation_meta.meta_value is NOT null and variation_meta.meta_value>0 and
            wp_term_relationships.term_taxonomy_id IN (".$categories_ids.") AND variation.post_type='product_variation' and product.post_status='publish' and product.post_type='product')";
        */

        /*
        $results = $this->_wpdb->get_row("SELECT min(wp_postmeta.meta_value*1) as min,max(wp_postmeta.meta_value*1) as max FROM wp_posts 
        LEFT JOIN wp_term_relationships ON (wp_posts.ID = wp_term_relationships.object_id) 
        LEFT JOIN wp_postmeta ON (wp_posts.ID = wp_postmeta.post_id and meta_key='_price')
        WHERE ( wp_term_relationships.term_taxonomy_id IN (".$categories_ids.") ) 
        AND wp_posts.post_type in ('product')
        AND ((wp_posts.post_status = 'publish'))", ARRAY_A);
        
        echo "SELECT min(wp_postmeta.meta_value*1) as min,max(wp_postmeta.meta_value*1) as max FROM wp_posts 
        LEFT JOIN wp_term_relationships ON (wp_posts.ID = wp_term_relationships.object_id) 
        LEFT JOIN wp_postmeta ON (wp_posts.ID = wp_postmeta.post_id and meta_key='_regular_price')
        WHERE ( wp_term_relationships.term_taxonomy_id IN (".$categories_ids.") ) 
        AND wp_posts.post_type in ('product')
        AND ((wp_posts.post_status = 'publish'))";
        */

        return $out;
    }

    public function getAvailibleTypes($categories_ids)
    {
        $sql = "SELECT pm.meta_value as type FROM wp_posts post
        LEFT JOIN wp_term_relationships wr ON (post.ID = wr.object_id) 
        LEFT JOIN wp_postmeta pm ON ( pm.post_id=wr.object_id and pm.meta_key='bold_product_line_type' )
        WHERE post.post_status='publish' and wr.term_taxonomy_id IN ( " . $categories_ids . " )
        AND pm.meta_value is NOT null
        GROUP BY pm.meta_value ORDER BY pm.meta_value";
        //echo $sql;

        $results = $this->_wpdb->get_results(
            $sql,
            ARRAY_A
        );
        $out = [];
        foreach ($results as $row) {
            if ($row['type']) {
                $out[] = $row['type'];
            }
        }
        return $out;
    }

    public function getAvailibleSizes($categories_ids)
    {

        $sql = "SELECT pm.meta_value as size FROM wp_posts post
        LEFT JOIN wp_term_relationships wr ON (post.ID = wr.object_id) 
        LEFT JOIN wp_postmeta pm ON ( pm.post_id=wr.object_id and pm.meta_key='bold_product_size' )
        WHERE post.post_status='publish' and wr.term_taxonomy_id IN ( " . $categories_ids . " )
        AND pm.meta_value is NOT null
        GROUP BY pm.meta_value";
        $results = $this->_wpdb->get_results(
            $sql,
            ARRAY_A
        );
        $sizes = [];
        $undef_sizes = [];

        foreach ($results as $row) {
            switch ($row["size"]) {
                case "XS":
                case "X-Small":
                    $sizes["0"] = array("X-Small" => "XS");
                    break;

                case "S":
                case "Small":
                    $sizes["01"] = array("Small" => "S");
                    break;

                case "M":
                case "Medium":
                    $sizes["02"] = array("Medium" => "M");
                    break;

                case "L":
                case "Large":
                    $sizes["03"] = array("Large" => "L");
                    break;

                case "XL":
                case "X-Large":
                    $sizes["04"] = array("X-Large" => "XL");
                    break;

                default:
                    $undef_sizes[] = array($row["size"] => $row["size"]);
            }
        }

        ksort($sizes);

        $f_sizes = array_merge($sizes, $undef_sizes);
        $final = [];
        foreach ($f_sizes as $f_size) {
            foreach ($f_size as $key => $fs) {
                $final[$key] = $fs;
            }
        }
        return $final;
    }


    public function getAllColors()
    {
        $array_colors = [];
        $terms = get_terms('pa_color', array(
            'hide_empty' => false,
        ));

        foreach ($terms as $item) {
            $hex = get_term_meta($item->term_id, 'bold_product_color_hex', true);

            $array_colors[$item->slug] = array(
                "id"            => $item->term_id,
                "name"          => $item->name,
                "slug"          => $item->slug,
                "color"         => $hex,
                "class_color"   => $this->contrast_color($hex),
                "dual"          => get_term_meta($item->term_id, 'bold_product_color_dual_texture', true),
                "sort_order"    => (int)get_term_meta($item->term_id, 'bold_product_color_sortorder', true)
            );
        }


        //print_r($array_colors);
        return $array_colors;
    }

    //public function getColorTableProduct($colors, $variation_id, $stock_data){
    public function getColorTableProduct($variants, $manage_stock, $product_captions)
    {

        //Separate standard and dual colors       
        $standard = [];
        $dual = [];

        foreach ($variants as $variant) {
            if ($variant['color']['dual'] == "Yes") {
                $dual[] = $variant;
            } else {
                $standard[] = $variant;
            }
        }


        usort($standard, function ($item1, $item2) {
            return $item1['color']['sort_order'] <=> $item2['color']['sort_order'];
        });
        usort($dual, function ($item1, $item2) {
            return $item1['color']['sort_order'] <=> $item2['color']['sort_order'];
        });

        $standard_str = "";
        //echo '<pre>'; print_r($variants); echo '<pre>';
        foreach ($standard as $item_color) {
            $standard_str .= $this->getProductColorRowHtml($item_color, $manage_stock);
            //$standard_str.=$this->getProductColorRowHtml($item_color, $variation_id, $stock_data);
        }
        $dual_str = "";
        foreach ($dual as $item_color) {
            $dual_str .= $this->getProductColorRowHtml($item_color, $manage_stock);
            //$dual_str.=$this->getProductColorRowHtml($item_color, $variation_id, $stock_data);
        }
        //echo "!".$standard_str."!";
        return $this->getProductColorBlockHtml($standard_str, $dual_str, $manage_stock, $product_captions);
    }

    public function getProductColorBlockHtml($standard_str, $dual_str, $manage_stock, $product_captions)
    {


        $standard_block = "";
        $dual_block = "";
        if ($standard_str) {
            $standard_block = '
            <div class="standard-stock">
                <div class="type-stock">
                    <div class="line_lft"></div>
                    <span class="color-type">' . $product_captions['standart'] . '</span> 
                    <div class="line_rgt"></div>
                </div>
                <div class="color-inventory">
                    ' . $standard_str . '
                </div>
            </div>';
        }
        if ($dual_str) {
            $dual_block = '
            <div class="standard-stock">
                <div class="type-stock">
                    <div class="line_lft"></div>
                    <span class="color-type">' . $product_captions['dual'] . '</span>
                    <div class="line_rgt"></div>
                </div>
                <div class="color-inventory">
                    ' . $dual_str . '
                </div>
            </div>';
        }
        $check_sale_discounted = get_post_meta($product_captions['product_id'], 'sale_discounted_item', true);
        $_hide_incoming_stock = get_post_meta($product_captions['product_id'], '_hide_incoming_stock', true);
        $only_full_line_product = get_post_meta($product_captions['product_id'], 'only_full_line_product', true);
        $force_add_class = '';
        if ($_hide_incoming_stock === 'Yes' && in_array($check_sale_discounted, ['Discounted', 'Sale'])) {
            $force_add_class = 'incoming-stock-row';
        } else {
            $force_add_class = '';
        }
        /* Hide current and incoming stock row */
        $fillline_stockrow_class = '';
        if ($only_full_line_product == 'yes') {
            $fillline_stockrow_class = 'current-incoming-row';
        }
        //echo $only_full_line_product.'here';
        /* Gaurav - 25 Aug 2023 */
        $current_date = new DateTime();
        $instock_date = $product_captions['instock_date'];
        $product_available_date = new DateTime($instock_date);
        $confirmData = 'No products are on the way';
        if (!empty($instock_date)) {
            $interval = $current_date->diff($product_available_date);
            $dateDiff = $interval->days;
            if ($dateDiff > 6) {
                $diff = $current_date->diff($product_available_date);
                $numberOfWeeks = floor($diff->days / 7);
                $confirmData = ($numberOfWeeks > 1) ? 'Available in about ' . $numberOfWeeks . ' weeks.' : 'Available in about ' . $numberOfWeeks . ' week.';
            } else {
                if ($current_date < $product_available_date) {
                    $confirmData = ($dateDiff > 1) ? 'Available in about ' . $dateDiff . ' days.' : 'Availables in about ' . $dateDiff . ' day.';
                } else {
                    $confirmData = 'No products are on the way';
                }
            }
        }
        /* The End */
        return '<div class="product-sheet">
            <div class="my-order_tbl attribute-wrapper ">
                <div class="stock-placeholder">
                    ' . ($manage_stock ?
            '
                    <div class="stock-separator">
                        <span class="showtooltip desktooltip ' . $fillline_stockrow_class . '">IN STOCK
                            <span class="maintooltip">
                                <img src="https://boldclimbing.com/wp-content/uploads/2023/09/info-icon.png" class="infoicon" alt="info-icon"/>
                                <span class="customcontent">Typically ships in 5 business days.</span>
                            </span>
                        </span>
                        <span class="showtooltip mobilecontent">STOCK
                            <span class="maintooltip">
                                <img src="https://boldclimbing.com/wp-content/uploads/2023/09/info-icon.png" class="infoicon" alt="info-icon"/>
                                <span class="customcontent">Typically ships in 5 business days.</span>
                            </span>
                        </span>
                    </div>
                    <div class="stock-separator">
                        <span class="showtooltip desktooltip ' . $force_add_class . ' ' . $fillline_stockrow_class . '">INCOMING STOCK
							<span class="maintooltip">
								<img src="https://boldclimbing.com/wp-content/uploads/2023/09/info-icon.png" class="infoicon" alt="info-icon"/>
								<span class="customcontent">' . $confirmData . '</span>
							</span>
						</span>
                        <span class="showtooltip mobilecontent">FUTURE
							<span class="maintooltip">
								<img src="https://boldclimbing.com/wp-content/uploads/2023/09/info-icon.png" class="infoicon" alt="info-icon"/>
								<span class="customcontent">' . $confirmData . '</span>
							</span>
						</span>
                    </div>' : '') . '
                    <div class="stock-separator"> 
                        <span class="showtooltip desktooltip">MY ORDER
                            <span class="maintooltip">
                                <img src="https://boldclimbing.com/wp-content/uploads/2023/09/info-icon.png" class="infoicon" alt="info-icon"/>
                                <span class="customcontent">Enter order here. You can order items not in stock. These will be produced for you.</span>
                            </span>
                        </span>
                        <span class="showtooltip mobilecontent">ORDER
                            <span class="maintooltip">
                                <img src="https://boldclimbing.com/wp-content/uploads/2023/09/info-icon.png" class="infoicon" alt="info-icon"/>
                                <span class="customcontent">Enter order here. You can order items not in stock. These will be produced for you.</span>
                            </span>
                        </span>
                    </div>
                </div>
                <div class="inventory-wrapper">
                    <form>
                    <div class="attribute-stock">
                        ' . $standard_block . $dual_block . '
                    </div>
                    </form>
                </div>
            </div>
        </div>';
    }

    //public function getProductColorRowHtml($item_color, $variation_id, $stock_data){
    public function getProductColorRowHtml($item_color, $manage_stock)
    {

        $check_sale_discounted = get_post_meta($item_color['product_id'], 'sale_discounted_item', true);
        $not_allow_backorders = get_post_meta($item_color['variation_id'], '_backorders_allow', true);
        $_hide_incoming_stock = get_post_meta($item_color['product_id'], '_hide_incoming_stock', true);
        $only_full_line_product = get_post_meta($item_color['product_id'], 'only_full_line_product', true);
        /* Hide current and incoming stock row */
        $fillline_stockrow_class = '';
        if ($only_full_line_product == 'yes') {
            $fillline_stockrow_class = 'current-incoming-row';
        }

        $force_add_class = '';
        if ($_hide_incoming_stock === 'Yes' && in_array($check_sale_discounted, ['Discounted', 'Sale'])) {
            $force_add_class = 'incoming-stock-row';
        }

        // if(!empty($_hide_incoming_stock) && $_hide_incoming_stock == 'Yes' && $check_sale_discounted == 'Discounted'){
        //     $force_add_class = 'incoming-stock-row';
        // }else{
        //     $force_add_class = '';
        // }

        $force_opacity = '';
        if ($item_color['in_stock'] || $item_color['in_stock6']) {
        } else {
            $force_opacity = '0.7';
            $force_opacity = "darkcolor";
        }
        //in_array($check_sale_discounted, ['Discounted', 'Sale'])
        if ($check_sale_discounted == 'Discounted' ||  $check_sale_discounted == 'Sale') {
            if ($not_allow_backorders != 'no') {
                $force_input = '<input type="number" name="variation[' . $item_color['variation_id'] . ']" style="background-color: ' . $item_color['color']['color'] . '" class="my-stock  my-stock-input ' . $item_color['color']['class_color'] . '" data-variation-id="' . $item_color['variation_id'] . '" min="0" value="0" />';
            } else {
                $force_class = 'disable-input';
                $force_input = '<span class="tooltip-discounted">
                                    <input type="number" name="variation[' . $item_color['variation_id'] . ']" style="background-color: ' . $item_color['color']['color'] . '" class="my-stock ' . $force_opacity . ' ' . $force_class . ' my-stock-input ' . $item_color['color']['class_color'] . '" data-variation-id="' . $item_color['variation_id'] . '" min="0" value="0"/>
                                    <span class="tooltiptext">Must order from stock</span>
                                </span>';
            }
        } else {
            $force_input = '<input type="number" name="variation[' . $item_color['variation_id'] . ']" style="background-color: ' . $item_color['color']['color'] . '" class="my-stock  my-stock-input ' . $item_color['color']['class_color'] . '" data-variation-id="' . $item_color['variation_id'] . '" min="0" value="0" />';
        }
        return '<div class="color-wrapper">
                <div class="color-block" style="background-color: ' . $item_color['color']['color'] . '">
                    <span class="' . $item_color['color']['class_color'] . '">' . $item_color['color']['name'] . '</span>
                </div>
                <div class="in-stock iamhere">
                    ' . ($manage_stock ?
            '<span style="background-color: ' . $item_color['color']['color'] . '" class="' . $fillline_stockrow_class . ' color-stock ' . $item_color['color']['class_color'] . ' ' . $force_opacity . '">' . ($item_color['in_stock'] ? $item_color['in_stock'] : '') . '</span>
                    <span style="background-color: ' . $item_color['color']['color'] . '" class="' . $fillline_stockrow_class . ' color-stock ' . $item_color['color']['class_color'] . ' ' . $force_add_class . ' ' . $force_opacity . '">' . ($item_color['in_stock6'] ? $item_color['in_stock6'] : '') . '</span>' :
            ''
        ) . '
                    ' . $force_input . '
                </div>
            </div>';
    }

    public function getBrandedCardHtml($product_data, $isBranded)
    {
        //echo '<pre>';  print_r($product_data); echo '</pre>';
        $branding_list = '';
        if ($product_data['branding_options']) {
            $branding_options_array = explode("|", $product_data['branding_options']);
            $disabled_options = '';

            if (count($branding_options_array) == 1) {
                $disabled_options = 'disabled';
            }
            $branding_list = '<select ' . $disabled_options . ' class="branding_list_select" name="branding_option">';
            foreach ($branding_options_array as $option) {
                $branding_list .= '<option value="' . $option . '">' . $option . '</option>';
            }
            $branding_list .= '</select>';
        }


        //if( isset( $product_data[ 'pack' ] ) ){

        if ($this->isWholesaleUser) {
            $str1 = '<td></td><td>Amount</td>';
            $str2 = '<td><div class="fulllist_table_tr_cap">Single Pack</div><div class="fulllist_table_tr_desc">20% Margin Retail Items</div></td>';
            $str3 = '<td>Total</td>';
        } else {
            $str1 = '';
            $str2 = '';
            $str3 = '';
        }

        //print_r($product_data);
        if (isset($product_data['pack'][0])) {
            $price0 = $total0 = $product_data['pack'][0]['price'];
            $price1 = isset($product_data['pack'][1]['price']) ? $product_data['pack'][1]['price'] : 0;
            $price2 = isset($product_data['pack'][2]['price']) ? $product_data['pack'][2]['price'] : 0;

            if (isset($product_data['pack'][1]['count']) and $product_data['pack'][1]['count']) {
                $total1 = $price1 / $product_data['pack'][1]['count'];
            } else {
                $total1 = 0;
            }

            if (isset($product_data['pack'][2]['count']) and $product_data['pack'][2]['count']) {
                //echo $product_data['product_id']."=pack_count=".$product_data[ 'pack' ][ 2 ][ 'count' ]."<br/>";
                $total2 = $price2 / $product_data['pack'][2]['count'];
            } else {
                $total2 = 0;
            }
        } else {
            $price0 = $total0 = $product_data['price'];
            $price1 = $total1 = 0;
            $price2 = $total2 = 0;
            if ($this->isWholesaleUser) {
                $price0 = $total0 = $product_data['wholesale_customer_wholesale_price'];
            }
            /*else{
        $price0 = $product_data[ 'msrp' ];
       if($price0 == ''){
            $price0 = $total0 = $product_data[ 'price' ];
       } 
    }*/
        }

        // ------ Check product tag-----

        $Firstmargin_item = '';
        $secondtmargin_item = '';
        $product_terms = wp_get_post_terms($product_data['product_id'], 'product_tag');
        $termsArray = array();
        if (count($product_terms) > 0) {
            foreach ($product_terms as $term) {
                $term_name = $term->name;
                $termsArray[] = $term_name;
            }
        } else {
        }
        if (in_array('Retail', $termsArray)) {
            $str2 = '<td><div class="fulllist_table_tr_cap">Single Pack</div><div class="fulllist_table_tr_desc">20% Margin Retail Items</div></td>';
            $Firstmargin_item = '<div class="fulllist_table_tr_desc">30% Margin Retail Items</div>';
            $secondtmargin_item = '<div class="fulllist_table_tr_desc">40% Margin Retail Items</div>';
        } else {
            $str2 = '<td><div class="fulllist_table_tr_cap">Single Pack</div><div class="fulllist_table_tr_desc"></div></td>';
        }

        $first_pack_caption = '1 Pack';

        //echo "price1=".$price1."<br/>";
        //echo 'price1_rate='.$WOOCS->woocs_exchange_value($price1);
        //echo $product_data['title']."<br/>";

        $pack_str = '
            
            <div class="branded_tr_cell_fulllist">
                <div class="branded_tr_cell_fulllist_wrapper">
                    <div class="branded_tr_cell_fulllist_rows">
                        
                        <table class="fulllist_table">
                            <tr class="fulllist_table_caption">
                                ' . $str1 . '
                                <td>Price</td>
                                ' . $str3 . '
                                <td>Order</td>
                            </tr>
                            <tr class="fulllist_table_vals">
                            ' . $str2 . '
                            ' . ($this->isWholesaleUser ? ('<td class="fulllist_table_cell">' . $first_pack_caption . '</td>') : '') . '
                                <td class="fulllist_table_cell">' . wc_price($price0) . '</td>
                            ' . ($this->isWholesaleUser ? ('<td class="fulllist_table_cell">' . wc_price($total0) . '</td>') : '') . '                                
                                
                                <td class="fulllist_table_cell pack_input_col" data-variation_id="' . (isset($product_data['pack'][0]['variant_id']) ? $product_data['pack'][0]['variant_id'] : '') . '"><input value="1" class="brand1_input_pack2 input_pack2" type="number" min="0" step="1"></td>
                            </tr>
                            ' . ($this->isWholesaleUser ? '
                                <tr class="fulllist_table_vals">
                                    ' . ($total1 ? '
                                        <td>
                                            <div class="fulllist_table_tr_cap">Small Pack</div>
                                            ' . $Firstmargin_item . '
                                        </td>
                                        <td class="fulllist_table_cell">' . $product_data['pack'][1]['count'] . ' Pack</td>
                                        <td class="fulllist_table_cell">' . wc_price($total1) . '</td>
                                        <td class="fulllist_table_cell">' . wc_price($price1) . '</td>
                                        <td class="fulllist_table_cell pack_input_col" data-variation_id="' . $product_data['pack'][1]['variant_id'] . '"><input class="brand2_input_pack2 input_pack2" type="number" min="0" step="1"></td>
                                    ' : '') . '
                                    
                                </tr>
                                <tr class="fulllist_table_vals">
                                    ' . ($total2 ? '
                                        <td>
                                            <div class="fulllist_table_tr_cap">Big Pack</div>
                                            ' . $secondtmargin_item . '
                                        </td>
                                        <td class="fulllist_table_cell">' . $product_data['pack'][2]['count'] . ' Pack</td>
                                        <td class="fulllist_table_cell">' . wc_price($total2) . '</td>
                                        <td class="fulllist_table_cell">' . wc_price($price2) . '</td>
                                        <td class="fulllist_table_cell pack_input_col" data-variation_id="' . $product_data['pack'][2]['variant_id'] . '"><input class="brand3_input_pack2 input_pack2" type="number" min="0" step="1"></td>
                                    ' : '') . '
                                    
                                </tr>' : '') . '

                        </table>
                    </div>
                </div>
            </div>

            <div class="branded_tr_cell branded_tr_cell_table">
                <div class="branded_table branded_table_retail">
                    <div class="branded_tr_cell first_col_pack table_pack_count branded_tr_fx">1 Pack</div>
                    <div class="branded_tr_cell table_pack_price branded_tr_fx">' . wc_price($price0) . '</div>
                    <div class="branded_tr_cell first_col_pack table_pack_price">' . wc_price($price0) . '</div>
                    <div class="branded_tr_cell last_col_pack pack_input_col" data-variation_id="' . (isset($product_data['pack'][0]['variant_id']) ? $product_data['pack'][0]['variant_id'] : '') . '">
                        <input class="brand1_input_pack1 input_pack1" type="number" min="0" step="1" value="1">
                    </div>
                </div>
            </div>                
            ';


        if ($this->isWholesaleUser) {
            if ($total1) {
                $pack_str .= '
                    <div class="branded_tr_cell branded_tr_cell_table">
                        <div class="branded_table">
                            <div class="branded_tr_cell first_col_pack table_pack_count">' . $product_data['pack'][1]['count'] . ' Pack</div>
                            <div class="branded_tr_cell table_pack_price">' . wc_price($total1) . '</div>
                            <div class="branded_tr_cell table_pack_price">' . wc_price($price1) . '</div>
                            <div class="branded_tr_cell last_col_pack pack_input_col" data-variation_id="' . $product_data['pack'][1]['variant_id'] . '">
                                <input class="brand2_input_pack1 input_pack1" type="number" min="0" step="1">
                            </div>
                        </div>
                    </div>';
            } else {
                $pack_str .= '
                    <div class="branded_tr_cell branded_tr_cell_table">
                        <div class="branded_table"></div>
                    </div>';
            }

            if ($total2) {
                $pack_str .= '
                    <div class="branded_tr_cell branded_tr_cell_table">
                        <div class="branded_table">
                            <div class="branded_tr_cell first_col_pack table_pack_count">' . $product_data['pack'][2]['count'] . ' Pack</div>
                            <div class="branded_tr_cell table_pack_price">' . wc_price($total2) . '</div>
                            <div class="branded_tr_cell table_pack_price">' . wc_price($price2) . '</div>
                            <div class="branded_tr_cell last_col_pack pack_input_col" data-variation_id="' . $product_data['pack'][2]['variant_id'] . '">
                                <input class="brand3_input_pack1 input_pack1" type="number" min="0" step="1">
                            </div>
                        </div>
                    </div>';
            } else {
                $pack_str .= '
                    <div class="branded_tr_cell branded_tr_cell_table">
                        <div class="branded_table"></div>
                    </div>';
            }
        }
        $pack_str .= '<div class="branded_tr_cell pack_addtocart"><div class="add_to_cart_branded">Add to cart</div></div>';

        //}
        //$isBranded = get_post_meta( $this->_category_id, 'bold_product_branded', true ) == "Yes";
        $add_title          = '';
        $branded_options    = '';
        $retail_price       = '';
        $retail_price_full  = '';

        if ($isBranded) {
            $add_title          = 'BRANDED - ';
            $branded_options    = '
            <div class="branded_tr_cell branded_options_list">
                <div class="branded_options_list_caption">Options</div>
                ' . $branding_list . '
            </div>';
        }
        if ($this->isWholesaleUser) {
            $retail_price       = '<div class="branded_tr_cell table_pack_price branded_table_msrp">' . wc_price($product_data['msrp']) . '</div>';
            $retail_price_full  = '<div class="table_pack_retail">MSRP (Retail) Price: ' . wc_price($product_data['msrp']) . ' </div>';
        }

        // Badges
        $sale_discount_item = get_post_meta($product_data['product_id'], 'sale_discounted_item', true);
        $new_tag = '';
        if ($sale_discount_item) {
            if ($this->isWholesaleUser) {
                $discount_cost = get_post_meta($product_data['product_id'], 'discount_wholesale_cost', true);
            } else {
                $discount_cost = get_post_meta($product_data['product_id'], 'discount_retail_cost', true);
            }
            if ($sale_discount_item == 'Discounted') {
                $new_tag = '<span class="acoplw-badge-icon acoplw-bsfour acoplwRightAlign acoplwPosTop acoplw-j-custom" style="opacity:1;width:155px;font-size:px;line-height:px;font-weight: 400;transform:rotateX(0deg) rotateY(0deg) rotateZ(0deg);border-radius: 0px 3px 3px 0px;top:0px;bottom:auto;background:rgba(208, 2, 27, 1); z-index: 2;"><span class="acoplw-blockText stock-sale" style="color:rgba(255, 255, 255, 1);">' . $discount_cost . '% discount</span></span>';
                $new_tag = '<span class="acoplw-badge-icon acoplw-bsfour acoplwRightAlign acoplwPosTop acoplw-j-custom" style="opacity:1;width:155px;font-size:px;line-height:px;font-weight: 400;transform:rotateX(0deg) rotateY(0deg) rotateZ(0deg);border-radius: 0px 3px 3px 0px;top:0px;bottom:auto;background:rgba(208, 2, 27, 1); z-index: 2;"><span class="acoplw-blockText stock-sale" style="color:rgba(255, 255, 255, 1);">' . $discount_cost . '% discount</span></span>';

                // $full_tag = '';
            } elseif ($sale_discount_item == 'Sale') {
                $new_tag = '<span class="acoplw-badge-icon acoplw-bsfour acoplwRightAlign acoplwPosTop acoplw-j-custom" style="opacity:1;width:155px;font-size:px;line-height:px;font-weight: 400;transform:rotateX(0deg) rotateY(0deg) rotateZ(0deg);border-radius: 0px 3px 3px 0px;top:0px;bottom:auto;background:rgba(208, 2, 27, 1); z-index: 2;"><span class="acoplw-blockText stock-sale" style="color:rgba(255, 255, 255, 1);">Stock Sale ' . $discount_cost . '% off</span></span>';
            } else {
                $new_tag = '';
            }
        }


        $out = '
        <div class="branded_main_container">
            <div class="branded_tr_row" data-id="' . $product_data['product_id'] . '">
                <div class="branded_tr_cell table_pack_name">
                    <div class="table_pack_name_wrapper">
                        <div class="table_pack_name_caption">
                            <a href="' . $product_data['link'] . '">
                                ' . $add_title . $product_data['title'] . '
                            </a>
                            ' . $retail_price_full . '
                            ' . $branded_options . '
                        </div>
                        <div class="wrapp-product-image">
                            <a class="product-image" href="' . $product_data['link'] . '">
                                ' . $new_tag . '
                                ' . $product_data['image'] . '
                            </a>
                        </div>
                    </div>
                </div>
                ' . $branded_options . '
                ' . $retail_price . '
                ' . $pack_str . '
            </div>
            <div class="wrapper_notice">
                <div class="success-notice success-notice-block" style="display: none;">
                    Success! Your items have been added to the cart. <a href="/cart/">Checkout <span class="fa fa-angle-right"></span></a>
                </div>
            </div>
        </div>
        ';

        return $out;
    }

    public function getProductCardHtml($product_data)
    {

        // CHeck Product varition stock qty
        $product = wc_get_product($product_data['product_id']);
        $variant_ids = array();
        if ($product && $product->is_type('variable')) {
            $variations = $product->get_children();
            foreach ($variations as $variation_id) {
                $variant_ids[] = $variation_id;
            }
        }
        if ($variant_ids) {
            $totalstock = 0;
            $variants_str = implode(",", $variant_ids);
            $sql_inbound = "SELECT wi.product_id, wm.stock_quantity as inbound_stock FROM wp_atum_inventories wi
                                LEFT JOIN wp_atum_inventory_meta wm ON wi.id = wm.inventory_id
                                WHERE wi.product_id IN (" . $variants_str . ") and wi.priority = 1";

            $meta_values = $this->_wpdb->get_results(
                $sql_inbound,
                ARRAY_A
            );
            foreach ($meta_values as $itm) {
                $totalstock += $itm['inbound_stock'] * 1;
            }

            $meta_values = $this->_wpdb->get_results(
                "select product_id, stock_quantity from wp_wc_product_meta_lookup where product_id in (" . $variants_str . ")",
                ARRAY_A
            );
            foreach ($meta_values as $itm) {
                $totalstock += $itm['stock_quantity'] * 1;
            }
        }
        // ---- End -----
        // -----Badges------//
        $new_tag = '';
        $full_tag = '';

        $terms = wp_get_post_terms($product_data['product_id'], 'product_tag');
        $termsArray = array();
        if (count($terms) > 0) {
            foreach ($terms as $term) {
                $term_name = $term->name;
                $termsArray[] = $term_name;
            }
        } else {
        }
        if ($termsArray) {
            if (in_array('New', $termsArray)) {
                $new_tag = '<span class="acoplw-badge-icon acoplw-bsone acoplwRightAlign acoplwPosBtm acoplw-full-line-10-off-copy-custom" style="opacity:1;width:94px;font-size:14px;line-height:30px;font-weight: 600;height:30px;transform:rotateX(0deg) rotateY(0deg) rotateZ(0deg);border-radius: 3px 3px 3px 3px;bottom:0px;top:auto;background:rgba(253, 207, 0, 1);"><span class="acoplw-blockText" style="color:rgba(0, 0, 0, 1);">New !</span></span>';
            }
            if (in_array('Full', $termsArray)) {
                $full_tag = '<span class="acoplw-badge-icon acoplw-bsfive acoplwLeftAlign acoplwPosTop acoplw-full-line-custom " style="opacity:1;width:125px;font-size:12px;line-height:23px;font-weight: 600;transform:rotateX(0deg) rotateY(0deg) rotateZ(0deg);top:0px;bottom:auto;height:125px;"><span class="acoplw-blockOne" style=""></span><span class="acoplw-blockTwo"></span><span class="acoplw-blockText" style="color:rgba(0, 0, 0, 1);background:rgba(253, 207, 0, 1);width:176.25px;top:32.5px;left:-38.75px;right:auto;">Full Line</span></span>';
            }
            if (in_array('Full2.5', $termsArray)) {
                $full_tag = '<span class="acoplw-badge-icon acoplw-bsfive acoplwLeftAlign acoplwPosTop acoplw-full-line-custom " style="opacity:1;width:125px;font-size:12px;line-height:23px;font-weight: 600;transform:rotateX(0deg) rotateY(0deg) rotateZ(0deg);top:0px;bottom:auto;height:125px;"><span class="acoplw-blockOne" style=""></span><span class="acoplw-blockTwo"></span><span class="acoplw-blockText" style="color:rgba(0, 0, 0, 1);background:rgba(253, 207, 0, 1);width:176.25px;top:32.5px;left:-38.75px;right:auto;">Full Line 2.5% Off</span></span>';
            }
        }
        // Discounted Badges
        $sale_discount_item = get_post_meta($product_data['product_id'], 'sale_discounted_item', true);
        if ($sale_discount_item == 'Discounted') {
            $new_tag = '<span class="acoplw-badge-icon acoplw-bsthree acoplwRightAlign acoplwPosTop acoplw-woo-badge-2-custom" style="opacity:1;width:111px;font-size:px;line-height:px;font-weight: 400;transform:rotateX(0deg) rotateY(0deg) rotateZ(0deg);border-radius: 3px 3px 3px 3px;top:0px;bottom:auto;background:rgba(208, 2, 27, 1); z-index: 2;"><span class="acoplw-blockText" style="color:rgba(255, 255, 255, 1);">Discounted</span></span>';
            $full_tag = '';
        } else {
            if ($sale_discount_item == 'Sale') {
                $new_tag = '<span class="acoplw-badge-icon acoplw-bsfour acoplwRightAlign acoplwPosTop acoplw-woo-badge-custom" style="opacity:1;width:60px;font-size:px;line-height:32px;font-weight: 400;transform:rotateX(0deg) rotateY(0deg) rotateZ(0deg);border-radius: 0px 3px 3px 0px;top:0px;bottom:auto;background:rgba(208, 2, 27, 1); z-index: 2;"><span class="acoplw-blockText" style="color:rgba(255, 255, 255, 1);">SALE</span></span>';
                $full_tag = '';
            }
        }

        // Check Discounted/sales item
        //$check_current_user = $this->getUserRoles();
        if ($sale_discount_item == 'Discounted' || $sale_discount_item == 'Sale') {
            $discount_retail_cost = get_post_meta($product_data['product_id'], 'discount_retail_cost', true);
            $discount_wholesale_cost = get_post_meta($product_data['product_id'], 'discount_wholesale_cost', true);
        }
        $discount_sale_price = '';
        $discount_cost = '';
        if ($this->isWholesaleUser) {
            $discount_cost = get_post_meta($product_data['product_id'], 'discount_wholesale_cost', true);
            if ($discount_wholesale_cost != '') {
                $force_discount = $discount_wholesale_cost * $product_data['price'] / 100;
                $discountprice = $product_data['price'] - $force_discount;
                $discount_sale_price = wc_price($discountprice);
            }
        } else {
            $discount_cost = get_post_meta($product_data['product_id'], 'discount_retail_cost', true);
            if ($discount_retail_cost != '') {
                $force_discount = $discount_retail_cost * $product_data['price'] / 100;
                $discountprice = $product_data['price'] - $force_discount;
                $discount_sale_price = wc_price($discountprice);
            }
        }
        // Stock Sale disocunt badges
        $stock_sale_current = get_post_meta($product_data['product_id'], 'stock_sale_current', true) === 'on';
        $stock_sale_future = get_post_meta($product_data['product_id'], 'stock_sale_future', true) === 'on';
        $stock_sale_mto = get_post_meta($product_data['product_id'], 'stock_sale_mto', true) === 'on';

        if ($sale_discount_item == 'Discounted') {
            $new_tag = '<span class="acoplw-badge-icon acoplw-bsfour acoplwRightAlign acoplwPosTop acoplw-j-custom" style="opacity:1;width:155px;font-size:px;line-height:px;font-weight: 400;transform:rotateX(0deg) rotateY(0deg) rotateZ(0deg);border-radius: 0px 3px 3px 0px;top:0px;bottom:auto;background:rgba(208, 2, 27, 1); z-index: 2;"><span class="acoplw-blockText stock-sale" style="color:rgba(255, 255, 255, 1);">' . $discount_cost . '% discount</span></span>';
            $full_tag = '';
        } elseif ($sale_discount_item == 'Sale') {
            $new_tag = '<span class="acoplw-badge-icon acoplw-bsfour acoplwRightAlign acoplwPosTop acoplw-j-custom" style="opacity:1;width:155px;font-size:px;line-height:px;font-weight: 400;transform:rotateX(0deg) rotateY(0deg) rotateZ(0deg);border-radius: 0px 3px 3px 0px;top:0px;bottom:auto;background:rgba(208, 2, 27, 1); z-index: 2;"><span class="acoplw-blockText stock-sale" style="color:rgba(255, 255, 255, 1);">Stock Sale ' . $discount_cost . '% off</span></span>';
            $full_tag = '';
        } else {
            //$new_tag = '';
            //$full_tag = '';
        }

        if ($discount_sale_price != '') {
            $price_section = '<span class="product-price"> <del style=" margin-right: 4px;" >' . wc_price($product_data['price'])  . '</del>' . $discount_sale_price . '</span>';
        } else {
            $price_section = '<span class="product-price"> <del style=" margin-right: 4px;" ></del>' . wc_price($product_data['price']) . '</span>';
        }


        // End
        return '<div data-id="' . $product_data['product_id'] . '" class="product-wrapper">
            <div class="product-wrapper-info">
                <div class="wrapper_product_info">
                    <div class="wrapp-product-image">
                        <a class="product-image" href="' . $product_data['link'] . '">
                            ' . $new_tag . '
                            ' . $full_tag . '
                            ' . $product_data['image'] . '
                        </a>
                    </div>
                    <div class="product-minfo">
                        <h3><a href="' . $product_data['link'] . '">' . $product_data['title'] . '</a></h3>
                        <div class="price-wrapper">
                            ' . $this->getProductCardBrand($product_data['brand']) . '
                            ' . $this->getProductCardSize($product_data['size']) . '
                            ' .  $price_section . '
                        </div>
                    </div>
                </div>
                <div class="wrapper_product-sheet">
                    ' . $product_data['t_table'] . '
                    <div class="wrapper_add_button">
                        ' . $product_data['count_item'] . '
                        ' . $product_data['add_button'] . '
                    </div>
                </div>
            </div>
            <div class="success-notice success-notice-block">Success! Your items have been added to the cart. <a href="/cart/">Checkout <span class="fa fa-angle-right"></span></a></div>
        </div>';
    }
    public function getProductCardHtmlFull($product_data)
    {
        if ($product_data['variant_type'] == "pack") {

            $add_button = '<div class="active addtocart_button_product add-to-cart-trigger" data-product_id="' . $product_data['product_id'] . '" data-type="' . $product_data['variant_type'] . '">Add to cart</div>';
            //echo "!".$product_data[ 'branding_options' ]."!";
            if ($this->isWholesaleUser and $product_data['branding_options']) {
                $product_data_array = explode("|", $product_data['branding_options']);

                if ($product_data_array) {
                    $options = '';
                    foreach ($product_data_array as $itm) {
                        $options .= '<option value="' . $itm . '">' . $itm . '</option>';
                    }
                    /*
                    $add_button .= '
                        <div class="branded_add_product_wrap">
                            <div class="branded_add_product_caption">Also available branding options:</div>
                            <div class="branded_add_product_select">
                                <select id="product_brand_select">
                                    ' . $options . '
                                </select>
                            </div>
                            <div class="active addtocart_button_brand">Add branded to cart</div>
                        </div>';
                    */
                    $add_button = '
                        <div class="branded_add_product_wrap">
                            <div class="branded_add_product_caption">
                                <strong>Branding Options</strong> - See branding tab above for more details & prices
                            </div>

                            <div class="branded_add_product_selects">
                                <div class="branded_add_product_select">
                                    <div class="branded_add_product_caption">Would you like your items Branded?</div>
                                    <select id="product_brand_asc">
                                        <option value="No" selected>No</option>
                                        <option value="Yes">Yes</option>
                                    </select>
                                </div>

                                <div class="type_product_select">
                                    <div class="branded_add_product_select">
                                        <div class="branded_add_product_caption">How would you like it branded:</div>
                                        <select id="product_brand_select">
                                            ' . $options . '
                                        </select>
                                    </div>
                                </div>
                            </div>

                            <!--<div class="active addtocart_button_brand">Add branded to cart</div>-->
                        </div>' . $add_button;
                }
            }
            $add_button = '<div class="wrapper_addto_product">' . $add_button . '</div>';
        }

        if ($product_data['variant_type'] == "color") {
            $add_button = '<div class="addtocart_button_product add-to-cart-trigger" data-product_id="' . $product_data['product_id'] . '" data-type="' . $product_data['variant_type'] . '">Add to cart</div>';
        }
        if ($product_data['variant_type'] == "") {
            $add_button = '<form class="wrapper_single_button">
                <input name="variation[' . $product_data['product_id'] . ']" type="number" class="input_single_button" min="1" value="1" />
                <div class="active single addtocart_button_product" data-product_id="' . $product_data['product_id'] . '" data-type="simple">Add to cart</div>
            </form>
            ';
        }

        //print_r($product_data);
        //<li data-name="shipping-info">Branding</li>
        $branding_li = '';
        if ($product_data['branding_options']) {
            $branding_li = '<li data-name="branding-info">Branding</li>';
        }

        $product_str = '<div class="attribute-row">
            <ul>
                <li data-name="my-order" class="active">My Order</li>
                ' . ($product_data['variant_type'] == "color" ? '<li data-name="color-info">Colors</li>' : '') . '
                <li data-name="shipping-info">Shipping Info</li>
                ' . $branding_li . '
            </ul>
        </div>
        <div  class="my-order info-tab attribute-wrapper active product-wrapper-info">
            ' . $product_data['t_table'] . '        
            ' . $add_button . '
        </div>
        ';

        return $product_str;
    }
    public function getProductCountItemHtml($count_item)
    {
        if ($count_item) {
            return '<input type="number" class="input-text qty text" step="1" min="1" max="" name="quantity" value="1" title="Qty" size="4" placeholder="" inputmode="numeric" autocomplete="off">';
        }
        return '';
    }
    public function getProductsOuterHtml($products_html)
    {
        /*
        return '<div id="product-container" class="product-container" data-page="1" data-view="'.$_COOKIE['bld_cat_view'].'">
            '.$products_html.'
        </div>';
        */
    }

    public function getProductCardImg($product_image_data)
    {
        if ($product_image_data['hover']) {
            $prod_img = '
                <img class="top-image" alt="' . $product_image_data['title'] . '" src="' . $product_image_data['image'] . '"/>
                <img class="bottom-image" alt="' . $product_image_data['title'] . '" src="' . $product_image_data['hover'] . '" />
            ';
        } else {
            $prod_img = '<img alt="' . $product_image_data['title'] . '" src="' . $product_image_data['image'] . '"/>';
        }
        return $prod_img;
    }

    public function getProductCardSize($size)
    {
        if ($size) {
            return '<span class="product-size">' . $size . ' &#8226; </span>';
        } else {
            return '';
        }
    }

    public function getProductCardBrand($brand)
    {
        if ($brand) {
            return '<span class="product-brand"><strong>' . $brand . '</strong> &#8226; </span>';
        } else {
            return '';
        }
    }
    public function availibleOptions($categories_str, $options_names)
    {
        $options_values = [];

        foreach ($options_names as $option) {
            $meta_values = $this->_wpdb->get_results(
                "SELECT wp_postmeta.meta_value FROM wp_posts 
                LEFT JOIN wp_term_relationships ON (wp_posts.ID = wp_term_relationships.object_id) 
                LEFT JOIN wp_postmeta ON (wp_posts.ID = wp_postmeta.post_id and meta_key='" . $option . "')
                WHERE ( wp_term_relationships.term_taxonomy_id IN (" . $categories_str . ") ) 
                AND wp_posts.post_type = 'product' 
                AND ((wp_posts.post_status = 'publish'))
                AND meta_value is not null AND meta_value<>'None' AND meta_value<>''
                
                group by wp_postmeta.meta_value order by wp_postmeta.meta_value",
                ARRAY_A
            );
            $options_values[$option] = [];
            foreach ($meta_values as $meta_value) {
                $options_values[$option][] = $meta_value['meta_value'];
            }
        }

        return $options_values;
    }

    //All available colors for category, sorted by sort_order
    public function availibleColors($categories_str)
    {

        $sql = "SELECT wpm.meta_value as slug FROM wp_posts p 
        LEFT JOIN wp_posts ch ON p.ID=ch.post_parent 
        LEFT JOIN wp_term_relationships wtr ON wtr.object_id=p.ID 
        LEFT JOIN wp_term_taxonomy wtt ON wtt.term_taxonomy_id=wtr.term_taxonomy_id 

        LEFT JOIN wp_postmeta wpm ON wpm.post_id=ch.ID and wpm.meta_key='attribute_pa_color'

        WHERE 
        wtt.taxonomy='product_cat' AND 
        wtr.term_taxonomy_id IN (" . $categories_str . ") AND 
        p.post_status = 'publish' AND 
        wpm.meta_value is not null
        group by wpm.meta_value";

        //echo $sql;

        $meta_values = $this->_wpdb->get_results(
            $sql,
            ARRAY_A
        );


        $colors = [];
        foreach ($meta_values as $itm) {

            $slug = $itm['slug'];
            if (isset($this->_all_colors[$slug])) {
                $hex = $this->_all_colors[$slug]['color'];
                $class = $this->contrast_color($hex);

                //$this->contrast_color($this->_all_colors[$slug]['hex']);
                $colors[$slug] = array(
                    "slug"          => $slug,
                    "name"          => $this->_all_colors[$slug]['name'],
                    "hex"           => $hex,
                    "sort_order"    => $this->_all_colors[$slug]['sort_order'],
                    "term_id"       => $this->_all_colors[$slug]['id'],
                    "class"         => $class
                );
            }
            //$colors
            //$colors[$itm['slug']]=$itm;
            //$colors[$itm['slug']]["class"]=$this->contrast_color($itm['hex']);
        }

        if (isset($colors['color'])) {
            usort($colors, function ($item1, $item2) {
                return $item1['color']['sort_order'] <=> $item2['color']['sort_order'];
            });
            //$f_colors=[];
            //print_r($colors);
        }
        $f_colors = [];
        foreach ($colors as $color) {
            $f_colors[$color['slug']] = $color;
        }

        return $f_colors;
        //print_r($colors);
        //return $colors;
    }
    public function getVariantsQuantity($variants)
    {

        $quantity_data = [];

        if (is_array($variants)) {

            $variants_str = implode(",", $variants);
            //echo $variants_str;
            if ($variants_str) {
                $sql_inbound = "SELECT wi.product_id, wm.stock_quantity as inbound_stock FROM wp_atum_inventories wi
                LEFT JOIN wp_atum_inventory_meta wm ON wi.id = wm.inventory_id
                WHERE wi.product_id IN (" . $variants_str . ") and wi.priority = 1";
                //echo $sql_inbound;
                $meta_values = $this->_wpdb->get_results(
                    $sql_inbound,
                    ARRAY_A
                );
                //echo "!".$sql_inbound."!";

                //echo "select product_id, inbound_stock from wp_atum_product_data where product_id in (".$variants_str.")<br/>";
                foreach ($meta_values as $itm) {
                    $quantity_data[$itm["product_id"]]["inbound"] = $itm['inbound_stock'] * 1;
                }

                $meta_values = $this->_wpdb->get_results(
                    "select product_id, stock_quantity from wp_wc_product_meta_lookup where product_id in (" . $variants_str . ")",
                    ARRAY_A
                );

                foreach ($meta_values as $itm) {
                    $quantity_data[$itm['product_id']]["stock"] = $itm['stock_quantity'] * 1;
                }


                $meta_values = $this->_wpdb->get_results(
                    "SELECT post_id, meta_value FROM wp_postmeta WHERE meta_key='_manage_stock' and post_id in (" . $variants_str . ")",
                    ARRAY_A
                );
                foreach ($meta_values as $itm) {
                    $quantity_data[$itm['post_id']]["manage_stock"] = $itm['meta_value'];
                }

                $meta_values = $this->_wpdb->get_results(
                    "SELECT post_id, meta_value FROM wp_postmeta WHERE meta_key='_stock_status' and post_id in (" . $variants_str . ")",
                    ARRAY_A
                );
                foreach ($meta_values as $itm) {
                    $quantity_data[$itm['post_id']]["stock_status"] = $itm['meta_value'];
                }
            }
        }
        //echo '<pre>'; print_r($variants); echo '<pre>';
        return $quantity_data;
    }

    public function buildTree(array $elements, $parentId = 0)
    {
        $branch = array();

        foreach ($elements as $element) {
            if ($element['parent'] == $parentId) {
                $children = $this->buildTree($elements, $element['term_id']);
                if ($children) {
                    $element['children'] = $children;
                }
                $branch[] = $element;
            }
        }

        return $branch;
    }
    /*
    private function createTree( &$list, $parent ){
        $tree = array();
        foreach ( $parent as $k=>$l ){
            if( isset( $list[ $l[ 'term_id' ] ] ) ){
                $l[ 'children' ] = $this->createTree( $list, $list[ $l[ 'term_id' ] ] );
            }
            $tree[] = $l;
        } 
        return $tree;
    }
    */

    //Categories for accessories
    public function availibleCategoriesAccess($categories_str)
    {
        $sql = "SELECT pt_cat.term_id, pt_cat.parent, wt.name, wt.slug, IF(pt_cat.parent=0,0,1) as prnt_order 
            FROM wp_posts LEFT JOIN wp_term_relationships ON wp_posts.ID = wp_term_relationships.object_id 
            LEFT JOIN wp_term_relationships pcat ON wp_posts.ID = pcat.object_id 
            LEFT JOIN wp_term_taxonomy pt_cat ON pt_cat.term_taxonomy_id=pcat.term_taxonomy_id 
            LEFT JOIN wp_terms wt ON wt.term_id=pt_cat.term_id 
            LEFT JOIN wp_termmeta wtm ON (wtm.term_id=pt_cat.term_id AND wtm.meta_key='bold_category_sort_order') 
            WHERE ( wp_term_relationships.term_taxonomy_id IN (" . $categories_str . ") ) 
            AND wp_posts.post_type = 'product' 
            AND ((wp_posts.post_status = 'publish')) 
            AND pt_cat.taxonomy='product_cat' 
            GROUP BY pt_cat.term_id, pt_cat.parent, wtm.meta_value 
            ORDER BY prnt_order, CAST(wtm.meta_value as SIGNED), wt.name";

        $results = $this->_wpdb->get_results(
            $sql,
            ARRAY_A
        );

        /*
        $new = array();
        foreach ( $results as $a ){
            $new[ $a[ 'parent' ] ][] = $a;
        }
        */
        //$tree = $this->createTree( $new, array( $results[ 0 ] ) );
        $tree = $this->buildTree($results, 0);

        //print_r($tree);
        $tree['subcats'] = array(
            "Setting and hardware"  => 40801,
            "Training"              => 34175,
            "Brushes"               => 34345,
            "Chalk and skin care"   => 34342,
            "Apparel"               => 34351
        );

        return $tree;
    }

    public function getBrandedProducts()
    {
        $sql = "select ID from wp_posts wp 
        LEFT JOiN wp_postmeta wpm ON (wp.ID=wpm.post_id and wpm.meta_key = 'brading_options')
        where wp.post_status = 'publish'  and wp.post_type = 'product' and wpm.meta_value <>'' ORDER BY wp.menu_order ASC";
        $results = $this->_wpdb->get_results(
            $sql,
            ARRAY_A
        );
        return $results;
    }

    //Categories for category
    public function availibleCategories($categories_str)
    {

        /*
        $sql="SELECT pt_cat.term_id, pt_cat.parent, wt.name, wt.slug, IF(pt_cat.parent=0,0,1) as prnt_order
        FROM wp_posts 
        LEFT JOIN wp_term_relationships ON wp_posts.ID = wp_term_relationships.object_id
        LEFT JOIN wp_term_relationships pcat ON wp_posts.ID = pcat.object_id
        LEFT JOIN wp_term_taxonomy pt_cat ON pt_cat.term_taxonomy_id=pcat.term_taxonomy_id
        LEFT JOIN wp_terms wt ON wt.term_id=pt_cat.term_id
        WHERE ( wp_term_relationships.term_taxonomy_id IN (" . $categories_str . ") ) 
        AND wp_posts.post_type = 'product' 
        AND ((wp_posts.post_status = 'publish'))
        AND pt_cat.taxonomy='product_cat'
        group by pt_cat.term_id,pt_cat.parent order by prnt_order, wt.name";
/* 
        $sql = "SELECT pt_cat.term_id, pt_cat.parent, wt.name, wt.slug, IF(pt_cat.parent=0,0,1) as prnt_order 
            FROM wp_posts LEFT JOIN wp_term_relationships ON wp_posts.ID = wp_term_relationships.object_id 
            LEFT JOIN wp_term_relationships pcat ON wp_posts.ID = pcat.object_id 
            LEFT JOIN wp_term_taxonomy pt_cat ON pt_cat.term_taxonomy_id=pcat.term_taxonomy_id 
            LEFT JOIN wp_terms wt ON wt.term_id=pt_cat.term_id 
            LEFT JOIN wp_termmeta wtm ON (wtm.term_id=pt_cat.term_id AND wtm.meta_key='bold_category_sort_order') 
            WHERE ( wp_term_relationships.term_taxonomy_id IN (" . $categories_str . ") ) 
            AND wp_posts.post_type = 'product' 
            AND ((wp_posts.post_status = 'publish')) 
            AND pt_cat.taxonomy='product_cat' 
            GROUP BY pt_cat.term_id, pt_cat.parent, wtm.meta_value 
            ORDER BY prnt_order, CAST(wtm.meta_value as SIGNED), wt.name";
*/
        $sql = "SELECT pt_cat.term_id, pt_cat.parent, wt.name, wt.slug
            FROM wp_posts LEFT JOIN wp_term_relationships ON wp_posts.ID = wp_term_relationships.object_id 
            LEFT JOIN wp_term_relationships pcat ON wp_posts.ID = pcat.object_id 
            LEFT JOIN wp_term_taxonomy pt_cat ON pt_cat.term_taxonomy_id=pcat.term_taxonomy_id 
            LEFT JOIN wp_terms wt ON wt.term_id=pt_cat.term_id 
            LEFT JOIN wp_termmeta wtm ON (wtm.term_id=pt_cat.term_id AND wtm.meta_key='bold_category_sort_order') 
            WHERE ( wp_term_relationships.term_taxonomy_id IN (" . $categories_str . ") ) 
            AND wp_posts.post_type = 'product' 
            AND ((wp_posts.post_status = 'publish')) 
            AND pt_cat.taxonomy='product_cat' 
            GROUP BY pt_cat.term_id, pt_cat.parent, wtm.meta_value 
            ORDER BY wt.term_order";



        $results = $this->_wpdb->get_results(
            $sql,
            ARRAY_A
        );
        //print_r($sql);

        //LEFT JOIN wp_termmeta ON pt_cat.term_id=
        $new = array();
        /*
        foreach ( $results as $a ){
            $new[ $a[ 'parent' ] ][] = $a;
        }
        */
        /*
        $tree = $this->createTree( $new, array( $results[ 0 ] ) );
        */

        $tree = $this->buildTree($results, 0);
        return $tree;
    }
    public function getBrand($product_id)
    {
        $categories = get_the_terms($product_id, 'product_cat', true);

        //Tech 02-Nov-23
        $catnamearray = array();
        foreach ($categories as $category) {
            $catnamearray[] = $category->name;
        }
        if (in_array('Training', $catnamearray)) {
            $trainingBrand = get_post_meta($product_id, 'product_brand', true);

            return $trainingBrand;
        } else {
            foreach ($categories as $category) {
                if (isset($this->_all_brends[$category->term_taxonomy_id])) {
                    return $this->_all_brends[$category->term_taxonomy_id];
                }
            }
            return '';
        }
    }
    //Main category query
    public function get_products_args($data)
    {

        //page_number] => 1 [posts_per_page
        if ($this->isWholesaleUser) {
            $price_field = 'wholesale_customer_wholesale_price';
        } else {
            $price_field = '_regular_price';
        }


        $categories_str = implode(",", $data['categories_ids']);
        if (isset($data['subcat'])) {
            $subcat_array = [];
            foreach ($data['subcat'] as $subcat) {
                $subcat_str = get_post_meta($subcat, "bold_product_category_id", true);
                $temp = explode(",", $subcat_str);
                $subcat_array = array_merge($subcat_array, $temp);
            }
            if ($subcat_array) {
                $categories_str = implode(",", $subcat_array);
            }
        }

        // ---Get CatId---//
        $catID = $data['categories_ids'][0];

        //global $wpdb;
        $group[] = 'wp_posts.ID';

        //$join[] = "LEFT JOIN wp_term_relationships ON (wp_posts.ID = wp_term_relationships.object_id AND (wp_term_relationships.term_taxonomy_id IN (" . $categories_str . ")))";
        //$join[] = "LEFT JOIN wp_posts as wp_posts_variations ON (wp_posts_variations.post_parent=wp_posts.id AND wp_posts_variations.post_status='publish' AND wp_posts_variations.post_type='product_variation')";

        $join[] = "INNER JOIN wp_term_relationships ON (wp_posts.ID = wp_term_relationships.object_id AND (wp_term_relationships.term_taxonomy_id IN (" . $categories_str . ")))";
        $join[] = "LEFT JOIN wp_posts as wp_posts_variations ON (wp_posts_variations.post_parent=wp_posts.id AND wp_posts_variations.post_status='publish' AND wp_posts_variations.post_type='product_variation')";
        $join[] = "LEFT JOIN wp_postmeta AS meta_new ON (wp_posts.ID = meta_new.post_id AND (meta_new.meta_key = 'sale_discounted_item'))";

        $where[] = "(wp_posts.post_type='product')";
        $where[] = "(wp_posts.post_status = 'publish')";
        // $where[] = "(meta_new.meta_value <> 'Discounted' OR meta_new.meta_value IS NULL)";
        if (isset($data['page_type'])) {
            $page_type = $data['page_type'];
            if ($page_type == 'accessory') {
                $where[] = "(meta_new.meta_value = 'Discounted' OR meta_new.meta_value = 'Sale' OR meta_new.meta_value = '' OR meta_new.meta_value = 'None' OR meta_new.meta_value IS NULL)";
            } else {
                $where[] = "(meta_new.meta_value <> 'Discounted')";
            }
        } else {
            $where[] = "(meta_new.meta_value <> 'Discounted')";
        }



        //Filter by Brand, Line
        if (isset($data['cat'])) {
            $join[] = "INNER JOIN wp_term_relationships product_cat ON (wp_posts.ID = product_cat.object_id AND (product_cat.term_taxonomy_id in (" . implode(",", $data['cat']) . ")))";
            //$where[] = "(product_cat.term_taxonomy_id in (" . implode( ",", $data[ 'cat' ] ) . "))";
        }

        //Filter by New
        /*
        if( isset( $data[ 'new' ])){
            $join[] = "INNER JOIN wp_postmeta AS meta_new ON ( wp_posts.ID = meta_new.post_id AND (meta_new.meta_key = 'bold_product_year' AND meta_new.meta_value like '%" . date("Y") . "%' )) ";
            //$where[] = "(meta_new.meta_key = 'bold_product_year' AND meta_new.meta_value like '%" . date("Y") . "%' )";
        }
        */

        //option[new]

        if (isset($data['option']['new'])) {
            $join[] = "INNER JOIN wp_postmeta AS meta_new ON ( wp_posts.ID = meta_new.post_id AND (meta_new.meta_key = 'bold_product_year' AND meta_new.meta_value like '%" . date("Y") . "%' )) ";
            //$where[] = "(meta_new.meta_key = 'bold_product_year' AND meta_new.meta_value like '%" . date("Y") . "%' )";
        }

        //Filter by Type
        if (isset($data['product-type'])) {
            $type_str = implode(', ', array_map(function ($val) {
                return sprintf("'%s'", $val);
            }, $data['product-type']));
            $join[] = "INNER JOIN wp_postmeta AS meta_type ON ( wp_posts.ID = meta_type.post_id AND (meta_type.meta_key = 'bold_product_line_type' AND meta_type.meta_value IN (" . $type_str . ")))";
        }

        //Filter by Size
        if (isset($data['product-size'])) {
            //$str = implode(', ', array_map(function($val){return sprintf("'%s'", $val);}, $data['product-size']));
            $s_array = [];
            foreach ($data['product-size'] as $s_size) {
                switch ($s_size) {
                    case 'XS':
                    case 'X-Small':
                        $s_array[] = 'XS';
                        $s_array[] = 'X-Small';
                        break;

                    case 'S':
                    case 'Small':
                        $s_array[] = 'S';
                        $s_array[] = 'Small';
                        break;

                    case 'M':
                    case 'Medium':
                        $s_array[] = 'M';
                        $s_array[] = 'Medium';
                        break;

                    case 'L':
                    case 'Large':
                        $s_array[] = 'L';
                        $s_array[] = 'Large';
                        break;

                    case 'XL':
                    case 'X-Large':
                        $s_array[] = 'XL';
                        $s_array[] = 'X-Large';
                        break;

                    default:
                        $s_array[] = $s_size;
                }

                //$s_array[]
            }
            if ($s_array) {
                //$size_str = implode( ",", $s_array );
                $size_str = implode(', ', array_map(function ($val) {
                    return sprintf("'%s'", $val);
                }, $s_array));
                $join[] = "INNER JOIN wp_postmeta AS meta_size ON ( wp_posts.ID = meta_size.post_id AND (meta_size.meta_key = 'bold_product_size' AND meta_size.meta_value IN (" . $size_str . ")))";
                //$where[] = "(meta_size.meta_key = 'bold_product_size' AND meta_size.meta_value IN (" . $size_str . "))";
            }
        }

        //Options
        //Bolt-on
        $bolton_array = [];
        if (isset($data['option']['bolton'])) {
            $bolton_array[] = 'Yes';
        }
        //Screw-on
        if (isset($data['option']['screwon'])) {
            $bolton_array[] = 'No';
        }
        if ($bolton_array) {
            $str = implode(', ', array_map(function ($val) {
                return sprintf("'%s'", $val);
            }, $bolton_array));
            $join[] = "INNER JOIN wp_postmeta AS meta_bolt ON ( wp_posts.ID = meta_bolt.post_id AND (meta_bolt.meta_key = 'bold_product_bolt_on' AND meta_bolt.meta_value IN (" . $str . ")) )";
            //$where[] = "(meta_bolt.meta_key = 'bold_product_bolt_on' AND meta_bolt.meta_value IN (" . $str . "))";
        }

        //T-Nuts
        $tnuts_array = [];
        if (isset($data['option']['tnuts'])) {
            $tnuts_array[] = 'Yes';
        }
        //No T-Nuts
        if (isset($data['option']['notnuts'])) {
            $tnuts_array[] = 'No';
        }
        if ($tnuts_array) {
            $str = implode(', ', array_map(function ($val) {
                return sprintf("'%s'", $val);
            }, $tnuts_array));
            $join[] = "INNER JOIN wp_postmeta AS meta_tnuts ON ( wp_posts.ID = meta_tnuts.post_id AND (meta_tnuts.meta_key = 'bold_product_tnut' AND meta_tnuts.meta_value IN (" . $str . ")) )";
            //$where[] = "(meta_tnuts.meta_key = 'bold_product_tnut' AND meta_tnuts.meta_value IN (" . $str . "))";
        }

        //USAC Supplier
        if (isset($data['option']['usac'])) {
            $join[] = "INNER JOIN wp_postmeta AS meta_usac ON ( wp_posts.ID = meta_usac.post_id AND (meta_usac.meta_key = 'bold_product_usac' AND meta_usac.meta_value='Yes') )";
            //$where[] = "(meta_usac.meta_key = 'bold_product_usac' AND meta_usac.meta_value='Yes')";
        }
        //IFSC Supplier
        if (isset($data['option']['ifsc'])) {
            $join[] = "INNER JOIN wp_postmeta AS meta_ifsc ON ( wp_posts.ID = meta_ifsc.post_id AND (meta_ifsc.meta_key = 'bold_product_ifsc' AND meta_ifsc.meta_value='Yes') )";
            //$where[] = "(meta_ifsc.meta_key = 'bold_product_ifsc' AND meta_ifsc.meta_value='Yes')";
        }
        //Tokio Supplier
        if (isset($data['option']['tokyo'])) {
            $join[] = "INNER JOIN wp_postmeta AS meta_tokyo ON ( wp_posts.ID = meta_tokyo.post_id AND (meta_tokyo.meta_key = 'bold_product_tokyo' AND meta_tokyo.meta_value='Yes'))";
            //$where[] = "(meta_tokyo.meta_key = 'bold_product_tokyo' AND meta_tokyo.meta_value='Yes')";
        }
        //CBJ Grip List Award
        /*
        if(isset($data['option']['grip'])){
            $join[]="INNER JOIN wp_postmeta AS meta_grip ON ( wp_posts.ID = meta_grip.post_id )";
            $where[]="(meta_grip.meta_key = 'bold_product_grip_list' AND meta_grip.meta_value='Yes')";
        }
        */

        //Grip lists
        if (isset($data['grip'])) {
            $str = implode(', ', array_map(function ($val) {
                return sprintf("'%s'", $val);
            }, $data['grip']));
            $join[] = "INNER JOIN wp_postmeta AS meta_grip ON ( wp_posts.ID = meta_grip.post_id AND (meta_grip.meta_key = 'bold_product_grip_lists' AND meta_grip.meta_value IN (" . $str . ")))";

            //$where[] = "(meta_grip.meta_key = 'bold_product_grip_lists' AND meta_grip.meta_value IN (" . $str . "))";
        }

        //Produced by
        if (isset($data['prod'])) {
            $str = implode(', ', array_map(function ($val) {
                return sprintf("'%s'", $val);
            }, $data['prod']));
            $join[] = "INNER JOIN wp_postmeta AS meta_prod ON ( wp_posts.ID = meta_prod.post_id AND (meta_prod.meta_key = 'bold_product_manufacturer' AND meta_prod.meta_value IN (" . $str . ")))";
            //$where[] = "(meta_prod.meta_key = 'bold_product_manufacturer' AND meta_prod.meta_value IN (" . $str . "))";
        }

        //Filter by Colors
        if (isset($data['product-color'])) {

            $str = implode(', ', array_map(function ($val) {
                return sprintf("'%s'", $val);
            }, $data['product-color']));
            #$join[]="LEFT JOIN wp_term_relationships AS term_color ON (wp_posts.ID = term_color.object_id)";
            #$where[]="term_color.term_taxonomy_id IN (".$str.")";
            $join[] = "LEFT JOIN wp_postmeta color_meta ON (color_meta.post_id=wp_posts_variations.ID and color_meta.meta_key='attribute_pa_color')";
            $join[] = "INNER JOIN wp_terms wt_color ON (color_meta.meta_value=wt_color.slug AND wt_color.term_id in (" . $str . "))";
            //$where[] = "wt_color.term_id in (" . $str . ")";

            //$colors = get_related_colors($data['product-color']);
            //print_r($colors);
            /*
            $search_color_args =               
                array(
                    'taxonomy' => 'pa_color',                    
                    'field' => 'slug',   
                    'terms' => $data['product-color'],
                );      
            $search_args['tax_query'][] = $search_color_args;   
            */
        }


        if (isset($data['instock'])) {
            $join[] = "INNER JOIN wp_postmeta quantity_meta ON (quantity_meta.post_id=wp_posts_variations.ID and quantity_meta.meta_key='_stock' AND quantity_meta.meta_value>0)";
            //$where[] = "quantity_meta.meta_value>0";
        }
        if (isset($data['instock6'])) {
            $join[] = "LEFT JOIN wp_postmeta quantity_meta ON (quantity_meta.post_id=wp_posts_variations.ID and quantity_meta.meta_key='_stock' )";
            //$join[] = "LEFT JOIN wp_atum_product_data inbound ON (inbound.product_id=wp_posts_variations.ID AND inbound.inbound_stock>0)";
            //$join[] = "LEFT JOIN wp_atum_inventories inbound ON (inbound.product_id=wp_posts_variations.ID AND inbound.inbound_stock>0 and inbound.priority = 1)";
            //$join[] = "LEFT JOIN wp_atum_inventories wai ON (wai.product_id = wp_posts_variations.id and wai.priority = 1 )";

            $join[] = "LEFT JOIN wp_atum_inventories wai ON (wai.product_id = wp_posts_variations.id and wai.priority = 1)";
            $join[] = "LEFT JOIN wp_atum_inventory_meta wm ON (wai.id = wm.inventory_id)";


            $where[] = " (quantity_meta.meta_value>0 or wm.stock_quantity>0) ";

            /*
            "SELECT wi.product_id, wm.stock_quantity as inbound_stock FROM wp_atum_inventories wi
                LEFT JOIN wp_atum_inventory_meta wm ON wi.id = wm.inventory_id
                WHERE wi.product_id IN (" . $variants_str . ") and wi.priority = 1", 
                ARRAY_A 
                */
        }

        //Filter by Price
        $prices = [];
        if (isset($data['price-filter-min'])) {
            $prices["min"] = $data['price-filter-min'];
        }
        if (isset($data['price-filter-max'])) {
            $prices["max"] = $data['price-filter-max'];
        }

        if ($prices) {
            /*
            $join[]="INNER JOIN wp_wc_product_meta_lookup wp_lookup ON (wp_lookup.product_id=wp_posts.ID)";
            if(isset($prices["min"])){
                $where[]="(CAST(wp_lookup.min_price as SIGNED)>='".$prices["min"]."')";
            }
            if(isset($prices["max"])){
                $where[]="(CAST(wp_lookup.max_price as SIGNED)<='".$prices["max"]."')";
            }
            */

            /*
            $join[]="INNER JOIN wp_postmeta AS meta_price ON ( wp_posts_variations.ID = meta_price.post_id )";
            if(isset($prices["min"])){
                $where[]="(meta_price.meta_key = '".$price_field."' AND CAST(meta_price.meta_value AS SIGNED) >= '".$prices["min"]."')";
            }
            if(isset($prices["max"])){
                $where[]="(meta_price.meta_key = '".$price_field."' AND CAST(meta_price.meta_value AS SIGNED) <= '".$prices["max"]."')";
            }
            */

            $join[] = "LEFT JOIN wp_postmeta AS post_price ON ( wp_posts.ID = post_price.post_id AND post_price.meta_key = '" . $price_field . "')";
            $join[] = "LEFT JOIN wp_postmeta AS variations_price ON ( wp_posts_variations.ID = variations_price.post_id AND variations_price.meta_key = '" . $price_field . "')";

            //----Uninstall plugging currency 			
            // $currencies=$this->_WOOCS->get_currencies();
            //  $currency_rate = $currencies[ $this->_WOOCS->current_currency ][ 'rate' ];
            // if( !$currency_rate ){
            //  $currency_rate = 1;
            // }
            $currency_rate = 1;
            if (isset($prices["min"])) {
                $prices_min = $prices["min"] / $currency_rate;
                $where[] = "( CAST(post_price.meta_value as SIGNED) >= '" . $prices_min . "' OR CAST(variations_price.meta_value as SIGNED) >= '" . $prices_min . "' )";
            }
            if (isset($prices["max"])) {
                $prices_max = $prices["max"] / $currency_rate;

                $where[] = "( CAST(post_price.meta_value as SIGNED) <= '" . $prices_max . "' OR CAST(variations_price.meta_value as SIGNED) <= '" . $prices_max . "' )";
            }
        }

        //Sorting
        $orderby = "wp_posts.menu_order ASC";
        if (isset($data['sort-by'])) {
            switch ($data['sort-by']) {
                case 'line':
                    $join[] = "INNER JOIN wp_postmeta AS meta_line ON ( wp_posts.ID = meta_line.post_id AND meta_line.meta_key = 'position') ";
                    //$where[] = "(wp_postmeta.meta_key = 'bold_product_line')";
                    $orderby = "CAST(meta_line.meta_value as unsigned) ASC";
                    //$orderby = "wp_postmeta.meta_value ASC";
                    break;
                    // case 'a-z':
                    //     $orderby = "wp_posts.post_title ASC";
                    // break;
                case 'position':
                    $join[] = "LEFT JOIN wp_postmeta AS post_meta ON ( wp_posts.ID = post_meta.post_id AND post_meta.meta_key = 'position_line')";
                    $orderby = "CAST(post_meta.meta_value as unsigned) ASC";
                    //$orderby = "(CAST(post_meta.meta_value AS UNSIGNED)+ 0) ASC";
                    //$orderby = "(CAST(post_meta.meta_value AS SIGNED) + 0) ASC";
                    break;

                case 'price':
                    /*$join[]="INNER JOIN wp_postmeta AS meta_sort_price ON ( wp_posts_variations.ID = meta_sort_price.post_id )";
                    $where[]="(meta_sort_price.meta_key = '".$price_field."')";
                    $orderby="CAST(meta_sort_price.meta_value AS SIGNED) ASC";
                    */
                    $join[] = "LEFT JOIN wp_postmeta AS post_price_order ON ( wp_posts.ID = post_price_order.post_id AND post_price_order.meta_key = '" . $price_field . "')";
                    $join[] = "LEFT JOIN wp_postmeta AS variations_price_order ON ( wp_posts_variations.ID = variations_price_order.post_id AND variations_price_order.meta_key = '" . $price_field . "')";
                    $orderby = "CAST(post_price_order.meta_value AS SIGNED) ASC, CAST(variations_price_order.meta_value AS SIGNED) ASC";
                    break;

                case 'popularity':
                    //post_views
                    $join[] = "LEFT JOIN wp_postmeta AS meta_viewcount ON ( wp_posts.ID = meta_viewcount.post_id AND meta_viewcount.meta_key='post_views')";
                    $group[] = "meta_viewcount.meta_value";
                    $orderby = "CAST(meta_viewcount.meta_value AS SIGNED) DESC";

                    break;

                case 'date':
                    $join[] = "LEFT JOIN wp_postmeta AS product_year ON ( wp_posts.ID = product_year.post_id AND product_year.meta_key = 'bold_product_year')";
                    $orderby = 'STR_TO_DATE(product_year.meta_value, "%Y-%m-%d") DESC';
                    break;
            }
        } else {
            // ---- default Filtter based on category----/
            if ($catID == '211' or $catID == '249') {
                $join[] = "LEFT JOIN wp_postmeta AS post_meta ON ( wp_posts.ID = post_meta.post_id AND post_meta.meta_key = 'position_line')";
                $orderby = "CAST(post_meta.meta_value as unsigned) ASC";
            }
            if ($catID == '229') {
                $join[] = "INNER JOIN wp_postmeta AS meta_line ON ( wp_posts.ID = meta_line.post_id AND meta_line.meta_key = 'position') ";
                $orderby = "CAST(meta_line.meta_value as unsigned) ASC";
            }
        }


        $q  = 'SELECT SQL_CALC_FOUND_ROWS wp_posts.ID ';
        $q .= ' FROM wp_posts ' . implode(" ", $join);

        $q .= ' where ' . implode(" AND ", $where);


        $q .= ' GROUP BY ' . implode(", ", $group);;
        //$q .=' GROUP BY wp_posts.ID';

        $q .= ' ORDER BY ' . $orderby;


        if (isset($data['posts_per_page']) and $data['posts_per_page']) {
            if ($data['posts_diff'] != '') {
                $q .= ' LIMIT ' . ($data['posts_per_page'] * $data['page_number'] - $data['posts_per_page'] - $data['posts_diff']) . ', ' . $data['posts_per_page'];
            } else {
                $q .= ' LIMIT ' . ($data['posts_per_page'] * $data['page_number'] - $data['posts_per_page']) . ', ' . $data['posts_per_page'];
            }
            //$q .= ' LIMIT ' . ( $data[ 'posts_per_page' ] * $data[ 'page_number' ] - $data[ 'posts_per_page' ] ) . ', ' . $data[ 'posts_per_page' ];
        }
        // if( isset( $data[ 'posts_per_page' ] ) and $data[ 'posts_per_page' ] ){
        //     $q .= ' LIMIT ' . ( $data[ 'posts_per_page' ] * $data[ 'page_number' ] - $data[ 'posts_per_page' ] ) . ', ' . $data[ 'posts_per_page' ];
        // }




        // echo $q;

        $out[0]   = $this->_wpdb->get_results($q, ARRAY_A);
        $count_rows = $this->_wpdb->get_var("SELECT FOUND_ROWS();");
        if (isset($data['posts_per_page']) and $data['posts_per_page']) {
            $out[1]   = ceil($count_rows / $data['posts_per_page']);
        } else {
            $out[1]   = 1;
        }

        return $out;
    }

    // Main Category product discount query
    public function get_products_discountargs($data)
    {

        //page_number] => 1 [posts_per_page
        if ($this->isWholesaleUser) {
            $price_field = 'wholesale_customer_wholesale_price';
        } else {
            $price_field = '_regular_price';
        }


        $categories_str = implode(",", $data['categories_ids']);
        if (isset($data['subcat'])) {
            $subcat_array = [];
            foreach ($data['subcat'] as $subcat) {
                $subcat_str = get_post_meta($subcat, "bold_product_category_id", true);
                $temp = explode(",", $subcat_str);
                $subcat_array = array_merge($subcat_array, $temp);
            }
            if ($subcat_array) {
                $categories_str = implode(",", $subcat_array);
            }
        }
        // ---Get CatId---//
        $catID = $data['categories_ids'][0];

        //global $wpdb;
        $group[] = 'wp_posts.ID';
        $join[] = "INNER JOIN wp_term_relationships ON (wp_posts.ID = wp_term_relationships.object_id AND (wp_term_relationships.term_taxonomy_id IN (" . $categories_str . ")))";
        $join[] = "LEFT JOIN wp_posts as wp_posts_variations ON (wp_posts_variations.post_parent = wp_posts.id AND wp_posts_variations.post_status = 'publish' AND wp_posts_variations.post_type = 'product_variation')";
        $join[] = "INNER JOIN wp_postmeta AS meta_new ON (wp_posts.ID = meta_new.post_id AND (meta_new.meta_key = 'sale_discounted_item'))";

        $join[] = "LEFT JOIN wp_postmeta quantity_meta ON (quantity_meta.post_id = wp_posts_variations.ID AND quantity_meta.meta_key = '_stock')";

        // Where conditions
        $where[] = "(wp_posts.post_type = 'product')";
        $where[] = "(wp_posts.post_status = 'publish')";
        $where[] = "(meta_new.meta_value = 'Sale' OR (meta_new.meta_value = 'Discounted' AND quantity_meta.meta_value > 0))";



        //global $wpdb;
        /*
        $group[] = 'wp_posts.ID';
        $join[] = "INNER JOIN wp_term_relationships ON (wp_posts.ID = wp_term_relationships.object_id AND (wp_term_relationships.term_taxonomy_id IN (" . $categories_str . ")))";
        $join[] = "LEFT JOIN wp_posts as wp_posts_variations ON (wp_posts_variations.post_parent=wp_posts.id AND wp_posts_variations.post_status='publish' AND wp_posts_variations.post_type='product_variation')";
        $join[] = "INNER JOIN wp_postmeta AS meta_new ON ( wp_posts.ID = meta_new.post_id AND (meta_new.meta_key = 'sale_discounted_item' AND meta_new.meta_value = 'Discounted'  OR meta_new.meta_value = 'Sale')) ";
        $join[] = "INNER JOIN wp_postmeta quantity_meta ON (quantity_meta.post_id=wp_posts_variations.ID and quantity_meta.meta_key='_stock' AND quantity_meta.meta_value>0) ";
        

        $where[] = "(wp_posts.post_type='product')";
        $where[] = "(wp_posts.post_status = 'publish')";
        */

        //Filter by Brand, Line
        if (isset($data['cat'])) {
            $join[] = "INNER JOIN wp_term_relationships product_cat ON (wp_posts.ID = product_cat.object_id AND (product_cat.term_taxonomy_id in (" . implode(",", $data['cat']) . ")))";
        }

        if (isset($data['option']['new'])) {
            $join[] = "INNER JOIN wp_postmeta AS meta_new ON ( wp_posts.ID = meta_new.post_id AND (meta_new.meta_key = 'bold_product_year' AND meta_new.meta_value like '%" . date("Y") . "%' )) ";
        }

        //Filter by Type
        if (isset($data['product-type'])) {
            $type_str = implode(', ', array_map(function ($val) {
                return sprintf("'%s'", $val);
            }, $data['product-type']));
            $join[] = "INNER JOIN wp_postmeta AS meta_type ON ( wp_posts.ID = meta_type.post_id AND (meta_type.meta_key = 'bold_product_line_type' AND meta_type.meta_value IN (" . $type_str . ")))";
        }

        //Filter by Size
        if (isset($data['product-size'])) {

            $s_array = [];
            foreach ($data['product-size'] as $s_size) {
                switch ($s_size) {
                    case 'XS':
                    case 'X-Small':
                        $s_array[] = 'XS';
                        $s_array[] = 'X-Small';
                        break;

                    case 'S':
                    case 'Small':
                        $s_array[] = 'S';
                        $s_array[] = 'Small';
                        break;

                    case 'M':
                    case 'Medium':
                        $s_array[] = 'M';
                        $s_array[] = 'Medium';
                        break;

                    case 'L':
                    case 'Large':
                        $s_array[] = 'L';
                        $s_array[] = 'Large';
                        break;

                    case 'XL':
                    case 'X-Large':
                        $s_array[] = 'XL';
                        $s_array[] = 'X-Large';
                        break;

                    default:
                        $s_array[] = $s_size;
                }

                //$s_array[]
            }
            if ($s_array) {
                $size_str = implode(', ', array_map(function ($val) {
                    return sprintf("'%s'", $val);
                }, $s_array));
                $join[] = "INNER JOIN wp_postmeta AS meta_size ON ( wp_posts.ID = meta_size.post_id AND (meta_size.meta_key = 'bold_product_size' AND meta_size.meta_value IN (" . $size_str . ")))";
            }
        }

        //Options
        //Bolt-on
        $bolton_array = [];
        if (isset($data['option']['bolton'])) {
            $bolton_array[] = 'Yes';
        }
        //Screw-on
        if (isset($data['option']['screwon'])) {
            $bolton_array[] = 'No';
        }
        if ($bolton_array) {
            $str = implode(', ', array_map(function ($val) {
                return sprintf("'%s'", $val);
            }, $bolton_array));
            $join[] = "INNER JOIN wp_postmeta AS meta_bolt ON ( wp_posts.ID = meta_bolt.post_id AND (meta_bolt.meta_key = 'bold_product_bolt_on' AND meta_bolt.meta_value IN (" . $str . ")) )";
        }

        //T-Nuts
        $tnuts_array = [];
        if (isset($data['option']['tnuts'])) {
            $tnuts_array[] = 'Yes';
        }
        //No T-Nuts
        if (isset($data['option']['notnuts'])) {
            $tnuts_array[] = 'No';
        }
        if ($tnuts_array) {
            $str = implode(', ', array_map(function ($val) {
                return sprintf("'%s'", $val);
            }, $tnuts_array));
            $join[] = "INNER JOIN wp_postmeta AS meta_tnuts ON ( wp_posts.ID = meta_tnuts.post_id AND (meta_tnuts.meta_key = 'bold_product_tnut' AND meta_tnuts.meta_value IN (" . $str . ")) )";
        }

        //USAC Supplier
        if (isset($data['option']['usac'])) {
            $join[] = "INNER JOIN wp_postmeta AS meta_usac ON ( wp_posts.ID = meta_usac.post_id AND (meta_usac.meta_key = 'bold_product_usac' AND meta_usac.meta_value='Yes') )";
        }
        //IFSC Supplier
        if (isset($data['option']['ifsc'])) {
            $join[] = "INNER JOIN wp_postmeta AS meta_ifsc ON ( wp_posts.ID = meta_ifsc.post_id AND (meta_ifsc.meta_key = 'bold_product_ifsc' AND meta_ifsc.meta_value='Yes') )";
        }
        //Tokio Supplier
        if (isset($data['option']['tokyo'])) {
            $join[] = "INNER JOIN wp_postmeta AS meta_tokyo ON ( wp_posts.ID = meta_tokyo.post_id AND (meta_tokyo.meta_key = 'bold_product_tokyo' AND meta_tokyo.meta_value='Yes'))";
        }

        //Grip lists
        if (isset($data['grip'])) {
            $str = implode(', ', array_map(function ($val) {
                return sprintf("'%s'", $val);
            }, $data['grip']));
            $join[] = "INNER JOIN wp_postmeta AS meta_grip ON ( wp_posts.ID = meta_grip.post_id AND (meta_grip.meta_key = 'bold_product_grip_lists' AND meta_grip.meta_value IN (" . $str . ")))";
        }

        //Produced by
        if (isset($data['prod'])) {
            $str = implode(', ', array_map(function ($val) {
                return sprintf("'%s'", $val);
            }, $data['prod']));
            $join[] = "INNER JOIN wp_postmeta AS meta_prod ON ( wp_posts.ID = meta_prod.post_id AND (meta_prod.meta_key = 'bold_product_manufacturer' AND meta_prod.meta_value IN (" . $str . ")))";
        }

        //Filter by Colors
        if (isset($data['product-color'])) {

            $str = implode(', ', array_map(function ($val) {
                return sprintf("'%s'", $val);
            }, $data['product-color']));
            $join[] = "LEFT JOIN wp_postmeta color_meta ON (color_meta.post_id=wp_posts_variations.ID and color_meta.meta_key='attribute_pa_color')";
            $join[] = "INNER JOIN wp_terms wt_color ON (color_meta.meta_value=wt_color.slug AND wt_color.term_id in (" . $str . "))";
        }


        if (isset($data['instock'])) {
            $join[] = "INNER JOIN wp_postmeta quantity_meta ON (quantity_meta.post_id=wp_posts_variations.ID and quantity_meta.meta_key='_stock' AND quantity_meta.meta_value>0)";
        }
        if (isset($data['instock6'])) {
            $join[] = "LEFT JOIN wp_postmeta quantity_meta ON (quantity_meta.post_id=wp_posts_variations.ID and quantity_meta.meta_key='_stock' )";

            $join[] = "LEFT JOIN wp_atum_inventories wai ON (wai.product_id = wp_posts_variations.id and wai.priority = 1)";
            $join[] = "LEFT JOIN wp_atum_inventory_meta wm ON (wai.id = wm.inventory_id)";


            $where[] = " (quantity_meta.meta_value>0 or wm.stock_quantity>0) ";
        }

        //Filter by Price
        $prices = [];
        if (isset($data['price-filter-min'])) {
            $prices["min"] = $data['price-filter-min'];
        }
        if (isset($data['price-filter-max'])) {
            $prices["max"] = $data['price-filter-max'];
        }

        if ($prices) {
            $join[] = "LEFT JOIN wp_postmeta AS post_price ON ( wp_posts.ID = post_price.post_id AND post_price.meta_key = '" . $price_field . "')";
            $join[] = "LEFT JOIN wp_postmeta AS variations_price ON ( wp_posts_variations.ID = variations_price.post_id AND variations_price.meta_key = '" . $price_field . "')";
            // ----Uninstall plugging currency
            // $currencies=$this->_WOOCS->get_currencies();
            // $currency_rate = $currencies[ $this->_WOOCS->current_currency ][ 'rate' ];
            // if( !$currency_rate ){
            // $currency_rate = 1;
            //  }

            $currency_rate = 1;

            if (isset($prices["min"])) {
                $prices_min = $prices["min"] / $currency_rate;
                $where[] = "( CAST(post_price.meta_value as SIGNED) >= '" . $prices_min . "' OR CAST(variations_price.meta_value as SIGNED) >= '" . $prices_min . "' )";
            }
            if (isset($prices["max"])) {
                $prices_max = $prices["max"] / $currency_rate;

                $where[] = "( CAST(post_price.meta_value as SIGNED) <= '" . $prices_max . "' OR CAST(variations_price.meta_value as SIGNED) <= '" . $prices_max . "' )";
            }
        }

        //Sorting
        $orderby = "wp_posts.menu_order ASC";
        if (isset($data['sort-by'])) {
            switch ($data['sort-by']) {
                case 'line':
                    $join[] = "INNER JOIN wp_postmeta AS meta_line ON ( wp_posts.ID = meta_line.post_id AND meta_line.meta_key = 'position') ";
                    $orderby = "CAST(meta_line.meta_value as unsigned) ASC";
                    break;

                case 'position':
                    $join[] = "LEFT JOIN wp_postmeta AS post_meta ON ( wp_posts.ID = post_meta.post_id AND post_meta.meta_key = 'position_line')";
                    $orderby = "CAST(post_meta.meta_value as unsigned) ASC";
                    break;

                case 'price':

                    $join[] = "LEFT JOIN wp_postmeta AS post_price_order ON ( wp_posts.ID = post_price_order.post_id AND post_price_order.meta_key = '" . $price_field . "')";
                    $join[] = "LEFT JOIN wp_postmeta AS variations_price_order ON ( wp_posts_variations.ID = variations_price_order.post_id AND variations_price_order.meta_key = '" . $price_field . "')";
                    $orderby = "CAST(post_price_order.meta_value AS SIGNED) ASC, CAST(variations_price_order.meta_value AS SIGNED) ASC";
                    break;

                case 'popularity':
                    //post_views
                    $join[] = "LEFT JOIN wp_postmeta AS meta_viewcount ON ( wp_posts.ID = meta_viewcount.post_id AND meta_viewcount.meta_key='post_views')";
                    $group[] = "meta_viewcount.meta_value";
                    $orderby = "CAST(meta_viewcount.meta_value AS SIGNED) DESC";

                    break;

                case 'date':
                    $join[] = "LEFT JOIN wp_postmeta AS product_year ON ( wp_posts.ID = product_year.post_id AND product_year.meta_key = 'bold_product_year')";
                    $orderby = 'STR_TO_DATE(product_year.meta_value, "%Y-%m-%d") DESC';
                    break;
            }
        } else {
            // ---- default Filtter based on category----/
            if ($catID == '211' or $catID == '249') {
                $join[] = "LEFT JOIN wp_postmeta AS post_meta ON ( wp_posts.ID = post_meta.post_id AND post_meta.meta_key = 'position_line')";
                $orderby = "CAST(post_meta.meta_value as unsigned) ASC";
            }
            if ($catID == '229') {
                $join[] = "INNER JOIN wp_postmeta AS meta_line ON ( wp_posts.ID = meta_line.post_id AND meta_line.meta_key = 'position') ";
                $orderby = "CAST(meta_line.meta_value as unsigned) ASC";
            }
        }


        $q  = 'SELECT SQL_CALC_FOUND_ROWS wp_posts.ID ';
        $q .= ' FROM wp_posts ' . implode(" ", $join);

        $q .= ' where ' . implode(" AND ", $where);


        $q .= ' GROUP BY ' . implode(", ", $group);
        //$q .=' GROUP BY wp_posts.ID';

        $q .= ' ORDER BY ' . $orderby;

        if (isset($data['posts_per_page']) and $data['posts_per_page']) {
            $q .= ' LIMIT ' . ($data['posts_per_page'] * $data['page_number'] - $data['posts_per_page']) . ', ' . $data['posts_per_page'];
        }




        // echo $q;

        $out[0]   = $this->_wpdb->get_results($q, ARRAY_A);
        $count_rows = $this->_wpdb->get_var("SELECT FOUND_ROWS();");
        if (isset($data['posts_per_page']) and $data['posts_per_page']) {
            $out[1]   = ceil($count_rows / $data['posts_per_page']);
        } else {
            $out[1]   = 1;
        }

        return $out;
    }



    public function getWholesalePrices($product_id)
    {

        $q = "SELECT min(pm.meta_value*1) as min, max(pm.meta_value*1) as max FROM wp_posts p 
        LEFT JOIN wp_postmeta pm ON pm.post_id=p.ID and pm.meta_key='wholesale_customer_wholesale_price'
        where p.post_parent=" . $product_id . " and pm.meta_value>0 and p.post_status='publish'";

        $rezult = $this->_wpdb->get_results($q, ARRAY_A);
        return $rezult[0];
    }

    public function getProduct($product_id)
    {

        $_product       = wc_get_product($product_id);
        $product_title  = $_product->get_title();
        $product_link   = get_permalink($product_id);

        $colortable_text = "";

        $add_button     = "";
        $t_table        = "";
        $variant_type   = "";
        $pack           = [];
        $categories     = get_the_terms($product_id, 'product_cat');
        $categories_ids = wp_list_pluck($categories, 'term_id');

        $shipping_info = "";
        foreach ($categories_ids as $category_id) {
            if (isset($this->_shipping_info[$category_id])) {
                $shipping_info = $this->_shipping_info[$category_id];
            }
        }


        switch ($_product->get_type()) {
            case 'variable':
                $options_variation = [];
                $count_item = false;

                sort($categories_ids);

                $standart_caption   = 'Standard';
                $dual_caption       = 'Dual Tex';


                foreach ($categories_ids as $category_id) {
                    //echo $this->_captions[ $category_id ][ 'standart' ];
                    if (isset($this->_captions[$category_id]['standart'])) {

                        if ($this->_captions[$category_id]['standart']) {
                            $standart_caption = $this->_captions[$category_id]['standart'];
                        }
                    }
                    if (isset($this->_captions[$category_id]['dual'])) {
                        if ($this->_captions[$category_id]['dual']) {
                            $dual_caption = $this->_captions[$category_id]['dual'];
                        }
                    }
                    if (isset($this->_captions[$category_id]['colortable'])) {
                        if ($this->_captions[$category_id]['colortable']) {
                            $colortable_text = $this->_captions[$category_id]['colortable'];
                        }
                    }
                }

                $product_captions = array(
                    'standart'  => $standart_caption,
                    'dual'      => $dual_caption
                );
                /* Gaurav 25 Aug 2023 */
                $available_stock_date = get_post_meta($product_id, 'instock_date', true);
                $product_captions['instock_date'] = $available_stock_date;
                $product_captions['product_id'] = $product_id;
                /* The End */

                //All attibutes of Product
                foreach ($_product->get_attributes() as $attr) {
                    $type_variation = $attr->get_name();
                    $options_variation[$attr->get_name()] = $attr['options'];
                }

                $min_price = $max_price = 0;

                if (isset($options_variation['pa_color'])) {  //Variation by color
                    $variant_type = "color";
                    $variant_ids = $_product->get_children(false);
                    // Tech 02-Nov-23
                    if ($variant_ids) {
                    } else {
                        $qr = "SELECT ID FROM wp_posts WHERE post_parent = '" . $product_id . "' && post_type='product_variation'";
                        $result = $this->_wpdb->get_results($qr, ARRAY_A);
                        foreach ($result as $value) {
                            $variant_ids[] = $value['ID'];
                        }
                    }

                    /*
                    $childrens = get_children( [
                        'post_parent' => $product_id,
                        'post_type'   => 'product_',
                        'numberposts' => -1,
                        'post_status' => 'any'
                    ] );
                    
                    print_r($childrens);
                    */

                    $quantity_data = $this->getVariantsQuantity($variant_ids);
                    $prices_var = [];


                    foreach ($variant_ids as $variant_id) {
                        $color_slug = get_post_meta($variant_id, 'attribute_pa_color', true);

                        $variants[] = array(
                            "product_id" => $product_id,
                            "variation_id"  => $variant_id,
                            "color"         => $this->_all_colors[$color_slug],
                            "in_stock"      => (isset($quantity_data[$variant_id]['stock'])) ? $quantity_data[$variant_id]['stock'] : "",
                            "in_stock6"     => (isset($quantity_data[$variant_id]['inbound'])) ? $quantity_data[$variant_id]['inbound'] : "",
                        );
                    }

                    // echo '<pre>'; print_r($product_captions); echo '<pre>';
                    //$t_table=$this->_BoldHelper->getColorTableProduct($product_colors_list, $variant_id, $stock_data);
                    //$t_table = $this->getColorTableProduct( $variants, $_product->get_manage_stock(), $product_captions );

                    //print_r( $this->getAtumControlled( $product_id ) );

                    $atum_controlled = $this->getAtumControlled($product_id);
                    $t_table = $this->getColorTableProduct($variants, $atum_controlled, $product_captions);

                    $add_button = '<a data-id="' . $product_id . '" class="add-to-cart-btn add-to-cart-trigger" href="#">Add to Cart</a>';

                    //if (in_array('wholesale_customer', $this->_userRoles)){

                    if ($this->isWholesaleUser) {
                        $wholesale_prices = $this->getWholesalePrices($product_id);
                        //$min_price = $max_price = $this->_WOOCS->woocs_exchange_value( $wholesale_prices[ 'min' ] );
                        $min_price = $max_price = $wholesale_prices['min'];

                        //$max_price = $wholesale_prices[ 'max' ];
                    } else {

                        //echo "!variation_regular_price=".$_product->get_variation_regular_price( 'min' )."!<br/>";

                        //print_r($_product->product_custom_fields);

                        //$min_price = $max_price = $this->_WOOCS->woocs_exchange_value( $_product->get_variation_regular_price( 'min' ) );
                        $min_price = $max_price = $_product->get_variation_regular_price('min');
                        //$max_price = $_product->get_variation_regular_price( 'max' );
                    }
                } elseif (isset($options_variation['pack'])) { //Variation by pack
                    $variant_type = "pack";
                    //TODO
                    //foreach ($_product->get_children() as $variant_id){

                    //}
                    $variations = $_product->get_available_variations();
                    $variations_id = wp_list_pluck($variations, 'variation_id');
                    $str = '';

                    $n_pp = 0;
                    foreach ($variations as $key => $variation) {
                        $pack_str = $variation['attributes']['attribute_pack'];
                        $pack_cnt = (int)$pack_str;
                        //echo "pack_cnt=".$pack_cnt."<br/>";


                        if ($this->isWholesaleUser) {
                            //print_r($variation);                            
                            //$price = get_post_meta($variations_id[$key],'wholesale_customer_wholesale_price',true);
                            /*
                            if($variations_id[$key]){
                                $price = get_post_meta($variations_id[$key],'wholesale_customer_wholesale_price',true);
                            }else{
                                $price = 0;
                            }
                            */
                            //echo "!".$variations_id[$key]."=".get_post_meta($variations_id[$key],'wholesale_customer_wholesale_price',true)."!<br/>";
                            //$price = get_post_meta($variations_id[$key],'wholesale_customer_wholesale_price',true) * 1;
                            $price_gt = get_post_meta($variations_id[$key], 'wholesale_customer_wholesale_price', true);
                            if ($price_gt) {
                                $price = $price_gt * 1;

                                //$price = $this->_WOOCS->woocs_exchange_value( $price_gt );
                            } else {
                                $price = $variation['display_price'] * 1;
                            }
                            //$price = 10;
                            //$price=$variation['display_price'];
                        } else {
                            //$price = $variation[ 'display_price' ];
                            $price = $variation['display_price'];
                        }


                        if (!$key || $this->isWholesaleUser) {


                            //$formatted_price = number_format( $price / $pack_cnt, 2, ".", "," );

                            //$formatted_price = wc_price( $this->_WOOCS->woocs_exchange_value( $price ) / $pack_cnt );

                            $formatted_price =  wc_price($price);
                            $formatted_amount =  wc_price($price / $pack_cnt);

                            // Getch20July2024
                            $sale_discount_item = get_post_meta($product_id, 'sale_discounted_item', true);
                            if ($this->isWholesaleUser) {
                                if ($sale_discount_item == 'Discounted' || $sale_discount_item == 'Sale') {
                                    $discount_cost = get_post_meta(get_the_ID(), 'discount_wholesale_cost', true);
                                    if ($discount_cost) {
                                        $force_discount = $discount_cost * $price / 100;
                                        $discounted_wprice = $price - $force_discount;
                                        $_price = $discounted_wprice;
                                        $_amount =  wc_price($_price / $pack_cnt);
                                        $formatted_amount = '<del style=" margin-right: 4px;" > ' . $formatted_amount . '</del>' . $_amount;
                                        $formatted_price =  wc_price($_price);
                                        //$formatted_price = '<del style=" margin-right: 4px;" > ' . $formatted_price . '</del>'.wc_price($_price);
                                    }
                                }
                            } else {
                                if ($sale_discount_item == 'Discounted' || $sale_discount_item == 'Sale') {
                                    $discount_cost = get_post_meta(get_the_ID(), 'discount_retail_cost', true);
                                    if ($discount_cost) {
                                        $force_discount = $discount_cost * $price / 100;
                                        $discounted_wprice = $price - $force_discount;
                                        $_price = $discounted_wprice;
                                        $_amount =  wc_price($_price / $pack_cnt);
                                        $formatted_amount = '<del style=" margin-right: 4px;" > ' . $formatted_amount . '</del>' . $_amount;
                                        $formatted_price = wc_price($_price);
                                        //$formatted_price = '<del style=" margin-right: 4px;" > ' . $formatted_price . '</del>'.wc_price($_price);
                                    }
                                }
                            }

                            $pack[$n_pp] = array(
                                "price"         => $price,
                                "count"         => $pack_cnt,
                                "variant_id"    => $variations_id[$key]
                            );

                            $str .= '<div class="pack_col">
                                <div class="pack_col_caption">' . $variation['attributes']['attribute_pack'] . '</div>
                                <div class="wrap_pack_captions">
                                    <div class="pack_input_col">
                                        <div class="pack_input_caption">Price</div>
                                        <div class="pack_input_val">' . $formatted_amount . '</div>
                                    </div>
                                    ' . ($key > 0 ? '
                                    <div class="pack_input_col">
                                        <div class="pack_input_caption">Total</div>
                                        <div class="pack_input_val">' . $formatted_price . '</div> 
                                    </div>' : '') . '
                                    <div class="pack_input_col">
                                        <div class="pack_input_caption">Order</div>
                                        <div class="pack_input_val"><input class="count_pack" data-variation_id="' . $variations_id[$key] . '" data-count="' . $key . '" value="' . ($key > 0 ? 0 : 1) . '" step="1" min="0" max="10" type="number" name=""/></div>
                                    </div>
                                </div>
                            </div>';
                        }
                        $n_pp++;
                    }
                    if ($str) {
                        $t_table = '<div class="product-sheet">
                            <div class="wrap_pack">
                                <div class="wrapper_pack">' . $str . '</div>
                            </div>
                        </div>';
                    }
                    $add_button = '<a data-id="' . $product_id . '" class="pack_btn_add add-to-cart-btn add-to-cart-trigger" href="#">Add to Cart</a>';
                    if ($this->isWholesaleUser) {
                        $wholesale_prices = $this->getWholesalePrices($product_id);
                        $min_price = $wholesale_prices['min'];
                        $max_price = $wholesale_prices['max'];
                    } else {
                        $min_price = $_product->get_variation_regular_price('min');
                        $max_price = $min_price;
                        //$max_price=$_product->get_variation_regular_price('max');
                    }

                    /* 
                    $add_button = '<div class="wrap_add_to_cart_pack">
                        <button class="add_tocart_pack active" data-product_id="'.$product_id.'">ADD TO CART</button>
                    </div>';*/
                }

                /*
                if( $min_price != $max_price ){
                    $product_price = number_format( $min_price, 2 ) . " - " . number_format( $max_price, 2 );
                }else{
                    $product_price = number_format( $min_price, 2 );
                }
                */
                $product_price = $min_price;


                break;

            default:
                $count_item = true;
                //$t_table='<div class="success-notice success-notice-block">Success! Your items have been added to the cart. <a href="/cart/">Checkout <span class="fa fa-angle-right"></span></a></div>';
                $product_price = $_product->get_price();
                //echo $product_id.'--'.$product_price.'<br>';
                $wholesale_customer_wholesale_price = get_post_meta($product_id, 'wholesale_customer_wholesale_price', true);
                if ($wholesale_customer_wholesale_price == '') {
                    $wholesale_customer_wholesale_price = $product_price;
                }
                $add_button = $add_button = '<a class="add-to-cart-btn simple" href="' . $product_link . '?add-to-cart=' . $product_id . '">Add to Cart</a>';
        }



        //get Size Product
        $product_size = get_post_meta($product_id, 'bold_product_size', true);

        //branding options
        if ($this->isWholesaleUser) {
            $brading_options = get_post_meta($product_id, 'brading_options', true);
        } else {
            $brading_options = "";
        }


        //MSRP Price
        $msrp_price = get_post_meta($product_id, 'bold_msrp', true);
        //get Image Product
        $product_image = array(
            "title" => $product_title,
            "image" => $this->defaultImage,
            "hover" => "",
        );

        // $post_thumbnail_id = $_product->get_image_id();
        // $html = wc_get_gallery_image_html( $post_thumbnail_id, true );

        //$image = wp_get_attachment_image_src( get_post_thumbnail_id( $product_id ), 'single-post-thumbnail' );
        //$image = wp_get_attachment_image_src( get_post_thumbnail_id( $product_id ), 'thumbnail' );
        //echo "!".get_the_post_thumbnail_url( $product_id, 'thumbnail')."!";
        //$image = get_the_post_thumbnail_url( $product_id, 'thumbnail');
        $image = wp_get_attachment_image_src(get_post_thumbnail_id($product_id), 'single-post-thumbnail');
        //print_r($image);


        //$image = get_the_post_thumbnail_url( $product_id );
        //echo "!".$image."!";
        //$preview = $this->ab_image_resize( $image, 250, 250, '_250_250' );
        //$product_image[ "image" ] = $image;

        //echo "!".get_post_thumbnail_id( $product_id )."!<br/>";
        //echo "!".get_the_post_thumbnail($product_id)."!";


        //echo $image[0]."<br/>";
        if (isset($image[0])) {

            $preview = $this->ab_image_resize($image[0], 900, 900, '_900_900');
            //$preview = $this->ab_image_resize( $image[ 0 ], 1000, 1000, '_250_250' );

            $product_image["image"] = $preview;

            $gallery_images = $_product->get_gallery_image_ids();
            if (isset($gallery_images[0])) {
                $hover_image                = wp_get_attachment_url($gallery_images[0], 'full');
                $preview_hover              = $this->ab_image_resize($hover_image, 900, 900, '_900_900');
                $product_image["hover"]   = $preview_hover;
            }
        }


        //print_r( $categories );
        $cats = [];
        foreach ($categories as $category) {
            if ("Yes" == get_term_meta($category->term_id, 'bold_branded_category', true)) {
                $cats[] = $category->term_id;
            }
        }
        //print_r($cats);

        /*$cats = [];
        foreach( $categories_ids as $category_id ){
            $meta_values = get_term_meta( $category_id, 'bold_branded_category', true );
            if( $meta_values == 'Yes' ){
                $cats[] = $category_id;
            }
        }
        */
        //----$this->getProductCardImg( $product_image ),
        /* Gaurav - 25 Aug 2023 */

        $product_for_wholesale_customer = get_post_meta($product_id, 'only_for_wholesale_users', true);
        $available_stock_date = get_post_meta($product_id, 'instock_date', true);

        /* The End */
        $product_data = array(
            "product_id"        => $product_id,
            "title"             => $product_title,
            "link"              => $product_link,
            "price"             => $product_price,
            "image"             => $this->getProductCardImg($product_image),
            "size"              => trim($product_size),
            "brand"             => $this->getBrand($product_id),
            "t_table"           => $t_table,
            "add_button"        => $add_button,
            "count_item"        => $this->getProductCountItemHtml($count_item),
            "variant_type"      => $variant_type,
            "msrp"              => $msrp_price,
            "pack"              => $pack,
            "category"          => $cats,
            "branding_options"  => $brading_options,
            "shipping_info"     => $shipping_info,
            'colortable_text'   => $colortable_text,
            'wholesale_customer_wholesale_price' => $wholesale_customer_wholesale_price,
            'only_for_wholesale_users' => $product_for_wholesale_customer,
            'available_stock_date' => $available_stock_date,

        );

        return $product_data;
    }

    private function ab_image_resize($imgurl, $width, $height, $imgname)
    {
        $img_file = $this->_root . "/" . str_replace(
            $this->site_url . "/",
            "",
            $imgurl
        );

        if (!$img_file) {
            $img_file = $this->defaultImage;
        } //set a default image if no image is found

        $image = wp_get_image_editor($img_file);

        if (! is_wp_error($image)) {

            $image->resize($width, $height, false);
            $filename = $image->generate_filename($imgname, ABSPATH . 'wp-content/uploads/ab_resized/', NULL); //create the upload folder; here: ab_resized
            $image->save($filename);
            $new_img_name = basename($filename);
            return get_site_url() . '/wp-content/uploads/ab_resized/' . $new_img_name;
        } else {
            return $this->defaultImage;
        }
    }

    public function getShippingInfo($shipping_info)
    {
        return '<div class="info-tab shipping-info">' . $shipping_info . '</div>';
    }

    private function getAtumControlled($product_id)
    {
        $q = "SELECT atum_controlled FROM `wp_atum_product_data` WHERE product_id = '" . $product_id . "'";
        $result = $this->_wpdb->get_row($q, ARRAY_A);
        return $result['atum_controlled'];
    }
}
