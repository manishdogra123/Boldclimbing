<?php
/*
Plugin Name: Bold Settings
Author: denys.kanibolotskyi@wp-masters.com
Version: 1.0.1
*/
add_action( 'wp_loaded', array( BoldSettings::getInstance(), 'register' ) );

class BoldSettings
{
    public $boldSettings = [
        "branding"=> [
            "name"      => "dkabz-settings",
            "caption"   => "Branding Settings",
            "func"      => "branding_page",
            "section"   => "dkabz_section_id",
            "settings"  => "dkabz_settings",
            "items"     => [
                [
                    "name"      => "dkabz_branding_iron",
                    "caption"   => "Iron branding price(setup):",
                    "func"      => "true_text_field",
                ],
                [
                    "name"      => "dkabz_branding_iron_piece",
                    "caption"   => "Iron branding price(per piece):",
                    "func"      => "true_text_field",
                ],
                [
                    "name"      => "dkabz_branding_laser",
                    "caption"   => "Laser branding price(setup):",
                    "func"      => "true_text_field",
                ],
                [
                    "name"      => "dkabz_branding_laser_piece",
                    "caption"   => "Laser branding price(per piece):",
                    "func"      => "true_text_field",
                ],
                [
                    "name"      => "dkabz_branding_stampstick",
                    "caption"   => "Chalk & Tape branding branding(setup):",
                    "func"      => "true_text_field",
                ],
                [
                    "name"      => "dkabz_branding_stampstick_piece",
                    "caption"   => "Chalk & Tape branding branding(per piece):",
                    "func"      => "true_text_field",
                ],
                [
                    "name"      => "dkabz_branding_free",
                    "caption"   => "Free branding over:",
                    "func"      => "true_text_field",
                ],
                [
                    "name"      => "dkabz_retail_branded_text",
                    "caption"   => "Retail branding text:",
                    "func"      => "true_textarea_field",
                ],
                [
                    "name"      => "dkabz_branding_info",
                    "caption"   => "Branding info text:",
                    "func"      => "true_textarea_field",
                ],
            ]
        ],
        "shipping" => [
            "name"      => "dkabz-settings-shipping",
            "caption"   => "Shipping Settings",
            "func"      => "shipping_page",
            "section"   => "shipping_section_id",
            "settings"  => "shipping_settings",
            "items"     => [
                [
                    "name"      => "dkabz_api_key",
                    "caption"   => "API Key (Address by ZIP):",
                    "func"      => "true_text_field",
                    "desc"      => "API Key from <a target='_blank' href='https://app.zipcodebase.com'>https://app.zipcodebase.com/</a>",
                ],
                [
                    "name"      => "dkabz_limit_retail_free",
                    "caption"   => "Amount for free shippping<br/>(Retail items):",
                    "func"      => "true_text_field",
                ],
                [
                    "name"      => "dkabz_limit_noretail_free",
                    "caption"   => "Amount for free shippping<br/>(No retail items):",
                    "func"      => "true_text_field",
                ],
                [
                    "name"      => "dkabz_local_rate",
                    "caption"   => "Multiplier for local delivery:",
                    "func"      => "true_text_field",
                ],
                [
                    "name"      => "dkabz_flat_rate_fix",
                    "caption"   => "Fix pay for Comp-X:",
                    "func"      => "true_text_field",
                ],
                [
                    "name"      => "dkabz_flat_rate_weight",
                    "caption"   => "Multiplier for Comp-X:",
                    "func"      => "true_text_field",
                ],
                [
                    "name"      => "dkabz_ups_rate_fix",
                    //"caption"   => "Multiplier for UPS:",
                    "caption"   => "Add amount for UPS(%):",
                    "func"      => "true_text_field",
                    "default"   => 1
                ],
                [
                    "name"      => "dkabz_usps_rate_fix",
                    //"caption"   => "Multiplier for USPS:",
                    "caption"   => "Add amount for USPS(%):",
                    "func"      => "true_text_field",
                    "default"   => 1
                ],
                [
                    "name"      => "dkabz_rl_rate_fix",
                    //"caption"   => "Multiplier for R+L:",
                    "caption"   => "Add amount for R+L(%):",
                    "func"      => "true_text_field",
                    "default"   => 1
                ],

                [
                    "name"      => "dkabz_kastline_pu_fix",
                    "caption"   => "Fix pay for Kastline-PU(%):",
                    "func"      => "true_text_field",
                    "default"   => 1
                ],
                [
                    "name"      => "dkabz_kasline_pu_flat",
                    "caption"   => "flat for Kastline-PU:",
                    "func"      => "true_text_field",
                ],

                [
                    "name"      => "dkabz_mto_hint",
                    "caption"   => "Notification MTO in cart:",
                    "func"      => "true_textarea_field",
                ],
                /*
                [
                    "name"      => "dkabz_useformula",
                    "caption"   => 'Apply min/max rates values',
                    "func"      => "true_checkbox_field",
                ],
                */

                [
                    "name"      => "dkabz_minperc_noshipping",
                    //"caption"   => 'Max percentage for show "Shipping separate quote"',
                    "caption"   => 'Min percentage for shipping',
                    "func"      => "true_number_field",
                ],
                [
                    "name"      => "dkabz_maxperc_noshipping",
                    //"caption"   => 'Min percentage for show "Shipping separate quote"',
                    "caption"   => 'Max percentage for shipping',
                    "func"      => "true_number_field",
                ],
                [
                    "name"      => "aragon_percent_shipping_price",
                    //"caption"   => 'Min percentage for show "Shipping separate quote"',
                    "caption"   => 'Aragon Shipping Percent',
                    "func"      => "true_number_field",
                ],
                [
                    "name"      => "proxy_percent_shipping_price",
                    //"caption"   => 'Min percentage for show "Shipping separate quote"',
                    "caption"   => 'Proxy Shipping Percent',
                    "func"      => "true_number_field",
                ],
				[
                    "name"      => "volx_percent_shipping_price",
                    "caption"   => 'Volx Shipping Percent',
                    "func"      => "true_number_field",
                ],
				[
                    "name"      => "kastline_percent_shipping_price",
                    "caption"   => 'Kastline Shipping Percent',
                    "func"      => "true_number_field",
                ],
                [
                    "name"      => "dkabz_amout_noshipping",
                    "caption"   => 'Pack amount for show "Shipping separate quote"',
                    "func"      => "true_number_field",
                ]

                ,
                [
                    "name"      => "dkabz_additional_weught_rl",
                    "caption"   => 'Additional weight for R + L package',
                    "func"      => "true_number_field",
                ]

                // Tech 9/23/23
                ,
                [
                    "name"      => "ups_ground_total_amount",
                    "caption"   => 'UPS/Ground total amount',
                    "func"      => "true_number_field",
                ]
                ,
                [
                    "name"      => "ups_usps_ground_minimum_amount",
                    "caption"   => 'UPS/USPS ground minimum amount',
                    "func"      => "true_number_field",
                ]
                ,
                [
                    "name"      => "frieght_total_amount",
                    "caption"   => 'Frieght total amount',
                    "func"      => "true_number_field",
                ]
                ,
                [
                    "name"      => "frieght_minimum_amount",
                    "caption"   => 'Frieght minimum amount',
                    "func"      => "true_number_field",
                ]
                // End tech
			
                /*
                [
                    "name"      => "dkabz_perc_shippingfloor",
                    "caption"   => 'Shipping cost (percentage of the order), below which the option "Shipping is calculated separately" will be displayed',
                    "func"      => "true_text_field",
                ],
                */
            ]
        ],
        "cart" => [
            "name"      => "dkabz-settings-cart",
            "caption"   => "Cart/Checkout Settings",
            "func"      => "cart_page",
            "section"   => "cart_section_id",
            "settings"  => "cart_settings",
            "items"     => [
                [
                    "name"      => "dkabz_shipping_stock_caption",
                    "caption"   => "Items in stock caption:",
                    "func"      => "true_text_field",
                ],
                [
                    "name"      => "dkabz_shipping_stock_desc",
                    "caption"   => "Items in stock description:",
                    "func"      => "true_textarea_field",
                ],
                [
                    "name"      => "dkabz_shipping_inbound_caption",
                    "caption"   => "Items inbound caption:",
                    "func"      => "true_text_field",
                ],
                [
                    "name"      => "dkabz_shipping_inbound_desc",
                    "caption"   => "Items inbound description:",
                    "func"      => "true_textarea_field",
                ],
                [
                    "name"      => "dkabz_shipping_mto_caption",
                    "caption"   => "Items MTO caption:",
                    "func"      => "true_text_field",
                ],
                [
                    "name"      => "dkabz_shipping_mto_desc",
                    "caption"   => "Items MTO description:",
                    "func"      => "true_textarea_field",
                ],

                //Main caption, stock
                [
                    "name"      => "dkabz_shipping_main_caption",
                    "caption"   => "Shipping together from stock caption:",
                    "func"      => "true_text_field",
                ],
                [
                    "name"      => "dkabz_shipping_main_description",
                    "caption"   => "Shipping together from stock description:",
                    "func"      => "true_textarea_field",
                ],

                //Proxy&Aragon
                [
                    "name"      => "dkabz_shipping_proxyaragon_caption",
                    "caption"   => "Shipping from Proxy caption:",
                    "func"      => "true_text_field",
                ],
                [
                    "name"      => "dkabz_shipping_proxyaragon_description",
                    "caption"   => "Shipping from Proxy description:",
                    "func"      => "true_textarea_field",
                ],

                [
                    "name"      => "dkabz_shipping_aragon_caption",
                    "caption"   => "Shipping from Aragon caption:",
                    "func"      => "true_text_field",
                ],
                [
                    "name"      => "dkabz_shipping_aragon_description",
                    "caption"   => "Shipping from Aragon description:",
                    "func"      => "true_textarea_field",
                ],

                //Composite-X
                [
                    "name"      => "dkabz_shipping_compozite_caption",
                    "caption"   => "Shipping from Compozite caption:",
                    "func"      => "true_text_field",
                ],
                [
                    "name"      => "dkabz_shipping_compozite_description",
                    "caption"   => "Shipping from Compozite description:",
                    "func"      => "true_textarea_field",
                ],

                //Static Air
                [
                    "name"      => "dkabz_shipping_staticair_caption",
                    "caption"   => "Shipping Static Air caption:",
                    "func"      => "true_text_field",
                ],
                [
                    "name"      => "dkabz_shipping_staticair_description",
                    "caption"   => "Shipping Static Air description:",
                    "func"      => "true_textarea_field",
                ],
                 // Volx Shipping
                 [
                    "name"      => "dkabz_shipping_volx_caption",
                    "caption"   => "Shipping Volx caption:",
                    "func"      => "true_text_field",
                ],
                [
                    "name"      => "dkabz_shipping_volx_description",
                    "caption"   => "Shipping Static Volx description:",
                    "func"      => "true_textarea_field",
                ],
                // Kastline Shipping
                [
                    "name"      => "dkabz_shipping_kastline_caption",
                    "caption"   => "Shipping Volx2 caption:",
                    "func"      => "true_text_field",
                ],
                [
                    "name"      => "dkabz_shipping_kastline_description",
                    "caption"   => "Shipping Static Volx2 description:",
                    "func"      => "true_textarea_field",
                ],
                
                [
                    "name"      => "dkabz_checkout_terms_note",
                    "caption"   => "Terms note:",
                    "func"      => "true_textarea_field",
                ],
				[
                    "name"      => "dkabz_cart_discount_25_5k",
                    "caption"   => "Discount % for 2500 - 5K orders",
                    "func"      => "true_text_field",
                ],
				[
                    "name"      => "dkabz_cart_discount_5k_7500",
                    "caption"   => "Discount % for 5K - 7500 orders",
                    "func"      => "true_text_field",
                ],
				[
                    "name"      => "dkabz_cart_discount_7500_10k",
                    "caption"   => "Discount % for 7500 - 10K orders",
                    "func"      => "true_text_field",
                ],
				[
                    "name"      => "dkabz_cart_discount_10K_15k",
                    "caption"   => "Discount % for 10K - 15K orders",
                    "func"      => "true_text_field",
                ],
				[
                    "name"      => "dkabz_cart_discount_above_15k",
                    "caption"   => "Discount % for above 15K orders",
                    "func"      => "true_text_field",
                ],
                // certain % of order is mto or future give a warning to customer

                [
                    "name"      => "percentage_of_current_product",
                    "caption"   => "Percentage of Current Product(%)",
                    "func"      => "true_text_field",
                ],
                [
                    "name"      => "percentage_of_future_product",
                    "caption"   => "Percentage of Future Product(%)",
                    "func"      => "true_text_field",
                ],
                [
                    "name"      => "importing_gst_fee",
                    "caption"   => "Importing/GST Fee/Canada",
                    "func"      => "true_text_field",
                ],
				[
                    "name"      => "total_product_percentage_importing_gst_fee",
                    "caption"   => "Total Product Percentage For Importing/GST Fee/Canada",
                    "func"      => "true_text_field",
                ],
                [
                    "name"      => "importing_gst_fee_mexico",
                    "caption"   => "Importing/GST Fee/Mexico",
                    "func"      => "true_text_field",
                ],
				[
                    "name"      => "total_product_percentage_importing_gst_fee_mexico",
                    "caption"   => "Total Product Percentage For Importing/GST Fee/Mexico ",
                    "func"      => "true_text_field",
                ],


            ]
        ],
        "product" => [
            "name"      => "dkabz-settings-product",
            "caption"   => "Product Settings",
            "func"      => "product_page",
            "section"   => "product_section_id",
            "settings"  => "product_settings",
            "items"     => [
                [
                    "name"      => "dkabz_product_bolt_caption",
                    "caption"   => "Bolt-on description:",
                    "func"      => "true_textarea_field",
                ]

            ]
        ]
    ];

    protected static $instance = false;
    public function register()
    {
        //global $wpdb;
        //$this->_wpdb        = $wpdb;
        $this->remoteUrl    = 'https://app.zipcodebase.com/api/v1/search';
        $this->api_key      = get_option('dkabz_api_key');

        add_action( 'admin_menu', [ $this, 'dkabz_settings' ], 25 );
        add_action( 'admin_init', [ $this, 'dkabz_fields' ] );

        add_action( 'wp_enqueue_scripts', array( $this, 'style_scripts' ) );

        add_action('wp_ajax_nopriv_get_address_by_code', [$this, 'get_address_by_code']);
        add_action('wp_ajax_get_address_by_code', [$this, 'get_address_by_code']);

    }

    public function get_address_by_code()
    {
        //https://app.zipcodebase.com/pi/v1/search?apikey=ad830040-880e-11ed-a204-f5015dd95c46&codes=10005&country=US

        //function wp_remote_get( $url, $args = array() ) {
        //    $http = _wp_http_get_object();
        //    return $http->get( $url, $args );
        //}
        $code       = sanitize_text_field( $_POST[ 'code' ] );
        $country    = sanitize_text_field( $_POST[ 'country' ] );

        $url = $this->remoteUrl . '?apikey=' . $this->api_key . '&codes=' . $code;

        if( $country!='default' ){
            $url .= '&country=' . $country;
        }

        $data = wp_remote_get( $url );

        $response[ 'success' ] = false;
        if ( 200 == $data[ 'response' ][ 'code' ] ){

            $response_data = json_decode( $data[ 'body' ], TRUE );
            $results = $response_data[ 'results' ];

            $response['response']=$data;

            if( isset( $results[ $code ][ 0 ][ 'state_code' ] ) ){
                $response[ 'state_code' ] = $results[ $code ][ 0 ][ 'state_code' ];
                $response[ 'success' ] = true;
            }
            $result_value = isset( $results[ $code ][ 'state_code' ] )? $results[ $code ][ 'state_code' ] : '';

        }

        wp_send_json( $response );
    }

    public static function getInstance()
    {
        if ( !self::$instance )
            self::$instance = new self;
        return self::$instance;
    }

    public function dkabz_settings()
    {
        add_menu_page(
            'Bold Settings',
            'Bold Settings',
            'manage_options',
            'dkabz-settings',
            [ __CLASS__, 'branding_page' ],
            'dashicons-images-alt2',
            20
        );

        foreach( $this->boldSettings as $item ){
            add_submenu_page(
                'dkabz-settings',
                $item[ 'caption' ],
                $item[ 'caption' ],
                'manage_options',
                $item[ 'name' ],
                array( __CLASS__, $item[ 'func' ] )
            );
        }

    }
    public function dkabz_fields()
    {
        //add_settings_section( 'shipping_section_id', '', '', 'shipping_settings' );
        //register_setting( 'shipping_settings', 'dkabz_api_key' );

        //add_settings_section( 'dkabz_section_id', '', '', 'dkabz_settings' );
        //add_settings_section( 'shipping_section_id', '', '', 'shipping_settings' );


        foreach( $this->boldSettings as $item ){
            add_settings_section( $item[ 'section' ], '', '', $item[ 'settings' ] );
            foreach( $item[ 'items' ] as $prop ){

                register_setting( $item[ 'settings' ], $prop['name'] );
                //register_setting( 'shipping_settings', 'dkabz_api_key' );
                add_settings_field(
                    $prop[ 'name' ],
                    $prop[ 'caption' ],
                    [ __CLASS__, $prop[ 'func' ] ],
                    $item[ 'settings' ],
                    $item[ 'section' ],
                    array(
                        'label_for'     => $prop[ 'name' ],
                        'name'          => $prop[ 'name' ],
                        'description'   => isset( $prop[ 'desc' ] ) ? $prop[ 'desc' ] : ''
                    )
                );

            }
        }

    }

    public static function true_text_field( $args )
    { ?>
        <input class="regular-text" type="text" id="<?php echo esc_attr( $args[ 'name' ] ); ?>" name="<?php echo esc_attr( $args[ 'name' ] ); ?>" value="<?php echo esc_attr( get_option( $args[ 'name' ] ) ); ?>"/>
        <?php if( isset( $args[ 'description' ] ) ) {?>
        <p><?php echo $args[ 'description' ] ?></p>
    <?php }
    }
    public static function true_number_field( $args )
    { ?>
        <input class="regular-text" type="number" id="<?php echo esc_attr( $args[ 'name' ] ); ?>" name="<?php echo esc_attr( $args[ 'name' ] ); ?>" value="<?php echo esc_attr( get_option( $args[ 'name' ] ) ); ?>"/>
        <?php if( isset( $args[ 'description' ] ) ) {?>
        <p><?php echo $args[ 'description' ] ?></p>
    <?php }
    }
    public static function true_textarea_field( $args )
    { ?>
        <textarea style="height:150px" class="regular-text" id="<?php echo esc_attr( $args[ 'name' ] ); ?>" name="<?php echo esc_attr( $args[ 'name' ] ); ?>"><?php echo esc_html( get_option( $args[ 'name' ] ) ); ?></textarea>
        <?php if( isset( $args[ 'description' ] ) ) {?>
        <p><?php echo $args[ 'description' ] ?></p>
    <?php }?>
        <?php
    }
    /*
    public static function true_checkbox_field( $args )
        
    }
    */
    public static function product_page()
    {
        ?>
        <h2><?php _e( 'Product settings', 'dkabz' ) ?></h2>
        <div class="wrap">
            <h1><?php get_admin_page_title() ?></h1>
            <form method="post" action="options.php">
                <?php
                settings_fields( 'product_settings' );
                do_settings_sections( 'product_settings' );
                submit_button();
                ?>
            </form>
        </div>
        <?php
    }
    public static function cart_page()
    {
        ?>
        <h2><?php _e( 'Cart settings', 'dkabz' ) ?></h2>
        <div class="wrap">
            <h1><?php get_admin_page_title() ?></h1>
            <form method="post" action="options.php">
                <?php
                settings_fields( 'cart_settings' );
                do_settings_sections( 'cart_settings' );
                submit_button();
                ?>
            </form>
        </div>
        <?php
    }

    public static function branding_page()
    {
        ?>
        <h2><?php _e( 'Branding settings', 'dkabz' ) ?></h2>
        <div class="wrap">
            <h1><?php get_admin_page_title() ?></h1>
            <form method="post" action="options.php">
                <?php
                settings_fields( 'dkabz_settings' );
                do_settings_sections( 'dkabz_settings' );
                submit_button();
                ?>
            </form>
        </div>
        <?php
    }

    public static function shipping_page()
    {
        ?>
        <h2><?php _e( 'Shipping settings', 'dkabz' ) ?></h2>
        <div class="wrap">
            <h1><?php get_admin_page_title() ?></h1>
            <form method="post" action="options.php">
                <?php
                settings_fields( 'shipping_settings' );
                do_settings_sections( 'shipping_settings' );
                submit_button();
                ?>
            </form>
        </div>
        <?php
    }



    public function style_scripts()
    {
        $data[ 'ajax_url' ] = admin_url( 'admin-ajax.php' );
        wp_enqueue_script( 'dkabz-script', plugins_url( '/assets/js/script.js', __FILE__ ), '', filemtime( dirname( __FILE__ ) . '/assets/js/script.js' ), true );
        wp_localize_script( 'dkabz-script', 'dkabz_vars', $data );
    }




}

