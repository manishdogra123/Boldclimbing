<?php
// Calculate Quarters of years
function month_name_data($month_number)
{
    return date('F', mktime(0, 0, 0, $month_number, 10));
}

function month_end_date_($year, $month_number)
{
    return date("t", strtotime("$year-$month_number-0"));
}

function zero_pad_data($number)
{
    if ($number < 10)
        return "0$number";

    return "$number";
}
function get_quarters_data($start_date, $end_date)
{
    $quarters = array();

    $start_month = date('n', strtotime($start_date));
    $start_year = date('Y', strtotime($start_date));

    $end_month = date('n', strtotime($end_date));
    $end_year = date('Y', strtotime($end_date));

    $quarter = ceil($start_month / 3);

    while (($start_year < $end_year) || ($start_year == $end_year && $quarter <= ceil($end_month / 3))) {
        $current_quarter = new stdClass();

        $q_start_month = (($quarter - 1) * 3) + 1;
        $q_end_month = $quarter * 3;

        $current_quarter->period = "Q$quarter $start_year";
        $current_quarter->period_start = "$start_year-" . zero_pad_data($q_start_month) . "-01";
        $current_quarter->period_end = date('Y-m-t', strtotime("$start_year-" . zero_pad_data($q_end_month) . "-01"));

        $quarters[] = $current_quarter;

        $quarter++;
        if ($quarter > 4) {
            $quarter = 1;
            $start_year++;
        }
    }

    return $quarters;
}



// Completed Order Summary
// Completed_Quarter_Order_Summary
// completed_quarters_order_summary_func
add_filter('cron_schedules', 'Completed_Quarter_Order_Summary');
function Completed_Quarter_Order_Summary($schedules)
{
    $schedules['once_hourly'] = array(
        'interval'  => 43200,
        'display'   => __('Twice Daily', 'textdomain')
    );
    return $schedules;
}


if (!wp_next_scheduled('Completed_Quarter_Order_Summary')) {
    wp_schedule_event(time(), 'once_hourly', 'Completed_Quarter_Order_Summary');
}


add_action('Completed_Quarter_Order_Summary', 'completed_quarters_order_summary_func');
function completed_quarters_order_summary_func()
{
    $order_statuses = array('wc-pending', 'wc-processing', 'wc-on-hold', 'wc-partially-paid', 'wc-completed', 'custom-status', 'wc-failed');


    // Call Quarters function
    $date = date('Y-m-d');
    $quarters = get_quarters_data('2023-07-01', $date);
    $reverseQuarters = array_reverse($quarters);
   
    
    $file_main_header = array();
    $file_main_header['customer_info'] = 'Customer Info';
    $file_main_header['customer_info_1'] = '';
    $file_main_header['customer_info_2'] = '';
    $file_main_header['customer_info_3'] = '';
    $file_main_header['customer_info_4'] = '';
    $file_main_header['customer_info_5'] = '';
    $file_main_header['customer_info_6'] = '';
    $file_main_header['customer_info_7'] = '';
    $file_main_header['customer_info_8'] = '';
    $file_main_header['customer_info_9'] = '';
    $file_main_header['customer_info_10'] = '';
    $file_main_header['customer_info_11'] = '';
    $file_main_header['customer_info_12'] = '';
    $file_main_header['total'] = 'Totals';
    $file_main_header['total_1'] = '';
    $file_main_header['total_2'] = '';
    $file_main_header['total_3'] = '';
    $file_main_header['total_4'] = '';
    $file_main_header['total_5'] = '';
    $file_main_header['total_6'] = '';
    $file_main_header['total_7'] = '';
    $file_main_header['total_8'] = '';
    $file_main_header['total_9'] = '';
    $file_main_header['total_10'] = '';
    $file_main_header['total_11'] = '';
    $file_main_header['all_shipments_costs'] = 'All Shipments Costs';
    $file_main_header['all_shipments_costs_1'] = '';
    $file_main_header['all_shipments_costs_2'] = '';
    $file_main_header['all_shipments_costs_3'] = '';
    $file_main_header['all_shipments_costs_4'] = '';
    $file_main_header['all_shipments_costs_5'] = '';
    $file_main_header['all_shipments_costs_6'] = '';
    $file_main_header['all_shipments_costs_7'] = '';
   // $file_main_header['all_shipments_costs_8'] = '';
    $file_main_header['shipping_methods_ups'] = 'Shipping methods - UPS / Freight';
    $file_main_header['shipping_methods_ups_1'] = '';
    $file_main_header['shipping_methods_ups_2'] = '';
    $file_main_header['shipping_methods_ups_3'] = '';
    $file_main_header['shipping_weight'] = 'Shipping Weight';
    $file_main_header['shipping_weight_1'] = '';
    $file_main_header['shipping_weight_2'] = '';
    $file_main_header['shipping_weight_3'] = '';
    $file_main_header['shipping_weight_4'] = '';
    $file_main_header['category_Totals'] = 'Category $ Totals';
    $file_main_header['category_Totals_1'] = '';
    $file_main_header['category_Totals_2'] = '';
    $file_main_header['category_Totals_3'] = '';
    $file_main_header['category_Totals_4'] = '';
    $file_main_header['blocz'] = 'Blocz';
    $file_main_header['blocz_1'] = '';
    $file_main_header['blocz_2'] = '';
    $file_main_header['bluepill'] = 'Bluepill';
    $file_main_header['bluepill_1'] = '';
    $file_main_header['bluepill_2'] = '';
    $file_main_header['Unit'] = 'Unit';
    $file_main_header['Unit_1'] = '';
    $file_main_header['Unit_2'] = '';
    $file_main_header['Rustam'] = 'Rustam';
    $file_main_header['Rustam_1'] = '';
    $file_main_header['Rustam_2'] = '';
    $file_main_header['artline'] = 'Artline';
    $file_main_header['artline_1'] = '';
    $file_main_header['artline_2'] = '';
    $file_main_header['_360'] = '360';
    $file_main_header['_360_1'] = '';
    $file_main_header['_360_2'] = '';
    $file_main_header['simpl'] = 'simpl';
    $file_main_header['simpl_1'] = '';
    $file_main_header['simpl_2'] = '';
    $file_main_header['rockcity'] = 'Rockcity';
    $file_main_header['rockcity_1'] = '';
    $file_main_header['rockcity_2'] = '';
    $file_main_header['chapter'] = 'Chapter';
    $file_main_header['chapter_1'] = '';
    $file_main_header['chapter_2'] = '';
    $file_main_header['CCE'] = 'CCE';
    $file_main_header['CCE_1'] = '';
    $file_main_header['CCE_2'] = '';
    $file_main_header['menagerie'] = 'Menagerie';
    $file_main_header['menagerie_1'] = '';
    $file_main_header['menagerie_2'] = '';
    $file_main_header['formik'] = 'Formik';
    $file_main_header['formik_1'] = '';
    $file_main_header['formik_2'] = '';
    $file_main_header['accessories'] = 'Accessories';
    $file_main_header['accessories_1'] = '';
    $file_main_header['accessories_2'] = '';
    $file_main_header['accessories_3'] = '';
    $file_main_header['accessories_4'] = '';


    $file_header_array = array();
    $file_header_array['orderid'] = 'Order#';
    $file_header_array['customer_type'] = 'Customer Type';
    $file_header_array['customer'] = 'Customer';
    $file_header_array['shipping_business_name'] = 'Shipping - Business Name';
    $file_header_array['shipping_address'] = 'Shipping Address';
    $file_header_array['email'] = 'Email';
    $file_header_array['phone'] = 'Phone';
    $file_header_array['order_date'] = 'Order Date';
    $file_header_array['customer_notes'] = 'Customer Notes';
    $file_header_array['customs_broker_name'] = 'Customs Broker name';
    $file_header_array['customs_broker'] = 'Customs Broker';

    $file_header_array['payment_method'] = 'Payment Method';
    $file_header_array['order_status'] = 'Order Status';
    $file_header_array['items_subtotal'] = 'Items Subtotal';
    $file_header_array['coupon_code'] = 'Coupon Code';
    $file_header_array['coupon_amount'] = 'Coupon Amount';
    $file_header_array['customfee_title'] = 'Custom Fee Title';
    $file_header_array['customfee'] = 'Custom Fee';
    $file_header_array['discount_title'] = 'Discount Title';
    $file_header_array['discount_fee'] = 'Discount';
    $file_header_array['international_customs_fee'] = 'International Customs Fee';

    $file_header_array['bold_discount'] = 'Bold Discount';
    $file_header_array['shipping_total'] = 'Shipping Total';
    $file_header_array['ca_tax'] = 'CA Tax';
    $file_header_array['order_total'] = 'Order Total';
    $file_header_array['bold_warehouse_cost'] = 'Bold Warehouse Cost';
    $file_header_array['current_stock_shipping_cost'] = 'Current Stock Shipping Cost';
    $file_header_array['future_stock_shipping_cost'] = 'Future Stock Shipping Cost';
    $file_header_array['mto_stock_shipping_cost'] = 'MTO Stock Shipping Cost';
    $file_header_array['proxy_ship_cost'] = 'Proxy Ship Cost';
    $file_header_array['aragon_ship_cost'] = 'Aragon Ship Cost';
   // $file_header_array['proxy_aragon_ship_cost'] = 'Proxy & Aragon Cost';
    $file_header_array['compx_ship_cost'] = 'CompX Ship Cost';
    $file_header_array['requires_quote'] = 'Requires Quote';
    $file_header_array['bold_warehouse'] = 'Bold Warehouse';
    $file_header_array['current_stock_shipping'] = 'Current Stock Shipping';
    $file_header_array['future_stock_shipping'] = 'Future Stock Shipping';
    $file_header_array['mto_stock_shipping'] = 'MTO Stock Shipping';
    $file_header_array['sw_bold_warehouse'] = 'Bold Warehouse';
    $file_header_array['sw_current_stock_shipping'] = 'Current Stock Shipping';
    $file_header_array['sw_future_stock_shipping'] = 'Future Stock Shipping';
    $file_header_array['sw_mto_stock_shipping'] = 'MTO Stock Shipping';
    $file_header_array['sw_quote'] = 'Quote';
    $file_header_array['category_holds'] = 'Holds';
    $file_header_array['category_macros'] = 'Macros';
    $file_header_array['category_volumes'] = 'Volumes';
    $file_header_array['category_accessories'] = 'Accessories';
    $file_header_array['category_static_air'] = 'Static Air';
    $file_header_array['blocz_holds'] = 'Holds';
    $file_header_array['blocz_macros'] = 'Macros';
    $file_header_array['blocz_volumes'] = 'Volumes';
    $file_header_array['bluepill_holds'] = 'Holds';
    $file_header_array['bluepill_macros'] = 'Macros';
    $file_header_array['bluepill_volumes'] = 'Volumes';
    $file_header_array['unit_holds'] = 'Holds';
    $file_header_array['unit_macros'] = 'Macros';
    $file_header_array['unit_volumes'] = 'Volumes';
    $file_header_array['rustam_holds'] = 'Holds';
    $file_header_array['rustam_macros'] = 'Macros';
    $file_header_array['rustam_volumes'] = 'Volumes';
    $file_header_array['artline_holds'] = 'Holds';
    $file_header_array['artline_macros'] = 'Macros';
    $file_header_array['artline_volumes'] = 'Volumes';

    $file_header_array['360_holds'] = 'Holds';
    $file_header_array['360_macros'] = 'Macros';
    $file_header_array['360_volumes'] = 'Volumes';

    $file_header_array['simpl_holds'] = 'Holds';
    $file_header_array['simpl_macros'] = 'Macros';
    $file_header_array['simpl_volumes'] = 'Volumes';

    $file_header_array['rockcity_holds'] = 'Holds';
    $file_header_array['rockcity_macros'] = 'Macros';
    $file_header_array['rockcity_volumes'] = 'Volumes';
    $file_header_array['chapter_holds'] = 'Holds';
    $file_header_array['chapter_macros'] = 'Macros';
    $file_header_array['chapter_volumes'] = 'Volumes';
    $file_header_array['cce_holds'] = 'Holds';
    $file_header_array['cce_macros'] = 'Macros';
    $file_header_array['cce_volumes'] = 'Volumes';
    $file_header_array['menagerie_holds'] = 'Holds';
    $file_header_array['menagerie_macros'] = 'Macros';
    $file_header_array['menagerie_volumes'] = 'Volumes';
    $file_header_array['formik_holds'] = 'Holds';
    $file_header_array['formik_macros'] = 'Macros';
    $file_header_array['formik_volumes'] = 'Volumes';
    $file_header_array['accessories_chalk'] = 'Chalk';
    $file_header_array['accessories_brushes'] = 'Brushes';
    $file_header_array['accessories_setting'] = 'Setting';
    $file_header_array['accessories_training'] = 'Training';
    $file_header_array['accessories_custom_branding'] = 'Custom Branding';

    $newheaderarray = array();
    foreach ($file_header_array as $field) {
        $newheaderarray[] = $field;
    }


    $mainheaderarray = array();
    foreach ($file_main_header as $field) {
        $mainheaderarray[] = $field;
    }

    //SCV Header

    $csv_data = array();
    $csv_data[] = $mainheaderarray;
    $csv_data[] = $newheaderarray;

    foreach($reverseQuarters as $value){
        $qstart = $value->period_start;
        $qend = $value->period_end;
        $period = $value->period; 
        $finaldate=$qstart.'='.$qend;
    
        if ($period) {
            $explodedates = explode("=", $finaldate);
            $final_date = $explodedates[1];
            $initial_date = $explodedates[0];
        } else {
            if ($qstart == '' && $qend == '') {
                $final_date = date('Y-m-d');
                $initial_date = date('Y-m-d', strtotime('-90 days'));
            } else {
            }
        }

        $orders = wc_get_orders(
            array(
                'limit' => -1,
                'type' => 'shop_order',
                'status' => $order_statuses,
                //'post__in' => array(193017),
                'date_created' => $initial_date . '...' . $final_date
            )
        );
        
        $finalorderwithdata = array();
        global $wpdb;
        foreach ($orders as $order) {
            $order_id = $order->ID;
            $currency_code = $order->get_currency();
            if ($currency_code == 'USD') {
                $currency = '$';
            }
            $isbroker = get_post_meta($order_id, 'bold_custom_broker_number', true);
            $isOrder_subtotal = $currency . '' . number_format($order->get_subtotal(), 2);

            $fees = $order->get_fees();
            $fee_items = $order->get_fees();
            $fees_Discount_amount = 0;
            $Discount_amount = 0;
            $customfee = 0;
            $positive_fees = 0;
            $negative_fees = 0;
            $importing_gst_fee = 0;
            $fee_titles = [];
            $Discount_label = [];
            if ($fee_items) {
                foreach ($fee_items as $item_id => $item) {
                    $label_Name = $item->get_name();
                    $matches = 'Bold Discount';
                    $another_match = 'GST Fee';
                    $discount_match = 'Discount';
                    if ( preg_match("/\b{$matches}\b/", $label_Name )) {
                        $Fees_Cost = $item->get_total();
                        $positive_value = abs($Fees_Cost);
                        $fees_Discount_amount = $fees_Discount_amount + $positive_value;
                    } 
                    else if ( preg_match("/\b{$another_match}\b/", $label_Name )){
                        $Fees_Cost = $item->get_total();
                        if($Fees_Cost > 0){
                            $importing_gst_fee = $Fees_Cost;
                        }
                    }
                    // elseif ( preg_match("/\b{$discount_match}\b/", $label_Name) && !preg_match("/\b{$matches}\b/", $label_Name )) {
                    else if( strripos($label_Name, $discount_match) !== false ){
                        $Discount_Name = $item->get_name();
                        $Fees_Cost = $item->get_total();
                        $positive_value = abs($Fees_Cost);
                        $Discount_amount += $positive_value;

                        $Discount_label[] =  $Discount_Name;
                    }
                    else {
                        $Fees_Cost = $item->get_total();
                        if ($Fees_Cost > 0) {
                            $positive_fees += $Fees_Cost;
                        } else {
                            $negative_fees += $Fees_Cost;
                        }
                    

                        $fee_titles[] = $label_Name;
                    }
                }
            }
            $customfee = $positive_fees + $negative_fees;

            if (count($fee_titles) > 1) {
                $fee_titles_string = implode(' / ', $fee_titles);
            } else {
                $fee_titles_string = $fee_titles[0] ?? '';
            }

            if (count($Discount_label) > 1) {
                $Discountlabel = implode(' / ', $Discount_label);
            } else {
                $Discountlabel = $Discount_label[0] ?? '';
            }


            $coupon = $order->get_coupon_codes();
            $coupon_array = array();
            foreach ($coupon as $coupon_data) {
                $coupon_array['coupon_data'] = $coupon_data;
            }


            $finalqtyarray = array();
            $finalarraycheck = array();
            $shipping_data_total = array();
            $shipping_meta_total = array();
            // Shipping Meta Data
            $fromboldarray = array();
            $fromboldarray_ = array();
            $manuallyshippings = array();

            //New---Mtech    
            $shipping_tags = array();

            foreach($order->get_items('shipping') as $item_is => $item){
                $item_data = $item->get_data();
                $shipping_meta = $item_data['meta_data'];

                $checkShippingtags = false;
                if($item_data['method_id'] == 'mto_stock' && $item_data['method_title'] == 'Freight'){
                    $checkShippingtags = true;
                }elseif($item_data['method_id'] == 'future_stock' && $item_data['method_title'] == 'Freight'){
                    $checkShippingtags = true;
                }elseif($item_data['method_id'] == 'current_stock' && $item_data['method_title'] == 'Freight'){
                    $checkShippingtags = true;
                }

                if($shipping_meta){
                    if($checkShippingtags){
                        if(isset($shipping_tags[$item_data['method_id']]) ){
                            $shipping_tags[$item_data['method_id']]['title'] = $item_data['method_id'];
                            $shipping_tags[$item_data['method_id']]['total'] += $item_data['total'];
                        }else{
                            $shipping_tags[$item_data['method_id']]['title'] = $item_data['method_id'];
                            $shipping_tags[$item_data['method_id']]['total'] = $item_data['total'];
                        }
                        foreach ($item_data['meta_data'] as $meta_item) {
                            if ($meta_item->key === 'Shipping') {
                                $meta_val = $meta_item->value;
                                $meta_expload = explode(':', $meta_val);
                                $secondmeta =  $meta_expload['1'];

                                if (isset($shipping_meta_total[$item_data['method_title']])) {
                                    $shipping_meta_total[$item_data['method_title']] +=  $secondmeta;
                                } else {
                                    $shipping_meta_total[$item_data['method_title']] =  $secondmeta;
                                }
                                $shipping_meta_total['ship_bold_warehouse'] += $secondmeta;
                                $firstmeta = $meta_expload[0];
                                $meta_exploadName = explode('=', $firstmeta);
                                if(isset( $shipping_tags[trim($meta_exploadName[0])])){
                                    $shipping_tags[trim($meta_exploadName[0])]['weight'] += $secondmeta;
    
                                }else{
                                    $shipping_tags[trim($meta_exploadName[0])]['weight'] = $secondmeta;
                                }
                            }
                        }

                    }else{
                        foreach ($item_data['meta_data'] as $meta_item) {
                            if ($meta_item->key === 'Shipping') {
                                $meta_val = $meta_item->value;
                                $meta_expload = explode(':', $meta_val);
                                $secondmeta =  $meta_expload['1'];
                                
                                if (isset($shipping_meta_total[$item_data['method_title']])) {
                                    $shipping_meta_total[$item_data['method_title']] +=  $secondmeta;
                                } else {
                                    $shipping_meta_total[$item_data['method_title']] =  $secondmeta;
                                }
                                $shipping_meta_total['ship_bold_warehouse'] += $secondmeta;
                                $firstmeta = $meta_expload[0];
                                $meta_exploadName = explode('=', $firstmeta);
                                if(isset( $shipping_tags[trim($meta_exploadName[0])])){
                                    $shipping_tags[trim($meta_exploadName[0])]['total'] += $item_data['total'];
                                    $shipping_tags[trim($meta_exploadName[0])]['title'] = $item_data['method_title'];
                                    $shipping_tags[trim($meta_exploadName[0])]['weight'] += $secondmeta;
    
                                }else{
                                    $shipping_tags[trim($meta_exploadName[0])]['total'] = $item_data['total'];
                                    $shipping_tags[trim($meta_exploadName[0])]['title'] = $item_data['method_title'];
                                    $shipping_tags[trim($meta_exploadName[0])]['weight'] = $secondmeta;
                                }
                                
                            }
                        }

                    }

                }else{
                    if(isset($shipping_tags[$item_data['method_id']]) ){
                        $shipping_tags[$item_data['method_id']]['title'] = $item_data['method_id'];
                        $shipping_tags[$item_data['method_id']]['total'] += $item_data['total'];
                    }else{
                        $shipping_tags[$item_data['method_id']]['title'] = $item_data['method_id'];
                        $shipping_tags[$item_data['method_id']]['total'] = $item_data['total'];
                    }
                }
            }
           //echo '<pre>'; print_r($shipping_tags); echo '</pre>';die();
           

            // Item Meta
            $coupon_data = array();
            $main_categories = array();
            $total_caregories = array();
            $newarray = array();
            $checktermarray = array();
            foreach ($order->get_items() as $item_key => $item_values) {
                $new_item = [];

                $item_data = $item_values->get_data();

                $product_id = $item_data['product_id'];
                $variation_id = $item_data['variation_id'];
                $quantity = $item_data['quantity'];
                $term_names = wp_get_post_terms($product_id, 'product_cat', array('fields' => 'names'));
                //Update category counts
                $product_brand = get_post_meta($product_id, 'product_brand', true);
                $main_category = get_post_meta($product_id, 'main_category', true);

                if (isset($main_categories[$product_brand][$main_category])) {
                    $main_categories[$product_brand][$main_category] +=  $item_data['total'];
                } else {
                    $main_categories[$product_brand][$main_category] =  $item_data['total'];
                }

                if (isset($total_caregories[$main_category])) {
                    $total_caregories[$main_category] +=  $item_data['total'];
                } else {
                    $total_caregories[$main_category] =  $item_data['total'];
                }

                //-----Accessories Brands
                $terms = get_the_terms($product_id, 'product_cat');
                foreach ($terms as $term) {
                    if ($term->parent  != '0' && $term->parent == '491' && $term->name != 'Training') {
                        if (isset($checktermarray['accesories'][$term->name])) {
                            $checktermarray['accesories'][$term->name] +=  $item_data['total'];
                        } else {
                            $checktermarray['accesories'][$term->name] =  $item_data['total'];
                        }
                    }
                    if ($term->name == 'Training') {
                        if (isset($checktermarray['accesories'][$term->name])) {
                            $checktermarray['accesories'][$term->name] +=  $item_data['total'];
                        } else {
                            $checktermarray['accesories'][$term->name] =  $item_data['total'];
                        }
                    }
                }




                //Coupon Code
                $coupon_code = $item_data['code'];
                $discount_amount = $item_data['discount'] + $item_data['discount_tax'];

                $coupon_data[] = array(
                    'coupon_code' => $coupon_code,
                    'discount_amount' => $discount_amount
                );


                $sql = "select * from wp_atum_inventory_orders where order_item_id = '$item_key'";
                $results = $wpdb->get_results(
                    $sql,
                    ARRAY_A
                );

                foreach ($results as $values) {
                    $extradata = $values['extra_data'];
                    $stockquantity = $values['qty'];

                    if ($extradata) {
                        $finalunserlizedata = unserialize($extradata);
                        $stockname = $finalunserlizedata['name'];
                        $finalarraycheck[$item_key][$stockname] = $stockquantity;
                    }
                }
                $finalqtyarray[$item_key]['qty'] = $quantity;
            }
           
            foreach ($file_header_array as $key => $value) {

                switch ($key) {
                    case 'orderid':
                        $new_item[] = $order->get_order_number();
                        break;

                    case 'customer_type':
                        $ordertype = $order->get_meta('_wwpp_order_type', true);
                        if ($ordertype) {
                            $new_item[] = $order->get_meta('_wwpp_order_type', true);
                        } else {
                            $user = $order->get_user();

                            $roles = (array) $user->roles;
                            if (in_array('administrator', $roles)) {
                                $new_item[] = 'admin';
                            } elseif (in_array('wholesale_customer', $roles)) {
                                $new_item[] = 'wholesale';
                            } else {
                                $new_item[] = '';
                            }
                        }

                        break;

                    case 'customer':
                        $new_item[] = $order->get_billing_first_name() . ' ' . $order->get_billing_last_name();
                        break;

                    case 'shipping_business_name':
                        if ($order->get_billing_company()) {
                            $new_item[]  = $order->get_billing_company();
                        } else {
                            $new_item[] = '';
                        }
                        break;

                    case 'shipping_address':
                        $isaddress = '';
                        if ($order->get_shipping_address_1() && $order->get_billing_address_2()) {
                            $isaddress = $order->get_shipping_address_1() . ', ' . $order->get_billing_address_2() . ', ' . $order->get_shipping_city() . ', ' . $order->get_shipping_state() . ' ' . $order->get_shipping_postcode();
                        } else {
                            $isaddress = $order->get_shipping_address_1() . ', ' . $order->get_shipping_city() . ', ' . $order->get_shipping_state() . ' ' . $order->get_shipping_postcode();
                        }
                        $new_item[] = $isaddress;
                        break;

                    case 'email':
                        $new_item[] = $order->get_billing_email();
                        break;

                    case 'phone':
                        $new_item[] = $order->get_billing_phone();
                        break;

                    case 'order_date':
                        $new_item[] = date('m/d/Y', strtotime($order->get_date_created()));
                        break;

                    case 'customer_notes':
                        $new_item[] = $order->get_customer_note();
                        break;
                    case 'customs_broker_name':
                        $isbrokername = get_post_meta($order->get_id(), 'bold_custom_broker', true);
                        if ($isbrokername != '') {
                            $new_item[] = $isbrokername;
                        } else {
                            $new_item[] = '';
                        }
                        break;


                    case 'customs_broker':
                        if ($isbroker != '') {
                            $new_item[] = $isbroker;
                        } else {
                            $new_item[] = '';
                        }
                        break;

                    case 'payment_method':
                        if ($order->get_payment_method_title() == 'Cash on delivery') {
                            $new_item[] = 'COD';
                        } else {
                            $new_item[] = $order->get_payment_method_title();
                        }
                        break;

                    case 'order_status':
                        $check_status = $order->get_status();
                        if($check_status == 'custom-status'){
                            $new_item [] = 'Pending';
                        }else{
                            $new_item[] = ucfirst($order->get_status());
                        }
                       
                    break;


                    case 'items_subtotal':
                        $new_item[] = $isOrder_subtotal;
                    break;

                    case 'coupon_code':
                        if ($coupon_array['coupon_data']) {
                            $new_item[] = $coupon_array['coupon_data'];
                        } else {
                            $new_item[] = '';
                        }
                    break;

                    case 'coupon_amount':
                        if ($order->get_discount_total()) {
                            $new_item[] = $currency . '' . number_format($order->get_discount_total(), 2);
                        } else {
                            $new_item[] = '';
                        }
                    break;

                    case 'customfee_title':
                       
                        if($fee_titles_string != ''){
                            $new_item[] = $fee_titles_string;
                        }else{
                            $new_item[] = '';
                        }

                    break;

                    case 'customfee':

                        if ($customfee != '' && $customfee != 0) {

                            $new_item[] = $currency . '' . $customfee;

                        }
                        else {
                            $new_item[] = '';
                        }

                    break;

                    case 'discount_title':
                        
                        if($Discountlabel != ''){
                            $new_item[] = $Discountlabel;
                        }else{
                            $new_item[] = '';
                        }
                    break;

                    
                    case 'discount_fee':

                        if ($Discount_amount != '' && $Discount_amount != 0) {

                            $new_item[] = $currency . '' . $Discount_amount;

                        }
                        else {
                            $new_item[] = '';
                        }

                    break;

                    case 'international_customs_fee':
                        if($importing_gst_fee != '' && $importing_gst_fee != 0){
                            $new_item[] = $currency.''.$importing_gst_fee;
                        }
                        else{
                            $new_item[] = '';
                        }
                    break;

                    case 'bold_discount':
                        if ($fees_Discount_amount != '' && $fees_Discount_amount != 0) {
                            $new_item[] = $currency . '' . $fees_Discount_amount;
                        } else {
                            $new_item[] = '';
                        }
                    break;

                    case 'shipping_total':
                        $new_item[] = $currency . '' . number_format($order->get_shipping_total(), 2);
                    break;

                    case 'ca_tax':
                        $new_item[] = $currency . '' . number_format($order->get_total_tax(), 2);
                    break;

                    case 'order_total':
                        $new_item[] = $currency . '' . number_format($order->get_total(), 2);
                    break;

                    case 'bold_warehouse_cost':
                        if($shipping_tags['bold_warehouse']['total'] == '0' || $shipping_tags['From Bold Warehouse']['total'] == '0'){
                            $new_item[] = $currency.''.'0.00';
                        }
                        else if($shipping_tags['bold_warehouse']['total']){
                            $new_item[] = $currency.''.number_format($shipping_tags['bold_warehouse']['total']);
                        }
                        elseif($shipping_tags['From Bold Warehouse']['total']){
                            $new_item[] =  $currency.''.number_format($shipping_tags['From Bold Warehouse']['total']);
                        }else{
                            $new_item[] = '';
                        }
                    break;

                    case 'current_stock_shipping_cost':
                        if($shipping_tags['current_stock']['total']){
                            $new_item[] = $currency.''.number_format($shipping_tags['current_stock']['total'], 2);
                        }
                        elseif($shipping_tags['From Bold - In Stock']['total']){
                            $new_item[] = $currency.''.number_format($shipping_tags['From Bold - In Stock']['total'], 2); 
                        }
                        else if($shipping_tags['From Bold - In Stock']['total'] == '0' || $shipping_tags['current_stock']['total'] == '0'){
                            $new_item[] = $currency.''.'0.00';
                        }
                        else{
                            $new_item[] = '';
                        }
                    break;

                    case 'future_stock_shipping_cost':
                        if($shipping_tags['future_stock']['total']){
                            $new_item[] = $currency.''.number_format($shipping_tags['future_stock']['total'], 2);
                        }elseif($shipping_tags['From Bold - Incoming']['total']){
                            $new_item[] = $currency.''.number_format($shipping_tags['From Bold - Incoming']['total'], 2);
                        }else if($shipping_tags['From Bold - Incoming']['total'] == '0' || $shipping_tags['future_stock']['total'] == '0'){
                            $new_item[] = $currency.''.'0.00';
                        }
                        else{
                            $new_item[] = '';
                        }
                    break;

                    case 'mto_stock_shipping_cost':
                        if($shipping_tags['mto_stock']['total']){
                            $new_item[] = $currency.''.number_format($shipping_tags['mto_stock']['total'], 2);
                        }elseif($shipping_tags['From Bold - MTO']['total']){
                            $new_item[] = $currency.''.number_format($shipping_tags['From Bold - MTO']['total'], 2);
                        }else if($shipping_tags['mto_stock']['total'] == '0' || $shipping_tags['From Bold - MTO']['total'] == '0'){
                            $new_item[] = $currency.''.'0.00';
                        }
                        else{
                            $new_item[] = '';
                        }
                    break;

                    case 'proxy_ship_cost':
                        if($shipping_tags['proxy_shipping']['total']){
                            $new_item[] = $currency.''.number_format($shipping_tags['proxy_shipping']['total'], 2);
                        }else if($shipping_tags['From Proxy']['total']){
                            $new_item[] = $currency.''.number_format($shipping_tags['From Proxy']['total'], 2);
                        }else if($shipping_tags['From Proxy']['total'] == '0' || $shipping_tags['proxy_shipping']['total'] == '0'){
                            $new_item[] = $currency.''.'0.00';
                        }
                        else{
                            $new_item[] = '';
                        }
                    break;

                    case 'aragon_ship_cost':
                        if($shipping_tags['aragon_shipping']['total']){
                                $new_item[] = $currency.''.number_format($shipping_tags['aragon_shipping']['total'], 2);
                        }else if($shipping_tags['From Aragon']['total']){
                            $new_item[] = $currency.''.number_format($shipping_tags['From Aragon']['total'], 2);
                        }else if($shipping_tags['From Aragon']['total'] == '0' || $shipping_tags['aragon_shipping']['total'] == '0'){
                            $new_item[] = $currency.''.'0.00';
                        }
                        else{
                            $new_item[] = '';
                        }
                    break;

                    case 'compx_ship_cost':
                        if($shipping_tags['CompX']['total']){
                            $new_item[] = $currency.''.number_format($shipping_tags['CompX']['total'], 2);
                        }
                        else if($shipping_tags['From Composite']['total']){
                            $new_item[] = $currency.''.number_format($shipping_tags['From Composite']['total'], 2);
                        }
                        else if($shipping_tags['From Composite-X']['total']){
                            $new_item[] = $currency.''.number_format($shipping_tags['From Composite-X']['total'], 2);
                        }
                        else if($shipping_tags['other']['total']){
                            $new_item[] = $currency.''.number_format($shipping_tags['other']['total'], 2);
                        }
                        else if($shipping_tags['flat_rate']['total']){
                            $new_item[] = $currency.''.number_format($shipping_tags['flat_rate']['total'], 2);

                        }else if($shipping_tags['CompX']['total'] == '0' || $shipping_tags['From Composite']['total'] == '0' || $shipping_tags['From Composite-X']['total'] == '0' || $shipping_tags['other']['total'] == '0' || $shipping_tags['flat_rate']['total'] == '0'){
                            $new_item[] = $currency.''.'0.00';
                        }
                        else{
                            $new_item[] = '';
                        }
                    break;


                    case 'requires_quote':
                        if($shipping_tags['quote_required']['total']){
                            $new_item[] = $currency.''.number_format($shipping_tags['quote_required']['total'], 2);
                        } 
                        elseif($shipping_tags['Requires Quote']['total']){
                            $new_item[] = $currency.''.number_format($shipping_tags['Requires Quote']['total'], 2);
                        }
                        elseif($shipping_tags['alg_wc_shipping']['total']){
                            $new_item[] = $currency.''.number_format($shipping_tags['alg_wc_shipping']['total'], 2);

                        }
                        elseif($shipping_tags['quote_required']['total'] == '0' || $shipping_tags['Requires Quote']['total'] == '0' || $shipping_tags['alg_wc_shipping']['total'] == '0' || $shipping_tags['Quote Required']['total'] == '0'){
                            $new_item[] = $currency.''.'0.00';
                        }
                        else{
                            $new_item[] = '';
                        }
                    break;

                    case 'bold_warehouse':
                        if($shipping_tags['From Bold Warehouse']){
                            $new_item[] = $shipping_tags['From Bold Warehouse']['title'];

                        }else if($shipping_tags['proxy_shipping']['title'] == 'proxy_shipping'){
                            $new_item[] =  '';
                        }
                        else if($shipping_tags['aragon_shipping']['title'] == 'aragon_shipping'){
                            $new_item[] =  '';
                        }
                        else if($shipping_tags['flat_rate']['title'] == 'flat_rate'){
                            $new_item[] =  '';
                        }
                        else if($shipping_tags['alg_wc_shipping']['title'] == 'alg_wc_shipping'){
                            $new_item[] =  '';
                        }
                        else if($shipping_tags['rlc']['title'] == 'rlc'){
                            $new_item[] =  'Frieght';
                        }
                        else if($shipping_tags['wf_shipping_ups']['title'] == 'wf_shipping_ups'){
                            $new_item[] =  'UPS/USPS Ground';
                        }
                        else if($shipping_tags['local_pickup']['title'] == 'local_pickup'){
                            $new_item[] =  '';
                        }
                        else{
                            $new_item[] = '';
                        }

                    break;


                    case 'current_stock_shipping':
                        if($shipping_tags['From Bold - In Stock']['title']){
                            $new_item[] = $shipping_tags['From Bold - In Stock']['title'];
                        }else{
                            $new_item[] = '';
                        }
                    break;

                    case 'future_stock_shipping':
                        if($shipping_tags['From Bold - Incoming']['title']){
                            $new_item[] = $shipping_tags['From Bold - Incoming']['title'];
                        }else{
                            $new_item[] = '';
                        }
                    break;

                    case 'mto_stock_shipping':
                        if($shipping_tags['From Bold - MTO']['title']){
                            $new_item[] = $shipping_tags['From Bold - MTO']['title'];
                        }else{
                            $new_item[] = '';
                        }
                    break;

                    case 'sw_bold_warehouse':
                        if($shipping_tags['From Bold Warehouse']){
                            $new_item[] = $shipping_tags['From Bold Warehouse']['weight'];
                        }else{
                            $new_item[] = '';
                        }
                    break;


                    case 'sw_current_stock_shipping':
                        if($shipping_tags['From Bold - In Stock']['weight']){
                            $new_item[] = $shipping_tags['From Bold - In Stock']['weight'];
                        }else{
                            $new_item[] = '';
                        }
                    break;

                    case 'sw_future_stock_shipping':
                        if($shipping_tags['From Bold - Incoming']['weight']){
                            $new_item[] = $shipping_tags['From Bold - Incoming']['weight'];
                        }else{
                            $new_item[] = '';
                        }
                    break;

                    case 'sw_mto_stock_shipping':
                        if($shipping_tags['From Bold - MTO']['weight']){
                            $new_item[] = $shipping_tags['From Bold - MTO']['weight'];
                        }else{
                            $new_item[] = '';
                        }
                    break;

                    case 'sw_quote':
                        if($shipping_tags['quote_required']['weight']){
                            $new_item[] = $shipping_tags['quote_required']['weight'];
                        }
                        elseif($shipping_tags['Free shipping']['weight']){
                            $new_item[] = $shipping_tags['Free shipping']['weight'];
                        }
                        elseif($shipping_meta_total['Requires Quote']){
                            $new_item[] = $shipping_tags['Requires Quote']['weight'];
                        }
                        elseif($shipping_meta_total['Free shipping']){
                            $new_item[] = $shipping_tags['Requires Quote']['weight'];
                        }
                        
                        else{
                            $new_item[] = '';
                        }
                    break;
                        

                    case 'category_holds':
                        if ($total_caregories['Holds']) {
                            $new_item[] = $currency . '' . number_format($total_caregories['Holds'], 2);
                        } else {
                            $new_item[] = '';
                        }
                    break;

                    case 'category_macros':
                        if ($total_caregories['Macros']) {
                            $new_item[] = $currency . '' . number_format($total_caregories['Macros'], 2);
                        } else {
                            $new_item[] = '';
                        }
                    break;

                    case 'category_volumes':
                        if ($total_caregories['Volumes']) {
                            $new_item[] = $currency . '' . number_format($total_caregories['Volumes'], 2);
                        } else {
                            $new_item[] = '';
                        }
                    break;

                    case 'category_accessories':
                        if ($total_caregories['Accessories']) {
                            $new_item[] = $currency . '' . number_format($total_caregories['Accessories'], 2);
                        } else {
                            $new_item[] = '';
                        }
                    break;

                    case 'category_static_air':
                        if ($total_caregories['Static Air']) {
                            $new_item[] = $currency . '' . number_format($total_caregories['Static Air'], 2);
                        } else {
                            $new_item[] = '';
                        }
                    break;

                    case 'blocz_holds':
                        if ($main_categories['Blocz']['Holds']) {
                            $new_item[] = $currency . '' . number_format($main_categories['Blocz']['Holds'], 2);
                        } else {
                            $new_item[] = '';
                        }
                    break;

                    case 'blocz_macros':
                        if ($main_categories['Blocz']['Macros']) {
                            $new_item[] = $currency . '' . number_format($main_categories['Blocz']['Macros'], 2);
                        } else {
                            $new_item[] = '';
                        }
                    break;

                    case 'blocz_volumes':
                        if ($main_categories['Blocz']['Volumes']) {
                            $new_item[] = $currency . '' . number_format($main_categories['Blocz']['Volumes'], 2);
                        } else {
                            $new_item[] = '';
                        }
                    break;

                    case 'bluepill_holds':
                        if ($main_categories['Bluepill']['Holds']) {
                            $new_item[] = $currency . '' . number_format($main_categories['Bluepill']['Holds'], 2);
                        } else {
                            $new_item[] = '';
                        }
                    break;

                    case 'bluepill_macros':
                        if ($main_categories['Bluepill']['Macros']) {
                            $new_item[] = $currency . '' . number_format($main_categories['Bluepill']['Macros'], 2);
                        } else {
                            $new_item[] = '';
                        }
                    break;

                    case 'bluepill_volumes':
                        if ($main_categories['Bluepill']['Volumes']) {
                            $new_item[] = $currency . '' . number_format($main_categories['Bluepill']['Volumes'], 2);
                        } else {
                            $new_item[] = '';
                        }
                    break;

                    case 'unit_holds':
                        if ($main_categories['Unit']['Holds']) {
                            $new_item[] = $currency . '' . number_format($main_categories['Unit']['Holds'], 2);
                        } else {
                            $new_item[] = '';
                        }
                    break;

                    case 'unit_macros':
                        if ($main_categories['Unit']['Macros']) {
                            $new_item[] = $currency . '' . number_format($main_categories['Unit']['Macros'], 2);
                        } else {
                            $new_item[] = '';
                        }
                    break;

                    case 'unit_volumes':
                        if ($main_categories['Unit']['Volumes']) {
                            $new_item[] = $currency . '' . number_format($main_categories['Unit']['Volumes'], 2);
                        } else {
                            $new_item[] = '';
                        }
                    break;

                    case 'rustam_holds':
                        if($main_categories['Rustam']['Holds']){
                            $new_item[] = $currency.''.number_format($main_categories['Rustam']['Holds'], 2);
                        }else{
                            $new_item[] = '';
                        }
                    break;

                    case 'rustam_macros':
                        if($main_categories['Rustam']['Macros']){
                            $new_item[] = $currency.''.number_format($main_categories['Rustam']['Macros'], 2);
                        }else{
                            $new_item[] = '';
                        }
                    break;

                    case 'rustam_volumes':
                        if($main_categories['Rustam']['Volumes']){
                            $new_item[] = $currency.''.number_format($main_categories['Rustam']['Volumes'], 2);
                        }else{
                            $new_item[] = '';
                        }
                    break;

                    case 'artline_holds':
                        if ($main_categories['Artline']['Holds']) {
                            $new_item[] = $currency . '' . number_format($main_categories['Artline']['Holds'], 2);
                        } else {
                            $new_item[] = '';
                        }
                    break;
                    case 'artline_macros':
                        if ($main_categories['Artline']['Macros']) {
                            $new_item[] = $currency . '' . number_format($main_categories['Artline']['Macros'], 2);
                        } else {
                            $new_item[] = '';
                        }
                    break;
                    
                    case 'artline_volumes':
                        if ($main_categories['Artline']['Volumes']) {
                            $new_item[] = $currency . '' . number_format($main_categories['Artline']['Volumes'], 2);
                        } else {
                            $new_item[] = '';
                        }
                    break;

                    case '360_holds':
                        if ($main_categories['360']['Holds']) {
                            $new_item[] = $currency . '' . number_format($main_categories['360']['Holds'], 2);
                        } else {
                            $new_item[] = '';
                        }
                    break;

                    case '360_macros':
                        if ($main_categories['360']['Macros']) {
                            $new_item[] = $currency . '' . number_format($main_categories['360']['Macros'], 2);
                        } else {
                            $new_item[] = '';
                        }
                    break;

                    case '360_volumes':
                        if ($main_categories['360']['Volumes']) {
                            $new_item[] = $currency . '' . number_format($main_categories['360']['Volumes'], 2);
                        } else {
                            $new_item[] = '';
                        }
                    break;

                    case 'simpl_holds':
                        if ($main_categories['Simpl']['Holds']) {
                            $new_item[] = $currency . '' . number_format($main_categories['Simpl']['Holds'], 2);
                        } else {
                            $new_item[] = '';
                        }
                    break;

                    case 'simpl_macros':
                        if ($main_categories['Simpl']['Macros']) {
                            $new_item[] = $currency . '' . number_format($main_categories['Simpl']['Macros'], 2);
                        } else {
                            $new_item[] = '';
                        }
                    break;

                    case 'simpl_volumes':
                        if ($main_categories['Simpl']['Volumes']) {
                            $new_item[] = $currency . '' . number_format($main_categories['Simpl']['Volumes'], 2);
                        } else {
                            $new_item[] = '';
                        }
                    break;

                    case 'rockcity_holds':
                        if ($main_categories['Rockcity']['Holds']) {
                            $new_item[] = $currency . '' . number_format($main_categories['Rockcity']['Holds'], 2);
                        } else if ($main_categories['Rock City']['Holds']) {
                            $new_item[] = $currency . '' . number_format($main_categories['Rock City']['Holds'], 2);
                        } else {
                            $new_item[] = '';
                        }
                    break;

                    case 'rockcity_macros':
                        if ($main_categories['Rockcity']['Macros']) {
                            $new_item[] = $currency . '' . number_format($main_categories['Rockcity']['Macros'], 2);
                        } else {
                            $new_item[] = '';
                        }
                    break;

                    case 'rockcity_volumes':
                        if ($main_categories['Rockcity']['Volumes']) {
                            $new_item[] = $currency . '' . number_format($main_categories['Rockcity']['Volumes'], 2);
                        } else {
                            $new_item[] = '';
                        }
                    break;

                    case 'chapter_holds':
                        if ($main_categories['Chapter']['Holds']) {
                            $new_item[] = $currency . '' . number_format($main_categories['Chapter']['Holds'], 2);
                        } else {
                            $new_item[] = '';
                        }
                    break;

                    case 'chapter_macros':
                        if ($main_categories['Chapter']['Macros']) {
                            $new_item[] = $currency . '' . number_format($main_categories['Chapter']['Macros'], 2);
                        } else {
                            $new_item[] = '';
                        }
                    break;

                    case 'chapter_volumes':
                        if ($main_categories['Chapter']['Volumes']) {
                            $new_item[] = $currency . '' . number_format($main_categories['Chapter']['Volumes'], 2);
                        } else {
                            $new_item[] = '';
                        }
                    break;

                    case 'cce_holds':
                        if ($main_categories['CCE']['Holds']) {
                            $new_item[] = $currency . '' . number_format($main_categories['CCE']['Holds'], 2);
                        } else {
                            $new_item[] = '';
                        }
                    break;

                    case 'cce_macros':
                        if ($main_categories['CCE']['Macros']) {
                            $new_item[] = $currency . '' . number_format($main_categories['CCE']['Macros'], 2);
                        } else {
                            $new_item[] = '';
                        }
                    break;

                    case 'cce_volumes':
                        if ($main_categories['CCE']['Volumes']) {
                            $new_item[] = $currency . '' . number_format($main_categories['CCE']['Volumes'], 2);
                        } else {
                            $new_item[] = '';
                        }
                    break;
                    
                    case 'menagerie_holds':
                        if ($main_categories['Menagerie']['Holds']) {
                            $new_item[] = $currency . '' . number_format($main_categories['Menagerie']['Holds'], 2);
                        } else {
                            $new_item[] = '';
                        }
                        break;
                    case 'menagerie_macros':
                        if ($main_categories['Menagerie']['Macros']) {
                            $new_item[] = $currency . '' . number_format($main_categories['Menagerie']['Macros'], 2);
                        } else {
                            $new_item[] = '';
                        }
                        break;
                    case 'menagerie_volumes':
                        if ($main_categories['Menagerie']['Volumes']) {
                            $new_item[] = $currency . '' . number_format($main_categories['Menagerie']['Volumes'], 2);
                        } else {
                            $new_item[] = '';
                        }
                        break;
                    case 'formik_holds':
                        if ($main_categories['Formik']['Holds']) {
                            $new_item[] = $currency . '' . number_format($main_categories['Formik']['Holds'], 2);
                        } else {
                            $new_item[] = '';
                        }
                        break;
                    case 'formik_macros':
                        if ($main_categories['Formik']['Macros']) {
                            $new_item[] = $currency . '' . number_format($main_categories['Formik']['Macros'], 2);
                        } else {
                            $new_item[] = '';
                        }
                        break;
                    case 'formik_volumes':
                        if ($main_categories['Formik']['Volumes']) {
                            $new_item[] = $currency . '' . number_format($main_categories['Formik']['Volumes'], 2);
                        } else {
                            $new_item[] = '';
                        }
                        break;
                    case 'accessories_chalk':
                        
                        if ($checktermarray['accesories']['Chalk &amp; Skin Care']) {
                            $new_item[] = $currency . '' . number_format($checktermarray['accesories']['Chalk &amp; Skin Care'], 2);
                        } else {
                            $new_item[] = '';
                        }
                        break;
                    case 'accessories_brushes':
                    
                        if ($checktermarray['accesories']['Brushes']) {
                            $new_item[] = $currency . '' . number_format($checktermarray['accesories']['Brushes'], 2);
                        } else {
                            $new_item[] = '';
                        }
                        break;
                    case 'accessories_setting':
                        
                        if ($checktermarray['accesories']['Setting &amp; Hardware']) {
                            $new_item[] = $currency . '' . number_format($checktermarray['accesories']['Setting &amp; Hardware'], 2);
                        } else {
                            $new_item[] = '';
                        }
                        break;
                    case 'accessories_training':
                        
                        if ($checktermarray['accesories']['Training']) {
                            $new_item[] = $currency . '' . number_format($checktermarray['accesories']['Training'], 2);
                        } else {
                            $new_item[] = '';
                        }
                        break;
                    case 'accessories_custom_branding':
                        if ($main_categories['Custom Branding']['Accessories']) {
                            $new_item[] = $currency . '' . number_format($main_categories['Custom Branding']['Accessories'], 2);
                        } else {
                            $new_item[] = '';
                        }
                        break;
                }
            }
            $csv_data[] = $new_item;

        }
        
    }
    // Add extra rows
    $extra_rows = 15;
    $empty_row = array_fill(0, count($file_header_array), '');

    for ($i = 0; $i < $extra_rows; $i++) {
        $csv_data[] = $empty_row;
    }
    //echo '<pre>'; print_r($csv_data); echo '</pre>';
    //die();
	
    unlink("/www/bold.test-domain-wp.com/csv/csv-files/order-summary.csv");
    $filename = 'order-summary.csv';

    $fp = fopen('/www/bold.test-domain-wp.com/csv/csv-files/' . $filename, 'w');

    foreach ($csv_data as $fields) {
        fputcsv($fp, $fields, ",");
    }

    fclose($fp);

    $finallink = 'https://boldclimbing.com/csv/csv-files/' . $filename;
    $rows = $csv_data;
    $csv = array();
    $file = fopen($finallink, 'r');

    while (($result = fgetcsv($file)) !== false) {
        $csv[] = $result;
    }

    fclose($file);

    require_once '/www/bold.test-domain-wp.com/csv/vendor/autoload.php';

    $client = new \Google_Client();
    $client->setApplicationName('Bold Climbing - All Data');
    $client->setScopes([\Google_Service_Sheets::SPREADSHEETS]);
    $client->setAccessType('offline');


    $path = '/www/bold.test-domain-wp.com/csv/credentials.json';
    $client->setAuthConfig($path);


    $service = new \Google_Service_Sheets($client);

     // ********* Order Summary *******
    $spreadsheetId = '1BUFObnO5LDlwsx0TJ0KTqMxAQzcnKJD1Ahkx8LtsSeo';
     // ********* Bold Sale *******
    $spreadsheetId2 = '1d7850Yh5kiNwwoJxIiHdod9xBMX7L0MPq_1IdzKGuWQ';
    //**** copy of bold sale ******
    $spreadsheetId3 = '1zRpgMdIY2a-PLYNNA96yEh552OI6jMXRr5EUb6djR5M';

    
    $spreadsheet = $service->spreadsheets->get($spreadsheetId);

    // Get the data from the spreadsheet
    $range = 'Completed Summary';
    $response = $service->spreadsheets_values->get($spreadsheetId, $range);
    $values = $response->getValues();
    $valueRange = new \Google_Service_Sheets_ValueRange();

    // ********* Order Summary *******
    $csv = $csv;
    $range = 'Completed Summary';
    $valueRange = new \Google_Service_Sheets_ValueRange();
    $valueRange->setValues($csv);
    $options = ['valueInputOption' => 'USER_ENTERED'];
    $response = $service->spreadsheets_values->update($spreadsheetId, $range, $valueRange, $options);
    

    // ********* Bold Sale *******
    $csv = $csv;
    //$range = 'Orders Data';
    $range = 'Orders Summary';
    $valueRange = new \Google_Service_Sheets_ValueRange();
    $valueRange->setValues($csv);
    $options = ['valueInputOption' => 'USER_ENTERED'];
    $response2 = $service->spreadsheets_values->update($spreadsheetId2, $range, $valueRange, $options);
    
    
    // ********* Copy of bold sales *******
    $csv = $csv;
    $range = 'Orders Data';
    $valueRange = new \Google_Service_Sheets_ValueRange();
    $valueRange->setValues($csv);
    $options = ['valueInputOption' => 'USER_ENTERED'];
    $response3 = $service->spreadsheets_values->update($spreadsheetId3, $range, $valueRange, $options);
    
    
    if ($response->updatedCells > 0) {
        echo 'Completed Summary sheet updated successfully with new data.';
    } else {
        echo 'Failed to update sheet.';
    }
    if ($response2->updatedCells > 0) {
        echo 'Bold Orders Data sheet updated successfully with new data.';
    } else {
        echo 'Failed to update sheet.';
    }
    if ($response3->updatedCells > 0) {
        echo 'Copy of bold sales Data sheet updated successfully with new data.';
    } else {
        echo 'Failed to update sheet.';
    }
}


// completed Order P Exporter
// Completed_Order_Exporter
// completed_order_exporter_func
add_filter('cron_schedules', 'Completed_Order_Exporter');
function Completed_Order_Exporter($schedules)
{
    $schedules['once_hourly'] = array(
        'interval'  => 43200,
        'display'   => __('Twice Daily', 'textdomain')
    );
    return $schedules;
}


if (!wp_next_scheduled('Completed_Order_Exporter')) {
    wp_schedule_event(time(), 'once_hourly', 'Completed_Order_Exporter');
}


add_action('Completed_Order_Exporter', 'completed_order_exporter_func');
function completed_order_exporter_func()
{
    $order_statuses = array('wc-processing', 'wc-on-hold', 'wc-partially-paid', 'wc-completed', 'custom-status');
    // Call Quarters function
    $date = date('Y-m-d');
    $quarters = get_quarters_data('2023-07-01', $date);
    $reverseQuarters = array_reverse($quarters);


    $file_header_array = array();
    $file_header_array['orderid'] = 'Order#';
    $file_header_array['date_created'] = 'Date Created';
    $file_header_array['status'] = 'Status';
    $file_header_array['customer'] = 'Customer';
    $file_header_array['business_name'] = 'Business Name';
    $file_header_array['customer_type'] = 'Customer Type';
    $file_header_array['product_id'] = 'Product ID';
    $file_header_array['Parent_product'] = 'Parent Product';
    $file_header_array['product_name'] = 'Product Name';
    $file_header_array['main_category'] = 'Main Category';
    $file_header_array['manufacturer'] = 'Manufacturer';
    $file_header_array['_brnad'] = 'Brand';
    $file_header_array['__sku'] = 'SKU';
    $file_header_array['wholesale_price'] = 'Wholesale Price';
    $file_header_array['ordered_quantity'] = 'Ordered Quantity';
    $file_header_array['order_current_stock'] = 'Order - Current Stock';
    $file_header_array['order_future_stock'] = 'Order - Future Stock';
    $file_header_array['order_mto'] = 'Order - MTO';

    $newheaderarray = array();
    foreach ($file_header_array as $field) {
        $newheaderarray[] = $field;
    }

    //SCV Header
    $csv_data = array(
        $newheaderarray
    );
    global $wpdb;
    foreach($reverseQuarters as $value){
        $qstart = $value->period_start;
        $qend   = $value->period_end;
        $period = $value->period; 
        $finaldate = $qstart.'='.$qend;
    
        if ($period) {
            $explodedates = explode("=", $finaldate);
            $final_date = $explodedates[1];
            $initial_date = $explodedates[0];
        } else {
            if ($qstart == '' && $qend == '') {
                $final_date = date('Y-m-d');
                $initial_date = date('Y-m-d', strtotime('-90 days'));
            } else {
            }
        }
        $orders = wc_get_orders(
            array(
                'limit' => -1,
                'type' => 'shop_order',
                'status' => $order_statuses,
                //'post__in' => array(203699),
                'date_created' => $initial_date . '...' . $final_date
            )
        );

        $finalorderwithdata = array();
        foreach ($orders as $order) {
            $order_id = $order->ID;
            $finalqtyarray = array();
            $finalarraycheck = array();


            foreach ($order->get_items() as $item_key => $item_values) {
                $new_item = [];
                $item_data = $item_values->get_data();
                $product_id = $item_data['product_id'];
                $variation_id = $item_data['variation_id'];
                $quantity = $item_data['quantity'];

                $sql = "select * from wp_atum_inventory_orders where order_item_id = '$item_key'";
                $results = $wpdb->get_results(
                    $sql,
                    ARRAY_A
                );
                
               
                foreach ($results as $values) {
                    $extradata = $values['extra_data'];
                    $stockquantity = $values['qty'];

                    if ($extradata) {
                        $finalunserlizedata = unserialize($extradata);
                        $stockname = $finalunserlizedata['name'];
                        $finalarraycheck[$item_key][$stockname] = $stockquantity;
                    }
                }
               
                $finalqtyarray[$item_key]['qty'] = $quantity;
                
                $prod_terms = get_the_terms($product_id, 'product_cat');
               //echo '<pre>'; print_r($prod_terms); echo '</pre>';
               foreach($prod_terms as $val){
                    if ($val->parent == 0) {
                        $final_cat = $val->name;
                    }
               }
                foreach ($file_header_array as $key => $value) {
                    switch ($key) {
                        case 'orderid':
                            $new_item[] = $order->get_order_number();
                            break;

                        case 'date_created':
                            $new_item[] = date('Y-m-d', strtotime($order->get_date_created()));
                            break;

                        case 'status':
                            $check_status = $order->get_status();
                            if ($check_status == 'custom-status') {
                                $new_item[] = 'Pending';
                            } else {
                                $new_item[] = $order->get_status();
                            }
                           // $new_item[] = $order->get_status();
                            break;

                        case 'customer':
                            $new_item[] = $order->get_billing_first_name() . ' ' . $order->get_billing_last_name();
                            break;
                        case 'business_name':
                            if ($order->get_shipping_company()) {
                                $new_item[] = $order->get_shipping_company();
                            } else {
                                $new_item[] = '';
                            }
                            break;
                        case 'customer_type':
                            $ordertype = $order->get_meta('_wwpp_order_type', true);
                            if ($ordertype) {
                                $new_item[] = $order->get_meta('_wwpp_order_type', true);
                            } else {
                                $user = $order->get_user();

                                $roles = (array) $user->roles;
                                if (in_array('administrator', $roles)) {
                                    $new_item[] = 'admin';
                                } elseif (in_array('wholesale_customer', $roles)) {
                                    $new_item[] = 'wholesale';
                                } else {
                                    $new_item[] = '';
                                }
                            }

                            break;

                        case 'product_id':
                            if ($variation_id == 0) {
                                $new_item[] = $product_id;
                            } else {
                                $new_item[] = $variation_id;
                            }

                        break;
                        
                        case 'main_category':
                            if($final_cat){
                                $new_item[] = $final_cat;
                            }else{
                                $new_item[] = '';
                            }
                        break;

                        case 'Parent_product':
                            if($product_id){
                                $new_item[] = $product_id;
                            }else{
                                $new_item[] = '';
                            }
                        break;

                        case 'product_name':
                            $new_item[] = $item_values->get_name();
                        break;

                        case 'manufacturer':
                            $new_item[] = get_post_meta($product_id, 'bold_product_manufacturer', true);
                        break;

                        case '_brnad':
                            $new_item[] = get_post_meta($product_id, 'product_brand', true);
                        break;

                        case '__sku':
                            $sku = get_post_meta($product_id, '_sku', true);
                            if ($sku) {
                                $new_item[] = $sku;
                            } else {
                                $new_item[] = '';
                            }
                            break;

                        case 'wholesale_price':
                            $new_item[] = get_post_meta($variation_id, 'wholesale_customer_wholesale_price', true);
                        break;

                        case 'ordered_quantity':
                            $new_item[] = $quantity;
                        break;

                        case 'order_current_stock':
                            $new_item[] = $finalarraycheck[$item_key]['Current stock'];
                            break;

                        case 'order_future_stock':
                            $new_item[] = $finalarraycheck[$item_key]['Future Stock'];
                            break;

                        case 'order_mto':
                            $new_item[] = $finalarraycheck[$item_key]['MTO'];
                            break;
                    }
                }


                $csv_data[] = $new_item;
            }
        }
    }
    // Add extra rows
    $extra_rows = 500;
    $empty_row = array_fill(0, count($file_header_array), '');

    for ($i = 0; $i < $extra_rows; $i++) {
        $csv_data[] = $empty_row;
    }

    unlink("/www/bold.test-domain-wp.com/csv/csv-files/order-exporter.csv");
    $filename = 'order-exporter.csv';

    $fp = fopen('/www/bold.test-domain-wp.com/csv/csv-files/' . $filename, 'w');

    foreach ($csv_data as $fields) {
        fputcsv($fp, $fields, ",");
    }

    fclose($fp);

    $finallink = 'https://boldclimbing.com/csv/csv-files/' . $filename;
    $rows = $csv_data;
    $csv = array();
    $file = fopen($finallink, 'r');

    while (($result = fgetcsv($file)) !== false) {
        $csv[] = $result;
    }

    fclose($file);



    require_once '/www/bold.test-domain-wp.com/csv/vendor/autoload.php';

    $client = new \Google_Client();
    $client->setApplicationName('Bold Climbing - All Data');
    $client->setScopes([\Google_Service_Sheets::SPREADSHEETS]);
    $client->setAccessType('offline');


    $path = '/www/bold.test-domain-wp.com/csv/credentials.json';
    $client->setAuthConfig($path);


    $service = new \Google_Service_Sheets($client);

    //****** Order Summary *****/
    $spreadsheetId = '1BUFObnO5LDlwsx0TJ0KTqMxAQzcnKJD1Ahkx8LtsSeo';
    // ***** Bold Sale *****
    $spreadsheetId2 = '1d7850Yh5kiNwwoJxIiHdod9xBMX7L0MPq_1IdzKGuWQ';
    // ***** Website Data *****
    $spreadsheetId3 = '17mV2yNUCgb8w65CjxAWYBNgoNQb-7MyKGzTgJMV6ZjA';

    $spreadsheet = $service->spreadsheets->get($spreadsheetId);

    // ********** Get the data from the spreadsheet **********
    $range = 'Order Exporter';
    $response = $service->spreadsheets_values->get($spreadsheetId, $range);
    $values = $response->getValues();
    $valueRange = new \Google_Service_Sheets_ValueRange();

    //******* Orders Sumaary ********
    $csv = $csv;
    $range = 'Order Exporter';
    $valueRange = new \Google_Service_Sheets_ValueRange();
    $valueRange->setValues($csv);
    $options = ['valueInputOption' => 'USER_ENTERED'];
    $response = $service->spreadsheets_values->update($spreadsheetId, $range, $valueRange, $options);

    //******* Website sales sheet Data ********
    $csv = $csv;
    $range = 'Orders Data';
    $valueRange = new \Google_Service_Sheets_ValueRange();
    $valueRange->setValues($csv);
    $options = ['valueInputOption' => 'USER_ENTERED'];
    $response2 = $service->spreadsheets_values->update($spreadsheetId3, $range, $valueRange, $options);
	
	//******* Bold sales sheet Data Order P ********
    $csv = $csv;
    $range = 'Orders P Data';
    $valueRange = new \Google_Service_Sheets_ValueRange();
    $valueRange->setValues($csv);
    $options = ['valueInputOption' => 'USER_ENTERED'];
    $response3 = $service->spreadsheets_values->update($spreadsheetId2, $range, $valueRange, $options);


    if ($response->updatedCells > 0) {
        echo 'Order Exporter updated successfully with new data.';
    } else {
        echo 'Failed to update sheet.';
    }

    if ($response2->updatedCells > 0) {
        echo ' Website Sale Orders Data updated successfully with new data.';
    } else {
        echo 'Failed to update sheet.';
    }
	
	 if ($response3->updatedCells > 0) {
        echo 'Orders P Data updated successfully with new data.';
    } else {
        echo 'Failed to update sheet.';
    }
}
